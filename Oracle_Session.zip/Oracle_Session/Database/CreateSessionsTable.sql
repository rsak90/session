-- Oracle Sessions Table Creation Script
-- This table stores session data for the ASP.NET MVC application

CREATE TABLE Sessions (
    SessionId NVARCHAR2(449) PRIMARY KEY,
    SessionKey NVARCHAR2(200) NOT NULL,
    SessionValue NCLOB,
    ExpiresAtTime TIMESTAMP NOT NULL,
    SlidingExpirationInSeconds NUMBER,
    AbsoluteExpiration TIMESTAMP
);

-- Create index for efficient cleanup of expired sessions
CREATE INDEX IX_Sessions_ExpiresAtTime ON Sessions (ExpiresAtTime);

-- Create composite index for session retrieval
CREATE INDEX IX_Sessions_SessionId_Key ON Sessions (SessionId, SessionKey);

-- Grant necessary permissions (adjust schema/user as needed)
-- GRANT SELECT, INSERT, UPDATE, DELETE ON Sessions TO your_app_user;