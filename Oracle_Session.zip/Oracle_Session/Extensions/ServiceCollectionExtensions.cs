using Microsoft.AspNetCore.Http;
using SessionOracleMigration.Services;

namespace SessionOracleMigration.Extensions
{
    /// <summary>
    /// Extension methods for configuring Oracle session management
    /// </summary>
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// Adds Oracle-based session management to the service collection
        /// </summary>
        /// <param name="services">The service collection</param>
        /// <param name="connectionString">Oracle database connection string</param>
        /// <param name="sessionTimeout">Session timeout duration (default: 120 minutes)</param>
        /// <returns>The service collection for chaining</returns>
        public static IServiceCollection AddOracleSession(
            this IServiceCollection services, 
            string connectionString, 
            TimeSpan? sessionTimeout = null)
        {
            if (string.IsNullOrEmpty(connectionString))
                throw new ArgumentException("Connection string cannot be null or empty", nameof(connectionString));

            var timeout = sessionTimeout ?? TimeSpan.FromMinutes(120);

            // Register Oracle session store as singleton
            services.AddSingleton<ISessionStore>(serviceProvider =>
            {
                var logger = serviceProvider.GetRequiredService<ILogger<OracleSessionStore>>();
                return new OracleSessionStore(connectionString, logger, timeout);
            });

            // Configure session options
            services.Configure<SessionOptions>(options =>
            {
                options.IdleTimeout = timeout;
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
                options.Cookie.Name = ".AspNetCore.Session";
                options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
                options.Cookie.SameSite = SameSiteMode.Lax;
            });

            // Add session services
            services.AddSession();

            return services;
        }

        /// <summary>
        /// Adds Oracle session management with custom session options
        /// </summary>
        /// <param name="services">The service collection</param>
        /// <param name="connectionString">Oracle database connection string</param>
        /// <param name="configureOptions">Action to configure session options</param>
        /// <param name="sessionTimeout">Session timeout duration (default: 120 minutes)</param>
        /// <returns>The service collection for chaining</returns>
        public static IServiceCollection AddOracleSession(
            this IServiceCollection services,
            string connectionString,
            Action<SessionOptions> configureOptions,
            TimeSpan? sessionTimeout = null)
        {
            if (string.IsNullOrEmpty(connectionString))
                throw new ArgumentException("Connection string cannot be null or empty", nameof(connectionString));

            var timeout = sessionTimeout ?? TimeSpan.FromMinutes(120);

            // Register Oracle session store as singleton
            services.AddSingleton<ISessionStore>(serviceProvider =>
            {
                var logger = serviceProvider.GetRequiredService<ILogger<OracleSessionStore>>();
                return new OracleSessionStore(connectionString, logger, timeout);
            });

            // Configure session options with custom configuration
            services.Configure<SessionOptions>(options =>
            {
                // Set default values
                options.IdleTimeout = timeout;
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
                options.Cookie.Name = ".AspNetCore.Session";
                options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
                options.Cookie.SameSite = SameSiteMode.Lax;

                // Apply custom configuration
                configureOptions?.Invoke(options);
            });

            // Add session services
            services.AddSession();

            return services;
        }
    }
}