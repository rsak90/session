using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using SessionOracleMigration.Models;

namespace SessionOracleMigration.Services
{
    /// <summary>
    /// Manages session expiration logic for Oracle-based sessions
    /// </summary>
    public class SessionExpirationManager
    {
        private readonly string _connectionString;
        private readonly ILogger<SessionExpirationManager> _logger;

        public SessionExpirationManager(string connectionString, ILogger<SessionExpirationManager> logger)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Updates session expiration time based on sliding expiration policy
        /// </summary>
        /// <param name="sessionId">The session ID to update</param>
        /// <param name="slidingExpiration">The sliding expiration duration</param>
        /// <returns>True if the session was updated, false if not found or expired</returns>
        public async Task<bool> UpdateSessionExpirationAsync(string sessionId, TimeSpan slidingExpiration)
        {
            try
            {
                using var connection = new OracleConnection(_connectionString);
                await connection.OpenAsync();

                var newExpirationTime = DateTime.UtcNow.Add(slidingExpiration);
                var slidingExpirationSeconds = (int)slidingExpiration.TotalSeconds;

                const string updateQuery = @"
                    UPDATE Sessions 
                    SET ExpiresAtTime = :newExpiration,
                        SlidingExpirationInSeconds = :slidingExpiration
                    WHERE SessionId = :sessionId 
                    AND ExpiresAtTime > :currentTime";

                using var command = new OracleCommand(updateQuery, connection);
                command.Parameters.Add(":newExpiration", OracleDbType.TimeStamp).Value = newExpirationTime;
                command.Parameters.Add(":slidingExpiration", OracleDbType.Int32).Value = slidingExpirationSeconds;
                command.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = sessionId;
                command.Parameters.Add(":currentTime", OracleDbType.TimeStamp).Value = DateTime.UtcNow;

                var rowsAffected = await command.ExecuteNonQueryAsync();
                
                if (rowsAffected > 0)
                {
                    _logger.LogDebug("Updated expiration for session {SessionId} to {NewExpiration}", 
                        sessionId, newExpirationTime);
                    return true;
                }
                else
                {
                    _logger.LogDebug("Session {SessionId} not found or already expired", sessionId);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating session expiration for session {SessionId}", sessionId);
                throw;
            }
        }

        /// <summary>
        /// Sets absolute expiration for a session
        /// </summary>
        /// <param name="sessionId">The session ID to update</param>
        /// <param name="absoluteExpiration">The absolute expiration time</param>
        /// <returns>True if the session was updated, false if not found</returns>
        public async Task<bool> SetAbsoluteExpirationAsync(string sessionId, DateTime absoluteExpiration)
        {
            try
            {
                using var connection = new OracleConnection(_connectionString);
                await connection.OpenAsync();

                const string updateQuery = @"
                    UPDATE Sessions 
                    SET AbsoluteExpiration = :absoluteExpiration,
                        ExpiresAtTime = LEAST(ExpiresAtTime, :absoluteExpiration)
                    WHERE SessionId = :sessionId";

                using var command = new OracleCommand(updateQuery, connection);
                command.Parameters.Add(":absoluteExpiration", OracleDbType.TimeStamp).Value = absoluteExpiration;
                command.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = sessionId;

                var rowsAffected = await command.ExecuteNonQueryAsync();
                
                if (rowsAffected > 0)
                {
                    _logger.LogDebug("Set absolute expiration for session {SessionId} to {AbsoluteExpiration}", 
                        sessionId, absoluteExpiration);
                    return true;
                }
                else
                {
                    _logger.LogDebug("Session {SessionId} not found", sessionId);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error setting absolute expiration for session {SessionId}", sessionId);
                throw;
            }
        }

        /// <summary>
        /// Checks if a session is expired
        /// </summary>
        /// <param name="sessionId">The session ID to check</param>
        /// <returns>True if expired or not found, false if still valid</returns>
        public async Task<bool> IsSessionExpiredAsync(string sessionId)
        {
            try
            {
                using var connection = new OracleConnection(_connectionString);
                await connection.OpenAsync();

                const string checkQuery = @"
                    SELECT COUNT(*) 
                    FROM Sessions 
                    WHERE SessionId = :sessionId 
                    AND ExpiresAtTime > :currentTime";

                using var command = new OracleCommand(checkQuery, connection);
                command.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = sessionId;
                command.Parameters.Add(":currentTime", OracleDbType.TimeStamp).Value = DateTime.UtcNow;

                var result = await command.ExecuteScalarAsync();
                var count = Convert.ToInt32(result);

                var isExpired = count == 0;
                _logger.LogDebug("Session {SessionId} expired status: {IsExpired}", sessionId, isExpired);
                
                return isExpired;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking session expiration for session {SessionId}", sessionId);
                // Assume expired on error for security
                return true;
            }
        }

        /// <summary>
        /// Gets session expiration information
        /// </summary>
        /// <param name="sessionId">The session ID to query</param>
        /// <returns>Session expiration details or null if not found</returns>
        public async Task<SessionExpirationInfo?> GetSessionExpirationInfoAsync(string sessionId)
        {
            try
            {
                using var connection = new OracleConnection(_connectionString);
                await connection.OpenAsync();

                const string query = @"
                    SELECT ExpiresAtTime, SlidingExpirationInSeconds, AbsoluteExpiration
                    FROM Sessions 
                    WHERE SessionId = :sessionId";

                using var command = new OracleCommand(query, connection);
                command.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = sessionId;

                using var reader = await command.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var expiresAt = reader.GetDateTime("ExpiresAtTime");
                    var slidingExpirationSeconds = reader.IsDBNull("SlidingExpirationInSeconds") 
                        ? (int?)null 
                        : reader.GetInt32("SlidingExpirationInSeconds");
                    var absoluteExpiration = reader.IsDBNull("AbsoluteExpiration") 
                        ? (DateTime?)null 
                        : reader.GetDateTime("AbsoluteExpiration");

                    return new SessionExpirationInfo
                    {
                        SessionId = sessionId,
                        ExpiresAtTime = expiresAt,
                        SlidingExpirationInSeconds = slidingExpirationSeconds,
                        AbsoluteExpiration = absoluteExpiration,
                        IsExpired = DateTime.UtcNow > expiresAt
                    };
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting session expiration info for session {SessionId}", sessionId);
                throw;
            }
        }

        /// <summary>
        /// Removes all expired sessions from the database
        /// </summary>
        /// <returns>Number of sessions removed</returns>
        public async Task<int> RemoveExpiredSessionsAsync()
        {
            try
            {
                using var connection = new OracleConnection(_connectionString);
                await connection.OpenAsync();

                const string deleteQuery = @"
                    DELETE FROM Sessions 
                    WHERE ExpiresAtTime <= :currentTime 
                    OR (AbsoluteExpiration IS NOT NULL AND AbsoluteExpiration <= :currentTime)";

                using var command = new OracleCommand(deleteQuery, connection);
                command.Parameters.Add(":currentTime", OracleDbType.TimeStamp).Value = DateTime.UtcNow;

                var rowsAffected = await command.ExecuteNonQueryAsync();
                _logger.LogInformation("Removed {Count} expired sessions", rowsAffected);
                
                return rowsAffected;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing expired sessions");
                throw;
            }
        }
    }

    /// <summary>
    /// Contains session expiration information
    /// </summary>
    public class SessionExpirationInfo
    {
        public string SessionId { get; set; } = string.Empty;
        public DateTime ExpiresAtTime { get; set; }
        public int? SlidingExpirationInSeconds { get; set; }
        public DateTime? AbsoluteExpiration { get; set; }
        public bool IsExpired { get; set; }

        public TimeSpan? SlidingExpiration => SlidingExpirationInSeconds.HasValue 
            ? TimeSpan.FromSeconds(SlidingExpirationInSeconds.Value) 
            : null;
    }
}