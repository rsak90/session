using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using SessionOracleMigration.Models;
using System.Data;

namespace SessionOracleMigration.Services
{
    /// <summary>
    /// Oracle-based implementation of ISessionStore for ASP.NET Core session management
    /// </summary>
    public class OracleSessionStore : ISessionStore
    {
        private readonly string _connectionString;
        private readonly ILogger<OracleSessionStore> _logger;
        private readonly TimeSpan _defaultTimeout;

        public OracleSessionStore(string connectionString, ILogger<OracleSessionStore> logger, TimeSpan defaultTimeout)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _defaultTimeout = defaultTimeout;
        }

        /// <summary>
        /// Creates a new session with the specified session ID
        /// </summary>
        public ISession Create(string sessionKey, TimeSpan idleTimeout, TimeSpan ioTimeout, Func<bool> tryEstablishSession, bool isNewSessionKey)
        {
            if (string.IsNullOrEmpty(sessionKey))
                throw new ArgumentException("Session key cannot be null or empty", nameof(sessionKey));

            var session = new OracleSession(sessionKey, this, _logger, idleTimeout);
            
            if (isNewSessionKey)
            {
                _logger.LogDebug("Creating new session with ID: {SessionId}", sessionKey);
            }

            return session;
        }

        /// <summary>
        /// Retrieves session data from Oracle database
        /// </summary>
        public async Task<Dictionary<string, string>> RetrieveAsync(string sessionId)
        {
            var sessionData = new Dictionary<string, string>();

            try
            {
                using var connection = new OracleConnection(_connectionString);
                await connection.OpenAsync();

                const string query = @"
                    SELECT SessionKey, SessionValue 
                    FROM Sessions 
                    WHERE SessionId = :sessionId AND ExpiresAtTime > :currentTime";

                using var command = new OracleCommand(query, connection);
                command.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = sessionId;
                command.Parameters.Add(":currentTime", OracleDbType.TimeStamp).Value = DateTime.UtcNow;

                using var reader = await command.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var key = reader.GetString("SessionKey");
                    var value = reader.IsDBNull("SessionValue") ? string.Empty : reader.GetString("SessionValue");
                    sessionData[key] = value;
                }

                _logger.LogDebug("Retrieved {Count} session items for session {SessionId}", sessionData.Count, sessionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving session data for session {SessionId}", sessionId);
                throw;
            }

            return sessionData;
        }

        /// <summary>
        /// Commits session changes to Oracle database
        /// </summary>
        public async Task CommitAsync(string sessionId, Dictionary<string, string> sessionData, TimeSpan timeout)
        {
            try
            {
                using var connection = new OracleConnection(_connectionString);
                await connection.OpenAsync();

                using var transaction = connection.BeginTransaction();

                try
                {
                    // Delete existing session data
                    const string deleteQuery = "DELETE FROM Sessions WHERE SessionId = :sessionId";
                    using var deleteCommand = new OracleCommand(deleteQuery, connection);
                    deleteCommand.Transaction = transaction;
                    deleteCommand.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = sessionId;
                    await deleteCommand.ExecuteNonQueryAsync();

                    // Insert updated session data
                    const string insertQuery = @"
                        INSERT INTO Sessions (SessionId, SessionKey, SessionValue, ExpiresAtTime, SlidingExpirationInSeconds)
                        VALUES (:sessionId, :sessionKey, :sessionValue, :expiresAt, :slidingExpiration)";

                    var expiresAt = DateTime.UtcNow.Add(timeout);
                    var slidingExpirationSeconds = (int)timeout.TotalSeconds;

                    foreach (var kvp in sessionData)
                    {
                        using var insertCommand = new OracleCommand(insertQuery, connection);
                        insertCommand.Transaction = transaction;
                        insertCommand.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = sessionId;
                        insertCommand.Parameters.Add(":sessionKey", OracleDbType.NVarchar2).Value = kvp.Key;
                        insertCommand.Parameters.Add(":sessionValue", OracleDbType.NClob).Value = kvp.Value ?? (object)DBNull.Value;
                        insertCommand.Parameters.Add(":expiresAt", OracleDbType.TimeStamp).Value = expiresAt;
                        insertCommand.Parameters.Add(":slidingExpiration", OracleDbType.Int32).Value = slidingExpirationSeconds;
                        
                        await insertCommand.ExecuteNonQueryAsync();
                    }

                    await transaction.CommitAsync();
                    _logger.LogDebug("Committed {Count} session items for session {SessionId}", sessionData.Count, sessionId);
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error committing session data for session {SessionId}", sessionId);
                throw;
            }
        }

        /// <summary>
        /// Removes expired sessions from Oracle database
        /// </summary>
        public async Task RemoveAsync(string sessionId)
        {
            try
            {
                using var connection = new OracleConnection(_connectionString);
                await connection.OpenAsync();

                const string deleteQuery = "DELETE FROM Sessions WHERE SessionId = :sessionId";
                using var command = new OracleCommand(deleteQuery, connection);
                command.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = sessionId;
                
                var rowsAffected = await command.ExecuteNonQueryAsync();
                _logger.LogDebug("Removed session {SessionId}, rows affected: {RowsAffected}", sessionId, rowsAffected);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing session {SessionId}", sessionId);
                throw;
            }
        }

        /// <summary>
        /// Cleans up expired sessions from the database
        /// </summary>
        public async Task CleanupExpiredSessionsAsync()
        {
            try
            {
                using var connection = new OracleConnection(_connectionString);
                await connection.OpenAsync();

                const string deleteQuery = "DELETE FROM Sessions WHERE ExpiresAtTime <= :currentTime";
                using var command = new OracleCommand(deleteQuery, connection);
                command.Parameters.Add(":currentTime", OracleDbType.TimeStamp).Value = DateTime.UtcNow;
                
                var rowsAffected = await command.ExecuteNonQueryAsync();
                _logger.LogInformation("Cleaned up {RowsAffected} expired sessions", rowsAffected);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error cleaning up expired sessions");
                throw;
            }
        }
    }
}