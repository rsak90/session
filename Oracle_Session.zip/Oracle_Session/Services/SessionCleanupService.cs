using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;

namespace SessionOracleMigration.Services
{
    /// <summary>
    /// Background service that periodically cleans up expired sessions from Oracle database
    /// </summary>
    public class SessionCleanupService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<SessionCleanupService> _logger;
        private readonly TimeSpan _cleanupInterval;

        public SessionCleanupService(
            IServiceProvider serviceProvider, 
            ILogger<SessionCleanupService> logger,
            IConfiguration configuration)
        {
            _serviceProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            
            var cleanupIntervalMinutes = configuration.GetValue<int>("SessionConfiguration:CleanupIntervalMinutes", 30);
            _cleanupInterval = TimeSpan.FromMinutes(cleanupIntervalMinutes);
        }

        /// <summary>
        /// Executes the background cleanup task
        /// </summary>
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Session cleanup service started with interval: {Interval} minutes", _cleanupInterval.TotalMinutes);

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await CleanupExpiredSessionsAsync();
                    await Task.Delay(_cleanupInterval, stoppingToken);
                }
                catch (OperationCanceledException)
                {
                    // Expected when cancellation is requested
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error occurred during session cleanup");
                    
                    // Wait a shorter interval before retrying on error
                    try
                    {
                        await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                }
            }

            _logger.LogInformation("Session cleanup service stopped");
        }

        /// <summary>
        /// Performs the actual cleanup of expired sessions
        /// </summary>
        private async Task CleanupExpiredSessionsAsync()
        {
            try
            {
                using var scope = _serviceProvider.CreateScope();
                var sessionStore = scope.ServiceProvider.GetRequiredService<ISessionStore>();
                
                if (sessionStore is OracleSessionStore oracleStore)
                {
                    await oracleStore.CleanupExpiredSessionsAsync();
                    _logger.LogDebug("Session cleanup completed successfully");
                }
                else
                {
                    _logger.LogWarning("Session store is not an Oracle session store, skipping cleanup");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to cleanup expired sessions");
                throw;
            }
        }

        /// <summary>
        /// Handles service stopping
        /// </summary>
        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Session cleanup service is stopping");
            await base.StopAsync(cancellationToken);
        }
    }
}