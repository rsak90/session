using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.Text;

namespace SessionOracleMigration.Services
{
    /// <summary>
    /// Oracle-based implementation of ISession for ASP.NET Core session management
    /// </summary>
    public class OracleSession : ISession
    {
        private readonly string _sessionId;
        private readonly OracleSessionStore _store;
        private readonly ILogger _logger;
        private readonly TimeSpan _idleTimeout;
        private readonly ConcurrentDictionary<string, string> _sessionData;
        private readonly ConcurrentDictionary<string, string> _originalData;
        private bool _isLoaded;
        private bool _isModified;
        private readonly object _loadLock = new object();

        public OracleSession(string sessionId, OracleSessionStore store, ILogger logger, TimeSpan idleTimeout)
        {
            _sessionId = sessionId ?? throw new ArgumentNullException(nameof(sessionId));
            _store = store ?? throw new ArgumentNullException(nameof(store));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _idleTimeout = idleTimeout;
            _sessionData = new ConcurrentDictionary<string, string>();
            _originalData = new ConcurrentDictionary<string, string>();
            _isLoaded = false;
            _isModified = false;
        }

        public string Id => _sessionId;

        public bool IsAvailable => true;

        public IEnumerable<string> Keys => _sessionData.Keys;

        /// <summary>
        /// Loads session data from Oracle database if not already loaded
        /// </summary>
        public async Task LoadAsync(CancellationToken cancellationToken = default)
        {
            if (_isLoaded) return;

            lock (_loadLock)
            {
                if (_isLoaded) return;

                try
                {
                    var data = _store.RetrieveAsync(_sessionId).GetAwaiter().GetResult();
                    
                    _sessionData.Clear();
                    _originalData.Clear();
                    
                    foreach (var kvp in data)
                    {
                        _sessionData[kvp.Key] = kvp.Value;
                        _originalData[kvp.Key] = kvp.Value;
                    }

                    _isLoaded = true;
                    _logger.LogDebug("Loaded session data for session {SessionId} with {Count} items", _sessionId, data.Count);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error loading session data for session {SessionId}", _sessionId);
                    throw;
                }
            }
        }

        /// <summary>
        /// Commits session changes to Oracle database
        /// </summary>
        public async Task CommitAsync(CancellationToken cancellationToken = default)
        {
            if (!_isLoaded || !_isModified) return;

            try
            {
                var dataToCommit = new Dictionary<string, string>(_sessionData);
                await _store.CommitAsync(_sessionId, dataToCommit, _idleTimeout);
                
                // Update original data to reflect committed state
                _originalData.Clear();
                foreach (var kvp in _sessionData)
                {
                    _originalData[kvp.Key] = kvp.Value;
                }
                
                _isModified = false;
                _logger.LogDebug("Committed session changes for session {SessionId}", _sessionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error committing session data for session {SessionId}", _sessionId);
                throw;
            }
        }

        /// <summary>
        /// Gets a string value from the session
        /// </summary>
        public string? GetString(string key)
        {
            if (string.IsNullOrEmpty(key))
                throw new ArgumentException("Key cannot be null or empty", nameof(key));

            EnsureLoaded();
            _sessionData.TryGetValue(key, out var value);
            return value;
        }

        /// <summary>
        /// Sets a string value in the session
        /// </summary>
        public void SetString(string key, string value)
        {
            if (string.IsNullOrEmpty(key))
                throw new ArgumentException("Key cannot be null or empty", nameof(key));

            EnsureLoaded();
            
            var oldValue = _sessionData.TryGetValue(key, out var existing) ? existing : null;
            _sessionData[key] = value ?? string.Empty;
            
            if (oldValue != value)
            {
                _isModified = true;
                _logger.LogDebug("Set session value for key {Key} in session {SessionId}", key, _sessionId);
            }
        }

        /// <summary>
        /// Gets a byte array value from the session
        /// </summary>
        public bool TryGetValue(string key, out byte[] value)
        {
            if (string.IsNullOrEmpty(key))
                throw new ArgumentException("Key cannot be null or empty", nameof(key));

            EnsureLoaded();
            
            if (_sessionData.TryGetValue(key, out var stringValue) && !string.IsNullOrEmpty(stringValue))
            {
                try
                {
                    value = Convert.FromBase64String(stringValue);
                    return true;
                }
                catch (FormatException)
                {
                    // If it's not base64, treat as UTF-8 string
                    value = Encoding.UTF8.GetBytes(stringValue);
                    return true;
                }
            }

            value = Array.Empty<byte>();
            return false;
        }

        /// <summary>
        /// Sets a byte array value in the session
        /// </summary>
        public void Set(string key, byte[] value)
        {
            if (string.IsNullOrEmpty(key))
                throw new ArgumentException("Key cannot be null or empty", nameof(key));

            EnsureLoaded();
            
            var stringValue = value != null ? Convert.ToBase64String(value) : string.Empty;
            var oldValue = _sessionData.TryGetValue(key, out var existing) ? existing : null;
            _sessionData[key] = stringValue;
            
            if (oldValue != stringValue)
            {
                _isModified = true;
                _logger.LogDebug("Set session byte array for key {Key} in session {SessionId}", key, _sessionId);
            }
        }

        /// <summary>
        /// Gets an integer value from the session
        /// </summary>
        public int? GetInt32(string key)
        {
            var stringValue = GetString(key);
            return int.TryParse(stringValue, out var intValue) ? intValue : null;
        }

        /// <summary>
        /// Sets an integer value in the session
        /// </summary>
        public void SetInt32(string key, int value)
        {
            SetString(key, value.ToString());
        }

        /// <summary>
        /// Removes a value from the session
        /// </summary>
        public void Remove(string key)
        {
            if (string.IsNullOrEmpty(key))
                throw new ArgumentException("Key cannot be null or empty", nameof(key));

            EnsureLoaded();
            
            if (_sessionData.TryRemove(key, out var removedValue))
            {
                _isModified = true;
                _logger.LogDebug("Removed session value for key {Key} in session {SessionId}", key, _sessionId);
            }
        }

        /// <summary>
        /// Clears all session data
        /// </summary>
        public void Clear()
        {
            EnsureLoaded();
            
            if (_sessionData.Count > 0)
            {
                _sessionData.Clear();
                _isModified = true;
                _logger.LogDebug("Cleared all session data for session {SessionId}", _sessionId);
            }
        }

        /// <summary>
        /// Ensures session data is loaded from the database
        /// </summary>
        private void EnsureLoaded()
        {
            if (!_isLoaded)
            {
                LoadAsync().GetAwaiter().GetResult();
            }
        }
    }
}