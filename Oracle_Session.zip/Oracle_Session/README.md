# Oracle Session Migration POC

This is a proof of concept (POC) for migrating ASP.NET MVC application session management from InProc (in-memory) storage to Oracle database persistence.

## Overview

The POC demonstrates:
- Oracle-based session storage maintaining ISession interface compatibility
- Existing Authorization attribute functionality with Oracle sessions
- JavaScript AJAX validation service integration
- 120-minute session timeout with sliding expiration
- Background session cleanup service
- Comprehensive testing suite

## Prerequisites

- .NET 6.0 or later
- Oracle Database (11g or later)
- Oracle.ManagedDataAccess.Core NuGet package

## Database Setup

1. Run the SQL script to create the Sessions table:
```sql
-- Execute the script in Database/CreateSessionsTable.sql
CREATE TABLE Sessions (
    SessionId NVARCHAR2(449) PRIMARY KEY,
    SessionKey NVARCHAR2(200) NOT NULL,
    SessionValue NCLOB,
    ExpiresAtTime TIMESTAMP NOT NULL,
    SlidingExpirationInSeconds NUMBER,
    AbsoluteExpiration TIMESTAMP
);

CREATE INDEX IX_Sessions_ExpiresAtTime ON Sessions (ExpiresAtTime);
CREATE INDEX IX_Sessions_SessionId_Key ON Sessions (SessionId, SessionKey);
```

2. Update the connection string in `appsettings.json`:
```json
{
  "ConnectionStrings": {
    "OracleConnection": "Data Source=your_server:1521/XE;User Id=your_username;Password=your_password;Connection Timeout=30;"
  }
}
```

## Configuration

The application supports the following configuration options in `appsettings.json`:

```json
{
  "SessionConfiguration": {
    "TimeoutMinutes": 120,
    "CleanupIntervalMinutes": 30
  }
}
```

- `TimeoutMinutes`: Session timeout duration (default: 120 minutes)
- `CleanupIntervalMinutes`: Background cleanup interval (default: 30 minutes)

## Key Components

### 1. Oracle Session Store (`OracleSessionStore`)
- Implements `ISessionStore` interface
- Handles session creation, retrieval, and cleanup
- Manages Oracle database connections and transactions

### 2. Oracle Session (`OracleSession`)
- Implements `ISession` interface
- Provides GetString, SetString, Remove, Clear methods
- Maintains session state and change tracking

### 3. Authorization Attribute (`AuthorizationAttribute`)
- Custom authorization attribute compatible with Oracle sessions
- Uses same session variable names as InProc implementation
- Provides helper methods for session management

### 4. Session Cleanup Service (`SessionCleanupService`)
- Background service for cleaning expired sessions
- Configurable cleanup interval
- Automatic retry on failures

### 5. JavaScript Validation Service
- Login validation service for AJAX calls
- Periodic session status checking
- Automatic redirect on session expiration

## Testing the POC

### 1. Basic Functionality Test

1. Start the application
2. Navigate to the Home page
3. Click "Go to Login" and enter any username/password
4. Verify you're redirected to the Dashboard (protected page)
5. Check that session data is displayed correctly

### 2. Authorization Attribute Test

1. Try accessing `/Home/Dashboard` without logging in
2. Verify you're redirected to the login page
3. After login, verify the Authorization attribute allows access
4. Test logout functionality

### 3. AJAX Integration Test

1. Navigate to `/Home/SessionTest`
2. Use the manual AJAX test buttons:
   - Test IsLoginRequired
   - Get Current User
   - Validate Session
3. Run the performance test (10 concurrent requests)

### 4. Session Timeout Test

1. Navigate to `/SessionTest/TimeoutTest`
2. Create a test session with 1-minute timeout
3. Use "Start Auto-Test" to monitor session expiration
4. Verify session expires after the specified timeout
5. Test manual cleanup functionality

### 5. Session Variables Test

The POC maintains compatibility with these session variables:
- `SessionVariables.IsAuthorized`
- `SessionVariables.UserId`
- `SessionVariables.AspNetUsersId`
- `SessionVariables.RoleId`
- `SessionVariables.ExternalConfig`
- `SessionVariables.IsDashboardVisited`

## Architecture Benefits

### Minimal Code Changes
- Existing Authorization attributes require no changes
- JavaScript validation code remains unchanged
- Controller methods maintain same signatures
- Session variable names and formats preserved

### Oracle-Specific Features
- Connection pooling for performance
- Proper transaction management
- Efficient indexing for session queries
- Sliding expiration support

### Performance Considerations
- In-memory caching for session data
- Efficient database queries with proper indexing
- Background cleanup to prevent database bloat
- Connection pooling for scalability

## Monitoring and Logging

The POC includes comprehensive logging:
- Session creation and retrieval operations
- Database connection issues
- Session expiration and cleanup activities
- Performance metrics for AJAX calls

Log levels can be configured in `appsettings.json`:
```json
{
  "Logging": {
    "LogLevel": {
      "SessionOracleMigration.Services": "Debug"
    }
  }
}
```

## Production Considerations

Before deploying to production:

1. **Security**: Review connection string security and encryption
2. **Performance**: Test under expected load conditions
3. **Monitoring**: Set up database and application monitoring
4. **Backup**: Ensure session data backup strategy if needed
5. **Cleanup**: Verify background cleanup service performance
6. **Connection Pooling**: Configure Oracle connection pooling appropriately

## Troubleshooting

### Common Issues

1. **Oracle Connection Errors**
   - Verify connection string format
   - Check Oracle service availability
   - Validate user permissions

2. **Session Not Persisting**
   - Check if Sessions table exists
   - Verify table permissions
   - Review application logs for errors

3. **Performance Issues**
   - Check database indexes
   - Monitor connection pool usage
   - Review cleanup service frequency

### Debug Mode

Enable debug logging to troubleshoot issues:
```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Debug",
      "SessionOracleMigration": "Debug"
    }
  }
}
```

## Next Steps

This POC validates the feasibility of migrating to Oracle session storage. For full implementation:

1. Add comprehensive error handling
2. Implement session encryption if required
3. Add performance monitoring and metrics
4. Create deployment scripts and documentation
5. Conduct load testing with realistic user volumes
6. Implement session data migration from existing InProc sessions