# Design Document

## Overview

This design outlines a simple POC for migrating ASP.NET MVC session management from InProc to Oracle database storage. The solution maintains the existing code structure and ISession interface while replacing the underlying storage mechanism with Oracle database persistence.

## Architecture

The POC follows a minimal modification approach:

1. **Custom Session Store Provider**: Implements ISessionStore to handle Oracle database operations
2. **Oracle Session Table**: Simple table structure to store session key-value pairs
3. **Session Configuration**: Updates to Startup.cs to use Oracle instead of InProc
4. **Existing Components**: Authorization attributes and JavaScript validation remain unchanged

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   MVC Views     │    │   Controllers    │    │ Authorization   │
│   (jQuery)      │────│   (IsLoginReq)   │────│   Attribute     │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                                │                        │
                                │                        │
                                ▼                        ▼
                       ┌──────────────────────────────────────┐
                       │          ISession Interface          │
                       └──────────────────────────────────────┘
                                        │
                                        ▼
                       ┌──────────────────────────────────────┐
                       │      Oracle Session Store           │
                       │   (Custom ISessionStore impl)       │
                       └──────────────────────────────────────┘
                                        │
                                        ▼
                       ┌──────────────────────────────────────┐
                       │         Oracle Database             │
                       │      (Sessions Table)               │
                       └──────────────────────────────────────┘
```

## Components and Interfaces

### 1. Oracle Session Store Implementation

**OracleSessionStore** class implementing ISessionStore:
- Handles session creation, retrieval, and cleanup
- Manages Oracle database connections
- Implements session timeout logic (120 minutes)
- Provides thread-safe operations

**Key Methods:**
- `CreateAsync()`: Creates new session in Oracle
- `RetrieveAsync()`: Retrieves session data from Oracle
- `CommitAsync()`: Saves session changes to Oracle
- `RemoveAsync()`: Deletes expired sessions

### 2. Oracle Session Data Model

**OracleSession** class implementing ISession:
- Wraps session data operations
- Maintains in-memory cache for performance
- Handles serialization/deserialization of session values
- Tracks changes for efficient database updates

### 3. Database Schema

**Sessions Table Structure:**
```sql
CREATE TABLE Sessions (
    SessionId NVARCHAR2(449) PRIMARY KEY,
    SessionKey NVARCHAR2(200) NOT NULL,
    SessionValue NCLOB,
    ExpiresAtTime TIMESTAMP NOT NULL,
    SlidingExpirationInSeconds NUMBER,
    AbsoluteExpiration TIMESTAMP,
    INDEX IX_Sessions_ExpiresAtTime (ExpiresAtTime)
);
```

### 4. Configuration Updates

**Startup.cs modifications:**
- Replace `services.AddSession()` with Oracle configuration
- Configure Oracle connection string
- Set session timeout to 120 minutes
- Enable session middleware

## Data Models

### Session Storage Model
```csharp
public class SessionRecord
{
    public string SessionId { get; set; }
    public string SessionKey { get; set; }
    public string SessionValue { get; set; }
    public DateTimeOffset ExpiresAtTime { get; set; }
    public int? SlidingExpirationInSeconds { get; set; }
    public DateTimeOffset? AbsoluteExpiration { get; set; }
}
```

### Session Data Structure
The POC maintains the existing session key structure:
- `SessionVariables.AspNetUsersId`
- `SessionVariables.ExternalConfig`
- `IsAuthorized`
- `RoleId`
- `UserId`
- `IsDashboardVisited`

## Error Handling

### Database Connection Failures
- Implement retry logic for transient Oracle connection issues
- Fallback to in-memory session for critical operations
- Log connection failures for monitoring

### Session Corruption
- Validate session data format during retrieval
- Handle malformed session data gracefully
- Clear corrupted sessions and force re-authentication

### Timeout Handling
- Background cleanup process for expired sessions
- Graceful handling of expired session access
- Proper cleanup of database resources

## Testing Strategy

### Unit Tests
1. **OracleSessionStore Tests**
   - Session creation and retrieval
   - Session expiration logic
   - Error handling scenarios
   - Concurrent access patterns

2. **OracleSession Tests**
   - Key-value operations (GetString, SetString)
   - Session state management
   - Serialization/deserialization

### Integration Tests
1. **Authorization Attribute Integration**
   - Session setting during authentication
   - Session retrieval during authorization
   - Session timeout behavior

2. **Controller Integration**
   - IsLoginRequired method with Oracle sessions
   - AJAX response format validation
   - Session state consistency

3. **Database Integration**
   - Oracle connection and query execution
   - Session cleanup operations
   - Performance under load

### Performance Tests
1. **Session Operations**
   - Measure session read/write performance
   - Compare with InProc baseline
   - Validate 120-minute timeout behavior

2. **Concurrent Access**
   - Multiple users accessing sessions
   - Session data consistency
   - Database connection pooling

## Implementation Notes

### Minimal Code Changes
- Existing Authorization attributes require no changes
- JavaScript validation code remains unchanged
- Controller methods maintain same signatures
- Session variable names and formats preserved

### Oracle-Specific Considerations
- Use Oracle.ManagedDataAccess.Core NuGet package
- Configure connection pooling for performance
- Handle Oracle-specific data type mappings
- Implement proper transaction management

### Development Approach
1. Create Oracle session table
2. Implement OracleSessionStore class
3. Update Startup.cs configuration
4. Add comprehensive tests
5. Validate with existing Authorization flow
6. Test IsLoginRequired JavaScript integration