# Implementation Plan

- [x] 1. Set up Oracle database schema and connection


  - Create Oracle Sessions table with proper indexes
  - Add Oracle connection string to configuration
  - Install Oracle.ManagedDataAccess.Core NuGet package
  - _Requirements: 1.1, 1.4_



- [ ] 2. Implement Oracle session store infrastructure
  - [ ] 2.1 Create SessionRecord data model class
    - Define properties for SessionId, SessionKey, SessionValue, ExpiresAtTime


    - Add serialization attributes for Oracle data mapping
    - _Requirements: 1.1, 1.4_

  - [-] 2.2 Implement OracleSessionStore class

    - Create class implementing ISessionStore interface
    - Implement CreateAsync, RetrieveAsync, CommitAsync, RemoveAsync methods
    - Add Oracle database connection and query logic
    - _Requirements: 1.1, 1.2, 1.5_

  - [x] 2.3 Implement OracleSession class

    - Create class implementing ISession interface
    - Implement GetString, SetString, Remove, Clear methods
    - Add session state tracking and change detection
    - _Requirements: 2.1, 2.2, 2.4_

- [x] 3. Configure session middleware for Oracle


  - [ ] 3.1 Update Startup.cs configuration
    - Replace AddSession with Oracle session configuration
    - Configure 120-minute session timeout
    - Add Oracle connection string configuration


    - _Requirements: 1.5, 2.1_

  - [ ] 3.2 Create session configuration extension methods
    - Add AddOracleSession extension method for IServiceCollection


    - Configure session options and Oracle connection
    - _Requirements: 1.1, 1.5_



- [ ] 4. Implement session cleanup and maintenance
  - [ ] 4.1 Create background session cleanup service
    - Implement IHostedService for expired session cleanup
    - Add periodic cleanup of expired Oracle session records
    - _Requirements: 1.5, 2.5_

  - [ ] 4.2 Add session expiration logic
    - Implement sliding expiration for 120-minute timeout
    - Handle absolute expiration scenarios
    - _Requirements: 1.5, 2.5_

- [ ] 5. Create comprehensive test suite
  - [ ] 5.1 Create unit tests for OracleSessionStore
    - Test session creation, retrieval, and deletion
    - Test session expiration and cleanup logic
    - Test error handling for database connection failures
    - _Requirements: 4.1, 4.3_

  - [ ] 5.2 Create unit tests for OracleSession
    - Test GetString and SetString operations
    - Test session state management and change tracking
    - Test session timeout behavior
    - _Requirements: 4.1, 4.2_

  - [ ] 5.3 Create integration tests for Authorization flow
    - Test Authorization attribute with Oracle sessions
    - Test session setting and retrieval during authentication
    - Test session persistence across requests
    - _Requirements: 4.4, 2.1, 2.2_



  - [ ] 5.4 Create integration tests for IsLoginRequired controller
    - Test IsLoginRequired method with Oracle session data
    - Test AJAX response format and timing


    - Test session state consistency in controller methods
    - _Requirements: 4.5, 3.1, 3.2_

- [x] 6. Validate existing functionality integration



  - [ ] 6.1 Test Authorization attribute compatibility
    - Verify existing Authorization attribute works with Oracle sessions
    - Test session variable setting (IsAuthorized, RoleId, UserId)
    - Validate session key formats (SessionVariables.ExternalConfig, AspNetUsersId)
    - _Requirements: 2.1, 2.2, 2.3_

  - [ ] 6.2 Test IsLoginRequired controller method
    - Verify IsLoginRequired method retrieves Oracle session data correctly
    - Test JSON response format matches existing implementation
    - Validate JavaScript AJAX integration continues working
    - _Requirements: 3.1, 3.2, 3.4_

  - [ ] 6.3 Validate session timeout and cleanup
    - Test 120-minute session timeout functionality
    - Verify expired sessions are cleaned up from Oracle
    - Test session renewal on user activity
    - _Requirements: 1.5, 2.5, 3.3_