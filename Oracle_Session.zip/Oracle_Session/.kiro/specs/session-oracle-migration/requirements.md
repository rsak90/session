# Requirements Document

## Introduction

This document outlines the requirements for a simple POC to migrate the ASP.NET MVC application's session management from InProc (in-memory) storage to Oracle database persistence. The POC will maintain the existing code structure and demonstrate basic session storage and retrieval functionality with Oracle.

## Glossary

- **Session_Store**: Oracle database table for storing session data
- **Authorization_Attribute**: Existing custom ASP.NET attribute that validates user sessions
- **Login_Validation_Service**: Existing JavaScript service that validates user login status via AJAX calls
- **Session_Data**: User authentication information including IsAuthorized, RoleId, UserId, IsDashboardVisited

## Requirements

### Requirement 1

**User Story:** As a developer, I want to demonstrate session storage in Oracle database, so that I can validate the feasibility of migrating from InProc sessions.

#### Acceptance Criteria

1. WHEN a user logs into the application, THE Session_Store SHALL store session data in Oracle database
2. WHEN session data is requested, THE Session_Store SHALL retrieve data from Oracle database
3. THE Session_Store SHALL maintain the same ISession interface as the current InProc implementation
4. THE Session_Store SHALL store session data as key-value pairs in Oracle
5. THE Session_Store SHALL support session timeout of 120 minutes

### Requirement 2

**User Story:** As a developer, I want the existing Authorization_Attribute to work unchanged, so that the POC requires minimal code modifications.

#### Acceptance Criteria

1. WHEN the Authorization_Attribute calls ISession.SetString, THE Session_Store SHALL store the data in Oracle
2. WHEN the Authorization_Attribute calls ISession.GetString, THE Session_Store SHALL retrieve the data from Oracle
3. THE Session_Store SHALL maintain existing session key formats like SessionVariables.ExternalConfig and SessionVariables.AspNetUsersId
4. THE Session_Store SHALL return null for non-existent session keys, matching current behavior
5. THE Session_Store SHALL handle session expiration by removing expired records from Oracle

### Requirement 3

**User Story:** As a developer, I want the IsLoginRequired controller method to continue working, so that the existing JavaScript validation remains functional.

#### Acceptance Criteria

1. WHEN the IsLoginRequired method executes, THE Session_Store SHALL provide session data from Oracle
2. THE Session_Store SHALL return session values in the same format as the current InProc implementation
3. WHEN the JavaScript Login_Validation_Service makes AJAX calls, THE Session_Store SHALL support the same response timing
4. THE Session_Store SHALL maintain session state across multiple requests
5. THE Session_Store SHALL handle concurrent session access without data corruption

### Requirement 4

**User Story:** As a developer, I want to validate the Oracle session implementation with tests, so that I can ensure the POC works correctly.

#### Acceptance Criteria

1. THE Session_Store SHALL include unit tests for session creation and retrieval
2. THE Session_Store SHALL include tests for session expiration after 120 minutes
3. THE Session_Store SHALL include tests for handling non-existent sessions
4. THE Session_Store SHALL include integration tests with the Authorization_Attribute
5. THE Session_Store SHALL include tests for the IsLoginRequired controller method functionality