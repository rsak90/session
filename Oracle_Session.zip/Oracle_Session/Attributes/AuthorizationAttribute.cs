using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using SessionOracleMigration.Models;

namespace SessionOracleMigration.Attributes
{
    /// <summary>
    /// Custom authorization attribute that validates user sessions using Oracle-based session storage
    /// This maintains compatibility with the existing InProc session implementation
    /// </summary>
    public class AuthorizationAttribute : ActionFilterAttribute
    {
        private readonly bool _requireAuthorization;

        public AuthorizationAttribute(bool requireAuthorization = true)
        {
            _requireAuthorization = requireAuthorization;
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (!_requireAuthorization)
            {
                base.OnActionExecuting(context);
                return;
            }

            var session = context.HttpContext.Session;
            
            // Check if user is authorized using the same session keys as before
            var isAuthorized = session.GetString(SessionVariables.IsAuthorized);
            var userId = session.GetString(SessionVariables.UserId);
            var aspNetUsersId = session.GetString(SessionVariables.AspNetUsersId);

            // Validate session data - same logic as InProc implementation
            if (string.IsNullOrEmpty(isAuthorized) || 
                isAuthorized.ToLower() != "true" ||
                string.IsNullOrEmpty(userId) ||
                string.IsNullOrEmpty(aspNetUsersId))
            {
                // User is not authorized, redirect to login
                context.Result = new RedirectToActionResult("Login", "Account", null);
                return;
            }

            // Optional: Update session activity timestamp for sliding expiration
            // This is handled automatically by the Oracle session store
            
            base.OnActionExecuting(context);
        }

        /// <summary>
        /// Sets user session data after successful authentication
        /// Maintains the same session variable structure as the InProc implementation
        /// </summary>
        /// <param name="session">The HTTP session</param>
        /// <param name="userId">User ID</param>
        /// <param name="aspNetUsersId">ASP.NET Users ID</param>
        /// <param name="roleId">User role ID</param>
        /// <param name="externalConfig">External configuration data</param>
        public static void SetUserSession(ISession session, string userId, string aspNetUsersId, 
            string? roleId = null, string? externalConfig = null)
        {
            if (session == null)
                throw new ArgumentNullException(nameof(session));

            // Set the same session variables as the InProc implementation
            session.SetString(SessionVariables.IsAuthorized, "true");
            session.SetString(SessionVariables.UserId, userId ?? string.Empty);
            session.SetString(SessionVariables.AspNetUsersId, aspNetUsersId ?? string.Empty);
            
            if (!string.IsNullOrEmpty(roleId))
            {
                session.SetString(SessionVariables.RoleId, roleId);
            }

            if (!string.IsNullOrEmpty(externalConfig))
            {
                session.SetString(SessionVariables.ExternalConfig, externalConfig);
            }

            // Initialize dashboard visited flag
            session.SetString(SessionVariables.IsDashboardVisited, "false");
        }

        /// <summary>
        /// Clears user session data on logout
        /// </summary>
        /// <param name="session">The HTTP session</param>
        public static void ClearUserSession(ISession session)
        {
            if (session == null)
                throw new ArgumentNullException(nameof(session));

            // Remove all session variables
            session.Remove(SessionVariables.IsAuthorized);
            session.Remove(SessionVariables.UserId);
            session.Remove(SessionVariables.AspNetUsersId);
            session.Remove(SessionVariables.RoleId);
            session.Remove(SessionVariables.ExternalConfig);
            session.Remove(SessionVariables.IsDashboardVisited);
        }

        /// <summary>
        /// Gets the current user ID from session
        /// </summary>
        /// <param name="session">The HTTP session</param>
        /// <returns>User ID or null if not found</returns>
        public static string? GetCurrentUserId(ISession session)
        {
            return session?.GetString(SessionVariables.UserId);
        }

        /// <summary>
        /// Gets the current ASP.NET Users ID from session
        /// </summary>
        /// <param name="session">The HTTP session</param>
        /// <returns>ASP.NET Users ID or null if not found</returns>
        public static string? GetCurrentAspNetUsersId(ISession session)
        {
            return session?.GetString(SessionVariables.AspNetUsersId);
        }

        /// <summary>
        /// Checks if the current user is authorized
        /// </summary>
        /// <param name="session">The HTTP session</param>
        /// <returns>True if authorized, false otherwise</returns>
        public static bool IsUserAuthorized(ISession session)
        {
            var isAuthorized = session?.GetString(SessionVariables.IsAuthorized);
            return !string.IsNullOrEmpty(isAuthorized) && isAuthorized.ToLower() == "true";
        }
    }
}