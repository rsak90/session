using Microsoft.AspNetCore.Mvc;
using SessionOracleMigration.Attributes;
using SessionOracleMigration.Models;

namespace SessionOracleMigration.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Public home page - no authorization required
        /// </summary>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Protected dashboard - requires authorization
        /// Tests the Authorization attribute with Oracle session storage
        /// </summary>
        [Authorization]
        public IActionResult Dashboard()
        {
            var userId = AuthorizationAttribute.GetCurrentUserId(HttpContext.Session);
            var aspNetUsersId = AuthorizationAttribute.GetCurrentAspNetUsersId(HttpContext.Session);
            
            ViewBag.UserId = userId;
            ViewBag.AspNetUsersId = aspNetUsersId;
            ViewBag.SessionId = HttpContext.Session.Id;

            // Mark dashboard as visited
            HttpContext.Session.SetString(SessionVariables.IsDashboardVisited, "true");

            return View();
        }

        /// <summary>
        /// Login page
        /// </summary>
        public IActionResult Login()
        {
            return View();
        }

        /// <summary>
        /// Handles login POST request
        /// Tests setting session data that will be stored in Oracle
        /// </summary>
        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            // Simple validation for POC - in real app, validate against database
            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
            {
                // Simulate successful authentication
                var userId = "user_" + username;
                var aspNetUsersId = Guid.NewGuid().ToString();
                var roleId = "1"; // Default role
                var externalConfig = "config_data_for_" + username;

                // Set session data using the Authorization attribute helper
                // This will be stored in Oracle database
                AuthorizationAttribute.SetUserSession(
                    HttpContext.Session, 
                    userId, 
                    aspNetUsersId, 
                    roleId, 
                    externalConfig);

                _logger.LogInformation("User {Username} logged in successfully. Session ID: {SessionId}", 
                    username, HttpContext.Session.Id);

                return RedirectToAction("Dashboard");
            }

            ViewBag.Error = "Invalid username or password";
            return View();
        }

        /// <summary>
        /// Handles logout
        /// Tests clearing session data from Oracle
        /// </summary>
        public IActionResult Logout()
        {
            var sessionId = HttpContext.Session.Id;
            
            // Clear session data
            AuthorizationAttribute.ClearUserSession(HttpContext.Session);
            
            _logger.LogInformation("User logged out. Session ID: {SessionId}", sessionId);

            return RedirectToAction("Index");
        }

        /// <summary>
        /// AJAX endpoint to check login status
        /// Tests the IsLoginRequired functionality with Oracle sessions
        /// </summary>
        [HttpGet]
        public IActionResult IsLoginRequired()
        {
            var isAuthorized = AuthorizationAttribute.IsUserAuthorized(HttpContext.Session);
            var userId = AuthorizationAttribute.GetCurrentUserId(HttpContext.Session);
            var isDashboardVisited = HttpContext.Session.GetString(SessionVariables.IsDashboardVisited) == "true";

            var response = new
            {
                IsLoginRequired = !isAuthorized,
                IsAuthorized = isAuthorized,
                UserId = userId,
                IsDashboardVisited = isDashboardVisited,
                SessionId = HttpContext.Session.Id
            };

            _logger.LogDebug("IsLoginRequired called. Response: {@Response}", response);

            return Json(response);
        }

        /// <summary>
        /// Test endpoint to validate session data persistence
        /// </summary>
        [Authorization]
        public IActionResult SessionTest()
        {
            var sessionData = new
            {
                SessionId = HttpContext.Session.Id,
                IsAuthorized = HttpContext.Session.GetString(SessionVariables.IsAuthorized),
                UserId = HttpContext.Session.GetString(SessionVariables.UserId),
                AspNetUsersId = HttpContext.Session.GetString(SessionVariables.AspNetUsersId),
                RoleId = HttpContext.Session.GetString(SessionVariables.RoleId),
                ExternalConfig = HttpContext.Session.GetString(SessionVariables.ExternalConfig),
                IsDashboardVisited = HttpContext.Session.GetString(SessionVariables.IsDashboardVisited)
            };

            return Json(sessionData);
        }
    }
}