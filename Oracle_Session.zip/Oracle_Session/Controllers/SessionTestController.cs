using Microsoft.AspNetCore.Mvc;
using SessionOracleMigration.Services;
using SessionOracleMigration.Attributes;
using SessionOracleMigration.Models;

namespace SessionOracleMigration.Controllers
{
    /// <summary>
    /// Controller for testing session timeout and cleanup functionality
    /// </summary>
    public class SessionTestController : Controller
    {
        private readonly ILogger<SessionTestController> _logger;
        private readonly ISessionStore _sessionStore;
        private readonly IConfiguration _configuration;

        public SessionTestController(
            ILogger<SessionTestController> logger, 
            ISessionStore sessionStore,
            IConfiguration configuration)
        {
            _logger = logger;
            _sessionStore = sessionStore;
            _configuration = configuration;
        }

        /// <summary>
        /// Test page for session timeout and cleanup functionality
        /// </summary>
        public IActionResult TimeoutTest()
        {
            var sessionTimeoutMinutes = _configuration.GetValue<int>("SessionConfiguration:TimeoutMinutes", 120);
            var cleanupIntervalMinutes = _configuration.GetValue<int>("SessionConfiguration:CleanupIntervalMinutes", 30);
            
            ViewBag.SessionTimeoutMinutes = sessionTimeoutMinutes;
            ViewBag.CleanupIntervalMinutes = cleanupIntervalMinutes;
            ViewBag.CurrentSessionId = HttpContext.Session.Id;
            
            return View();
        }

        /// <summary>
        /// Creates a test session with custom timeout for testing
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> CreateTestSession(int timeoutMinutes = 1)
        {
            try
            {
                // Create a test session with short timeout for testing
                var testSessionId = "test_" + Guid.NewGuid().ToString("N")[..8];
                var testUserId = "test_user_" + DateTime.Now.Ticks;
                
                // Set session data
                HttpContext.Session.SetString(SessionVariables.IsAuthorized, "true");
                HttpContext.Session.SetString(SessionVariables.UserId, testUserId);
                HttpContext.Session.SetString(SessionVariables.AspNetUsersId, Guid.NewGuid().ToString());
                HttpContext.Session.SetString("TestSessionId", testSessionId);
                HttpContext.Session.SetString("CreatedAt", DateTime.UtcNow.ToString("O"));
                HttpContext.Session.SetString("TimeoutMinutes", timeoutMinutes.ToString());

                // Commit the session
                await HttpContext.Session.CommitAsync();

                var result = new
                {
                    Success = true,
                    SessionId = HttpContext.Session.Id,
                    TestSessionId = testSessionId,
                    UserId = testUserId,
                    TimeoutMinutes = timeoutMinutes,
                    CreatedAt = DateTime.UtcNow,
                    ExpiresAt = DateTime.UtcNow.AddMinutes(timeoutMinutes)
                };

                _logger.LogInformation("Created test session {TestSessionId} with {TimeoutMinutes} minute timeout", 
                    testSessionId, timeoutMinutes);

                return Json(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating test session");
                return Json(new { Success = false, Error = ex.Message });
            }
        }

        /// <summary>
        /// Checks if the current session is still valid
        /// </summary>
        [HttpGet]
        public IActionResult CheckSessionValidity()
        {
            try
            {
                var sessionId = HttpContext.Session.Id;
                var isAuthorized = HttpContext.Session.GetString(SessionVariables.IsAuthorized);
                var userId = HttpContext.Session.GetString(SessionVariables.UserId);
                var testSessionId = HttpContext.Session.GetString("TestSessionId");
                var createdAt = HttpContext.Session.GetString("CreatedAt");
                var timeoutMinutes = HttpContext.Session.GetString("TimeoutMinutes");

                var result = new
                {
                    SessionId = sessionId,
                    IsValid = !string.IsNullOrEmpty(isAuthorized) && isAuthorized == "true",
                    IsAuthorized = isAuthorized,
                    UserId = userId,
                    TestSessionId = testSessionId,
                    CreatedAt = createdAt,
                    TimeoutMinutes = timeoutMinutes,
                    CheckedAt = DateTime.UtcNow
                };

                return Json(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking session validity");
                return Json(new { Error = ex.Message, CheckedAt = DateTime.UtcNow });
            }
        }

        /// <summary>
        /// Manually triggers session cleanup for testing
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> TriggerCleanup()
        {
            try
            {
                if (_sessionStore is OracleSessionStore oracleStore)
                {
                    await oracleStore.CleanupExpiredSessionsAsync();
                    
                    var result = new
                    {
                        Success = true,
                        Message = "Session cleanup triggered successfully",
                        TriggeredAt = DateTime.UtcNow
                    };

                    _logger.LogInformation("Manual session cleanup triggered");
                    return Json(result);
                }
                else
                {
                    return Json(new 
                    { 
                        Success = false, 
                        Error = "Session store is not Oracle-based",
                        TriggeredAt = DateTime.UtcNow
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error triggering session cleanup");
                return Json(new 
                { 
                    Success = false, 
                    Error = ex.Message,
                    TriggeredAt = DateTime.UtcNow
                });
            }
        }

        /// <summary>
        /// Gets session statistics from Oracle database
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetSessionStats()
        {
            try
            {
                if (_sessionStore is OracleSessionStore oracleStore)
                {
                    // This would require additional methods in OracleSessionStore
                    // For now, return basic info
                    var result = new
                    {
                        Success = true,
                        Message = "Session statistics retrieved",
                        CurrentTime = DateTime.UtcNow,
                        SessionStoreType = "Oracle",
                        Note = "Detailed statistics would require additional database queries"
                    };

                    return Json(result);
                }
                else
                {
                    return Json(new 
                    { 
                        Success = false, 
                        Error = "Session store is not Oracle-based"
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting session statistics");
                return Json(new { Success = false, Error = ex.Message });
            }
        }

        /// <summary>
        /// Tests session renewal (sliding expiration)
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> TestSessionRenewal()
        {
            try
            {
                var sessionId = HttpContext.Session.Id;
                var beforeRenewal = DateTime.UtcNow;
                
                // Access session data to trigger renewal
                var userId = HttpContext.Session.GetString(SessionVariables.UserId);
                HttpContext.Session.SetString("LastRenewal", beforeRenewal.ToString("O"));
                
                // Commit changes to trigger sliding expiration update
                await HttpContext.Session.CommitAsync();
                
                var result = new
                {
                    Success = true,
                    SessionId = sessionId,
                    UserId = userId,
                    RenewalTime = beforeRenewal,
                    Message = "Session renewal triggered (sliding expiration updated)"
                };

                _logger.LogInformation("Session renewal tested for session {SessionId}", sessionId);
                return Json(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error testing session renewal");
                return Json(new { Success = false, Error = ex.Message });
            }
        }

        /// <summary>
        /// Simulates session expiration by clearing session data
        /// </summary>
        [HttpPost]
        public IActionResult SimulateExpiration()
        {
            try
            {
                var sessionId = HttpContext.Session.Id;
                
                // Clear all session data to simulate expiration
                HttpContext.Session.Clear();
                
                var result = new
                {
                    Success = true,
                    SessionId = sessionId,
                    Message = "Session data cleared to simulate expiration",
                    ClearedAt = DateTime.UtcNow
                };

                _logger.LogInformation("Simulated session expiration for session {SessionId}", sessionId);
                return Json(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error simulating session expiration");
                return Json(new { Success = false, Error = ex.Message });
            }
        }
    }
}