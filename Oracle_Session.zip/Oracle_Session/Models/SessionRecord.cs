using System.ComponentModel.DataAnnotations;

namespace SessionOracleMigration.Models
{
    /// <summary>
    /// Data model representing a session record in the Oracle database
    /// Maps to the Sessions table structure
    /// </summary>
    public class SessionRecord
    {
        /// <summary>
        /// Unique identifier for the session
        /// </summary>
        [Key]
        [MaxLength(449)]
        public string SessionId { get; set; } = string.Empty;

        /// <summary>
        /// Session key for the stored value (e.g., "IsAuthorized", "UserId")
        /// </summary>
        [Required]
        [MaxLength(200)]
        public string SessionKey { get; set; } = string.Empty;

        /// <summary>
        /// Serialized session value stored as NCLOB in Oracle
        /// </summary>
        public string? SessionValue { get; set; }

        /// <summary>
        /// Timestamp when the session expires
        /// </summary>
        [Required]
        public DateTimeOffset ExpiresAtTime { get; set; }

        /// <summary>
        /// Sliding expiration duration in seconds (120 minutes = 7200 seconds)
        /// </summary>
        public int? SlidingExpirationInSeconds { get; set; }

        /// <summary>
        /// Absolute expiration timestamp (optional)
        /// </summary>
        public DateTimeOffset? AbsoluteExpiration { get; set; }

        /// <summary>
        /// Checks if the session record has expired
        /// </summary>
        public bool IsExpired => DateTimeOffset.UtcNow > ExpiresAtTime;

        /// <summary>
        /// Updates the expiration time based on sliding expiration
        /// </summary>
        public void UpdateExpiration()
        {
            if (SlidingExpirationInSeconds.HasValue)
            {
                ExpiresAtTime = DateTimeOffset.UtcNow.AddSeconds(SlidingExpirationInSeconds.Value);
            }
        }
    }
}