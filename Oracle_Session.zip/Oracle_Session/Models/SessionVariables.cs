namespace SessionOracleMigration.Models
{
    /// <summary>
    /// Constants for session variable keys used throughout the application
    /// </summary>
    public static class SessionVariables
    {
        public const string AspNetUsersId = "AspNetUsersId";
        public const string ExternalConfig = "ExternalConfig";
        public const string IsAuthorized = "IsAuthorized";
        public const string RoleId = "RoleId";
        public const string UserId = "UserId";
        public const string IsDashboardVisited = "IsDashboardVisited";
    }
}