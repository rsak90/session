/**
 * Login Validation Service - JavaScript service for validating user login status
 * This service maintains compatibility with the existing InProc session implementation
 * while using Oracle database session storage
 */
class LoginValidationService {
    constructor() {
        this.baseUrl = '';
        this.checkInterval = null;
        this.isLoginRequiredUrl = '/Home/IsLoginRequired';
    }

    /**
     * Checks if login is required via AJAX call
     * Returns a promise with the login status
     */
    async checkLoginStatus() {
        try {
            const response = await fetch(this.isLoginRequiredUrl, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                credentials: 'same-origin'
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            
            // Log for debugging
            console.log('Login status check result:', data);
            
            return {
                success: true,
                data: data,
                isLoginRequired: data.IsLoginRequired,
                isAuthorized: data.IsAuthorized,
                userId: data.UserId,
                isDashboardVisited: data.IsDashboardVisited,
                sessionId: data.SessionId
            };
        } catch (error) {
            console.error('Error checking login status:', error);
            return {
                success: false,
                error: error.message,
                isLoginRequired: true, // Assume login required on error for security
                isAuthorized: false
            };
        }
    }

    /**
     * Starts periodic login status checking
     * @param {number} intervalMs - Check interval in milliseconds (default: 5 minutes)
     * @param {function} callback - Callback function to handle status changes
     */
    startPeriodicCheck(intervalMs = 300000, callback = null) {
        if (this.checkInterval) {
            this.stopPeriodicCheck();
        }

        this.checkInterval = setInterval(async () => {
            const result = await this.checkLoginStatus();
            
            if (callback && typeof callback === 'function') {
                callback(result);
            }

            // If login is required, optionally redirect to login page
            if (result.isLoginRequired && result.success) {
                console.warn('Session expired, login required');
                // Uncomment the next line to auto-redirect on session expiration
                // window.location.href = '/Home/Login';
            }
        }, intervalMs);

        console.log(`Started periodic login status checking every ${intervalMs}ms`);
    }

    /**
     * Stops periodic login status checking
     */
    stopPeriodicCheck() {
        if (this.checkInterval) {
            clearInterval(this.checkInterval);
            this.checkInterval = null;
            console.log('Stopped periodic login status checking');
        }
    }

    /**
     * Validates current session and redirects to login if needed
     * @param {string} redirectUrl - URL to redirect to after login (optional)
     */
    async validateSessionOrRedirect(redirectUrl = null) {
        const result = await this.checkLoginStatus();
        
        if (result.isLoginRequired) {
            let loginUrl = '/Home/Login';
            if (redirectUrl) {
                loginUrl += `?returnUrl=${encodeURIComponent(redirectUrl)}`;
            }
            window.location.href = loginUrl;
            return false;
        }
        
        return true;
    }

    /**
     * Gets current user information from session
     */
    async getCurrentUser() {
        const result = await this.checkLoginStatus();
        
        if (result.success && !result.isLoginRequired) {
            return {
                userId: result.userId,
                sessionId: result.sessionId,
                isDashboardVisited: result.isDashboardVisited,
                isAuthorized: result.isAuthorized
            };
        }
        
        return null;
    }

    /**
     * Utility method to check if user is on a protected page
     */
    isProtectedPage() {
        const protectedPaths = ['/Home/Dashboard', '/Home/SessionTest'];
        const currentPath = window.location.pathname;
        return protectedPaths.some(path => currentPath.toLowerCase().includes(path.toLowerCase()));
    }

    /**
     * Initialize the service with automatic session validation for protected pages
     */
    async initialize() {
        console.log('Initializing Login Validation Service');
        
        // Check session status on page load for protected pages
        if (this.isProtectedPage()) {
            const isValid = await this.validateSessionOrRedirect(window.location.href);
            if (!isValid) {
                return; // Redirected to login
            }
        }

        // Start periodic checking for all pages
        this.startPeriodicCheck(300000, (result) => {
            if (result.isLoginRequired && this.isProtectedPage()) {
                console.warn('Session expired on protected page, redirecting to login');
                this.validateSessionOrRedirect(window.location.href);
            }
        });
    }
}

// Create global instance
window.loginValidationService = new LoginValidationService();

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    window.loginValidationService.initialize();
});

// jQuery compatibility for existing code
if (typeof $ !== 'undefined') {
    $(document).ready(function() {
        // Expose service methods to jQuery for backward compatibility
        $.loginValidation = {
            checkStatus: () => window.loginValidationService.checkLoginStatus(),
            validateOrRedirect: (url) => window.loginValidationService.validateSessionOrRedirect(url),
            getCurrentUser: () => window.loginValidationService.getCurrentUser()
        };
    });
}