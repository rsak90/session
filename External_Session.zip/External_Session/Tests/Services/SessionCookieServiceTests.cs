using Xunit;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using SecureSessionManagement.Services;
using SecureSessionManagement.Configuration;
using System;

namespace SecureSessionManagement.Tests.Services
{
    public class SessionCookieServiceTests
    {
        private readonly SessionCookieService _cookieService;
        private readonly SessionConfiguration _config;
        private readonly Mock<ILogger<SessionCookieService>> _mockLogger;

        public SessionCookieServiceTests()
        {
            _config = new SessionConfiguration
            {
                SessionTimeout = TimeSpan.FromMinutes(30)
            };
            _mockLogger = new Mock<ILogger<SessionCookieService>>();
            _cookieService = new SessionCookieService(Options.Create(_config), _mockLogger.Object);
        }

        [Fact]
        public void GenerateSecureSessionId_ReturnsValidFormat()
        {
            // Act
            var sessionId = SessionCookieService.GenerateSecureSessionId();

            // Assert
            sessionId.Should().NotBeNullOrEmpty();
            sessionId.Should().HaveLength(43); // Base64 without padding
            sessionId.Should().MatchRegex(@"^[A-Za-z0-9_-]+$");
        }

        [Fact]
        public void GenerateSecureSessionId_GeneratesUniqueIds()
        {
            // Arrange
            var sessionIds = new HashSet<string>();

            // Act
            for (int i = 0; i < 10000; i++)
            {
                var sessionId = SessionCookieService.GenerateSecureSessionId();
                sessionIds.Add(sessionId);
            }

            // Assert
            sessionIds.Should().HaveCount(10000); // All should be unique
        }

        [Fact]
        public void SetSessionCookie_SetsSecureAttributes()
        {
            // Arrange
            var httpContext = new DefaultHttpContext();
            var sessionId = "test-session-id";

            // Act
            _cookieService.SetSessionCookie(httpContext, sessionId);

            // Assert
            var setCookieHeader = httpContext.Response.Headers["Set-Cookie"].ToString();
            setCookieHeader.Should().Contain("HttpOnly");
            setCookieHeader.Should().Contain("Secure");
            setCookieHeader.Should().Contain("SameSite=Strict");
            setCookieHeader.Should().Contain("SessionId=" + sessionId);
        }

        [Fact]
        public void GetSessionId_ValidCookie_ReturnsSessionId()
        {
            // Arrange
            var httpContext = new DefaultHttpContext();
            var expectedSessionId = SessionCookieService.GenerateSecureSessionId();
            
            // First set the cookie
            _cookieService.SetSessionCookie(httpContext, expectedSessionId);
            
            // Create a new context with the cookie
            var requestContext = new DefaultHttpContext();
            requestContext.Request.Headers["Cookie"] = $"SessionId={expectedSessionId}";

            // Act
            var actualSessionId = _cookieService.GetSessionId(requestContext);

            // Assert
            actualSessionId.Should().Be(expectedSessionId);
        }

        [Fact]
        public void GetSessionId_NoCookie_ReturnsNull()
        {
            // Arrange
            var httpContext = new DefaultHttpContext();

            // Act
            var sessionId = _cookieService.GetSessionId(httpContext);

            // Assert
            sessionId.Should().BeNull();
        }

        [Fact]
        public void GetSessionId_InvalidFormat_ReturnsNull()
        {
            // Arrange
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers["Cookie"] = "SessionId=invalid-format-123!@#";

            // Act
            var sessionId = _cookieService.GetSessionId(httpContext);

            // Assert
            sessionId.Should().BeNull();
        }

        [Fact]
        public void RemoveSessionCookies_SetsExpiredCookies()
        {
            // Arrange
            var httpContext = new DefaultHttpContext();

            // Act
            _cookieService.RemoveSessionCookies(httpContext);

            // Assert
            var setCookieHeaders = httpContext.Response.Headers["Set-Cookie"];
            setCookieHeaders.Should().Contain(header => header.Contains("SessionId=") && header.Contains("expires="));
            setCookieHeaders.Should().Contain(header => header.Contains("SessionValidation=") && header.Contains("expires="));
        }

        [Fact]
        public void RefreshSessionCookie_UpdatesExpiration()
        {
            // Arrange
            var httpContext = new DefaultHttpContext();
            var sessionId = SessionCookieService.GenerateSecureSessionId();

            // Act
            _cookieService.RefreshSessionCookie(httpContext, sessionId);

            // Assert
            var setCookieHeader = httpContext.Response.Headers["Set-Cookie"].ToString();
            setCookieHeader.Should().Contain("SessionId=" + sessionId);
            setCookieHeader.Should().Contain("expires=");
        }

        [Fact]
        public void GetSessionCookieInfo_ValidSession_ReturnsInfo()
        {
            // Arrange
            var httpContext = new DefaultHttpContext();
            var sessionId = SessionCookieService.GenerateSecureSessionId();
            httpContext.Request.Headers["Cookie"] = $"SessionId={sessionId}";
            httpContext.Request.Headers["User-Agent"] = "Test Browser";
            httpContext.Connection.RemoteIpAddress = System.Net.IPAddress.Parse("192.168.1.1");
            httpContext.Request.IsHttps = true;

            // Act
            var info = _cookieService.GetSessionCookieInfo(httpContext);

            // Assert
            info.HasSessionCookie.Should().BeTrue();
            info.SessionId.Should().Be(sessionId);
            info.IsSecure.Should().BeTrue();
            info.UserAgent.Should().Be("Test Browser");
            info.IpAddress.Should().Be("192.168.1.1");
        }
    }
}