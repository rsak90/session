using Xunit;
using Moq;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SecureSessionManagement.Services;
using SecureSessionManagement.Configuration;
using SecureSessionManagement.Models;
using SecureSessionManagement.Stores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SecureSessionManagement.Tests.Services
{
    public class ReliableSessionManagerTests
    {
        private readonly Mock<ISessionStore> _mockRedisStore;
        private readonly Mock<ISessionStore> _mockOracleStore;
        private readonly Mock<ILogger<ReliableSessionManager>> _mockLogger;
        private readonly SessionConfiguration _config;
        private readonly ReliableSessionManager _sessionManager;

        public ReliableSessionManagerTests()
        {
            _mockRedisStore = new Mock<ISessionStore>();
            _mockOracleStore = new Mock<ISessionStore>();
            _mockLogger = new Mock<ILogger<ReliableSessionManager>>();
            
            _config = new SessionConfiguration
            {
                SessionTimeout = TimeSpan.FromMinutes(30),
                MaxRetryAttempts = 3,
                RetryDelay = TimeSpan.FromSeconds(1)
            };

            // Setup store identification
            _mockRedisStore.Setup(x => x.GetType().Name).Returns("RedisSessionStore");
            _mockOracleStore.Setup(x => x.GetType().Name).Returns("OracleSessionStore");

            var stores = new List<ISessionStore> { _mockRedisStore.Object, _mockOracleStore.Object };
            _sessionManager = new ReliableSessionManager(
                stores, 
                Options.Create(_config), 
                _mockLogger.Object);
        }

        [Fact]
        public async Task GetAsync_ValidSession_ReturnsFromRedis()
        {
            // Arrange
            var sessionId = "test-session";
            var sessionRecord = new SessionRecord
            {
                SessionId = sessionId,
                JsonPayload = """{"userId":"TEST001","roleId":"USER","isAuthorized":true,"isDashboardVisited":false,"externalConfig":"{}","createdAt":"2024-01-01T00:00:00Z","lastAccessedAt":"2024-01-01T00:00:00Z","expirationTimeout":"00:30:00"}""",
                CreatedAt = DateTime.UtcNow,
                ExpiresAt = DateTime.UtcNow.AddMinutes(30),
                LastAccessedAt = DateTime.UtcNow
            };

            _mockRedisStore.Setup(x => x.GetAsync(sessionId))
                          .ReturnsAsync(sessionRecord);

            // Act
            var result = await _sessionManager.GetAsync(sessionId);

            // Assert
            result.Should().NotBeNull();
            result!.UserId.Should().Be("TEST001");
            _mockRedisStore.Verify(x => x.GetAsync(sessionId), Times.Once);
        }

        [Fact]
        public async Task GetAsync_RedisFailsOracleSucceeds_ReturnsFromOracle()
        {
            // Arrange
            var sessionId = "test-session";
            var sessionRecord = new SessionRecord
            {
                SessionId = sessionId,
                JsonPayload = """{"userId":"TEST001","roleId":"USER","isAuthorized":true,"isDashboardVisited":false,"externalConfig":"{}","createdAt":"2024-01-01T00:00:00Z","lastAccessedAt":"2024-01-01T00:00:00Z","expirationTimeout":"00:30:00"}""",
                CreatedAt = DateTime.UtcNow,
                ExpiresAt = DateTime.UtcNow.AddMinutes(30),
                LastAccessedAt = DateTime.UtcNow
            };

            _mockRedisStore.Setup(x => x.GetAsync(sessionId))
                          .ThrowsAsync(new Exception("Redis connection failed"));
            _mockOracleStore.Setup(x => x.GetAsync(sessionId))
                           .ReturnsAsync(sessionRecord);

            // Act
            var result = await _sessionManager.GetAsync(sessionId);

            // Assert
            result.Should().NotBeNull();
            result!.UserId.Should().Be("TEST001");
            _mockOracleStore.Verify(x => x.GetAsync(sessionId), Times.Once);
        }

        [Fact]
        public async Task GetAsync_ExpiredSession_ReturnsNull()
        {
            // Arrange
            var sessionId = "expired-session";
            var expiredSessionRecord = new SessionRecord
            {
                SessionId = sessionId,
                JsonPayload = """{"userId":"TEST001","roleId":"USER","isAuthorized":true,"isDashboardVisited":false,"externalConfig":"{}","createdAt":"2024-01-01T00:00:00Z","lastAccessedAt":"2024-01-01T00:00:00Z","expirationTimeout":"00:30:00"}""",
                CreatedAt = DateTime.UtcNow.AddHours(-2),
                ExpiresAt = DateTime.UtcNow.AddHours(-1), // Expired
                LastAccessedAt = DateTime.UtcNow.AddHours(-2)
            };

            _mockRedisStore.Setup(x => x.GetAsync(sessionId))
                          .ReturnsAsync(expiredSessionRecord);

            // Act
            var result = await _sessionManager.GetAsync(sessionId);

            // Assert
            result.Should().BeNull();
            _mockRedisStore.Verify(x => x.RemoveAsync(sessionId), Times.Once);
            _mockOracleStore.Verify(x => x.RemoveAsync(sessionId), Times.Once);
        }

        [Fact]
        public async Task SetAsync_ValidSession_StoresInBothStores()
        {
            // Arrange
            var sessionId = "test-session";
            var session = new UserSession
            {
                UserId = "TEST001",
                RoleId = "USER",
                IsAuthorized = true,
                CreatedAt = DateTime.UtcNow,
                LastAccessedAt = DateTime.UtcNow
            };

            _mockRedisStore.Setup(x => x.SetAsync(It.IsAny<string>(), It.IsAny<SessionRecord>()))
                          .Returns(Task.CompletedTask);
            _mockOracleStore.Setup(x => x.SetAsync(It.IsAny<string>(), It.IsAny<SessionRecord>()))
                           .Returns(Task.CompletedTask);

            // Act
            await _sessionManager.SetAsync(sessionId, session);

            // Assert
            _mockRedisStore.Verify(x => x.SetAsync(sessionId, It.IsAny<SessionRecord>()), Times.Once);
            _mockOracleStore.Verify(x => x.SetAsync(sessionId, It.IsAny<SessionRecord>()), Times.Once);
        }

        [Fact]
        public async Task RemoveAsync_ValidSessionId_RemovesFromBothStores()
        {
            // Arrange
            var sessionId = "test-session";

            _mockRedisStore.Setup(x => x.RemoveAsync(sessionId))
                          .Returns(Task.CompletedTask);
            _mockOracleStore.Setup(x => x.RemoveAsync(sessionId))
                           .Returns(Task.CompletedTask);

            // Act
            await _sessionManager.RemoveAsync(sessionId);

            // Assert
            _mockRedisStore.Verify(x => x.RemoveAsync(sessionId), Times.Once);
            _mockOracleStore.Verify(x => x.RemoveAsync(sessionId), Times.Once);
        }

        [Fact]
        public async Task ExistsAsync_SessionExistsInRedis_ReturnsTrue()
        {
            // Arrange
            var sessionId = "test-session";
            _mockRedisStore.Setup(x => x.ExistsAsync(sessionId))
                          .ReturnsAsync(true);

            // Act
            var result = await _sessionManager.ExistsAsync(sessionId);

            // Assert
            result.Should().BeTrue();
            _mockRedisStore.Verify(x => x.ExistsAsync(sessionId), Times.Once);
        }

        [Fact]
        public async Task ExistsAsync_SessionExistsOnlyInOracle_ReturnsTrue()
        {
            // Arrange
            var sessionId = "test-session";
            _mockRedisStore.Setup(x => x.ExistsAsync(sessionId))
                          .ReturnsAsync(false);
            _mockOracleStore.Setup(x => x.ExistsAsync(sessionId))
                           .ReturnsAsync(true);

            // Act
            var result = await _sessionManager.ExistsAsync(sessionId);

            // Assert
            result.Should().BeTrue();
            _mockRedisStore.Verify(x => x.ExistsAsync(sessionId), Times.Once);
            _mockOracleStore.Verify(x => x.ExistsAsync(sessionId), Times.Once);
        }

        [Fact]
        public void GenerateSessionId_ReturnsValidFormat()
        {
            // Act
            var sessionId = ReliableSessionManager.GenerateSessionId();

            // Assert
            sessionId.Should().NotBeNullOrEmpty();
            sessionId.Should().HaveLength(43); // Base64 without padding
            sessionId.Should().MatchRegex(@"^[A-Za-z0-9_-]+$");
        }

        [Fact]
        public void GenerateSessionId_GeneratesUniqueIds()
        {
            // Arrange
            var sessionIds = new HashSet<string>();

            // Act
            for (int i = 0; i < 1000; i++)
            {
                var sessionId = ReliableSessionManager.GenerateSessionId();
                sessionIds.Add(sessionId);
            }

            // Assert
            sessionIds.Should().HaveCount(1000); // All should be unique
        }
    }
}