using System.Threading.Tasks;
using SecureSessionManagement.Models;

namespace SecureSessionManagement.Stores
{
    public interface ISessionStore
    {
        Task<SessionRecord?> GetAsync(string sessionId);
        Task SetAsync(string sessionId, SessionRecord record);
        Task RemoveAsync(string sessionId);
        Task<bool> ExistsAsync(string sessionId);
        Task CleanupExpiredAsync();
    }
}