using System;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using StackExchange.Redis;
using SecureSessionManagement.Configuration;
using SecureSessionManagement.Models;

namespace SecureSessionManagement.Stores
{
    public class RedisSessionStore : ISessionStore, IDisposable
    {
        private readonly IConnectionMultiplexer _redis;
        private readonly IDatabase _database;
        private readonly SessionConfiguration _config;
        private readonly ILogger<RedisSessionStore> _logger;
        private bool _disposed = false;

        public RedisSessionStore(
            IConnectionMultiplexer redis,
            IOptions<SessionConfiguration> config,
            ILogger<RedisSessionStore> logger)
        {
            _redis = redis;
            _database = redis.GetDatabase();
            _config = config.Value;
            _logger = logger;
        }

        public async Task<SessionRecord?> GetAsync(string sessionId)
        {
            try
            {
                var key = GetRedisKey(sessionId);
                var value = await _database.StringGetAsync(key);
                
                if (!value.HasValue)
                    return null;

                var record = JsonSerializer.Deserialize<SessionRecord>(value!, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                // Check if session is expired
                if (record != null && record.ExpiresAt <= DateTime.UtcNow)
                {
                    await RemoveAsync(sessionId);
                    return null;
                }

                return record;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting session {SessionId} from Redis", sessionId);
                throw;
            }
        }

        public async Task SetAsync(string sessionId, SessionRecord record)
        {
            try
            {
                var key = GetRedisKey(sessionId);
                var value = JsonSerializer.Serialize(record, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                var expiry = record.ExpiresAt - DateTime.UtcNow;
                if (expiry <= TimeSpan.Zero)
                {
                    _logger.LogWarning("Attempting to store expired session {SessionId}", sessionId);
                    return;
                }

                await _database.StringSetAsync(key, value, expiry);
                _logger.LogDebug("Session {SessionId} stored in Redis with expiry {Expiry}", sessionId, expiry);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error setting session {SessionId} in Redis", sessionId);
                throw;
            }
        }

        public async Task RemoveAsync(string sessionId)
        {
            try
            {
                var key = GetRedisKey(sessionId);
                await _database.KeyDeleteAsync(key);
                _logger.LogDebug("Session {SessionId} removed from Redis", sessionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing session {SessionId} from Redis", sessionId);
                throw;
            }
        }

        public async Task<bool> ExistsAsync(string sessionId)
        {
            try
            {
                var key = GetRedisKey(sessionId);
                return await _database.KeyExistsAsync(key);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking existence of session {SessionId} in Redis", sessionId);
                throw;
            }
        }

        public async Task CleanupExpiredAsync()
        {
            try
            {
                // Redis automatically handles TTL expiration, but we can scan for any orphaned keys
                var server = _redis.GetServer(_redis.GetEndPoints().First());
                var pattern = GetRedisKey("*");
                
                await foreach (var key in server.ScanAsync(pattern: pattern))
                {
                    var ttl = await _database.KeyTimeToLiveAsync(key);
                    if (!ttl.HasValue || ttl.Value <= TimeSpan.Zero)
                    {
                        await _database.KeyDeleteAsync(key);
                        _logger.LogDebug("Cleaned up expired session key: {Key}", key);
                    }
                }
                
                _logger.LogInformation("Redis session cleanup completed");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during Redis session cleanup");
                throw;
            }
        }

        private string GetRedisKey(string sessionId)
        {
            return $"session:{sessionId}";
        }

        public void Dispose()
        {
            if (!_disposed)
            {
                _redis?.Dispose();
                _disposed = true;
            }
        }
    }
}