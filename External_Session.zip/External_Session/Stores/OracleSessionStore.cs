using System;
using System.Data;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using SecureSessionManagement.Configuration;
using SecureSessionManagement.Models;

namespace SecureSessionManagement.Stores
{
    public class OracleSessionStore : ISessionStore
    {
        private readonly SessionConfiguration _config;
        private readonly ILogger<OracleSessionStore> _logger;

        public OracleSessionStore(
            IOptions<SessionConfiguration> config,
            ILogger<OracleSessionStore> logger)
        {
            _config = config.Value;
            _logger = logger;
        }

        public async Task<SessionRecord?> GetAsync(string sessionId)
        {
            try
            {
                using var connection = new OracleConnection(_config.OracleConnectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT SessionId, JsonPayload, CreatedAt, ExpiresAt, LastAccessedAt 
                    FROM UserSessions 
                    WHERE SessionId = :sessionId AND ExpiresAt > SYSDATE";

                using var command = new OracleCommand(sql, connection);
                command.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = sessionId;

                using var reader = await command.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    return new SessionRecord
                    {
                        SessionId = reader.GetString("SessionId"),
                        JsonPayload = reader.GetString("JsonPayload"),
                        CreatedAt = reader.GetDateTime("CreatedAt"),
                        ExpiresAt = reader.GetDateTime("ExpiresAt"),
                        LastAccessedAt = reader.GetDateTime("LastAccessedAt")
                    };
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting session {SessionId} from Oracle", sessionId);
                throw;
            }
        }

        public async Task SetAsync(string sessionId, SessionRecord record)
        {
            try
            {
                using var connection = new OracleConnection(_config.OracleConnectionString);
                await connection.OpenAsync();

                using var transaction = connection.BeginTransaction();
                try
                {
                    // Use MERGE to handle both insert and update
                    const string sql = @"
                        MERGE INTO UserSessions us
                        USING (SELECT :sessionId AS SessionId FROM dual) src
                        ON (us.SessionId = src.SessionId)
                        WHEN MATCHED THEN
                            UPDATE SET 
                                JsonPayload = :jsonPayload,
                                ExpiresAt = :expiresAt,
                                LastAccessedAt = :lastAccessedAt
                        WHEN NOT MATCHED THEN
                            INSERT (SessionId, JsonPayload, CreatedAt, ExpiresAt, LastAccessedAt)
                            VALUES (:sessionId, :jsonPayload, :createdAt, :expiresAt, :lastAccessedAt)";

                    using var command = new OracleCommand(sql, connection, transaction);
                    command.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = record.SessionId;
                    command.Parameters.Add(":jsonPayload", OracleDbType.Clob).Value = record.JsonPayload;
                    command.Parameters.Add(":createdAt", OracleDbType.TimeStamp).Value = record.CreatedAt;
                    command.Parameters.Add(":expiresAt", OracleDbType.TimeStamp).Value = record.ExpiresAt;
                    command.Parameters.Add(":lastAccessedAt", OracleDbType.TimeStamp).Value = record.LastAccessedAt;

                    await command.ExecuteNonQueryAsync();
                    transaction.Commit();

                    _logger.LogDebug("Session {SessionId} stored in Oracle", sessionId);
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error setting session {SessionId} in Oracle", sessionId);
                throw;
            }
        }

        public async Task RemoveAsync(string sessionId)
        {
            try
            {
                using var connection = new OracleConnection(_config.OracleConnectionString);
                await connection.OpenAsync();

                const string sql = "DELETE FROM UserSessions WHERE SessionId = :sessionId";

                using var command = new OracleCommand(sql, connection);
                command.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = sessionId;

                var rowsAffected = await command.ExecuteNonQueryAsync();
                _logger.LogDebug("Session {SessionId} removed from Oracle. Rows affected: {RowsAffected}", 
                    sessionId, rowsAffected);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing session {SessionId} from Oracle", sessionId);
                throw;
            }
        }

        public async Task<bool> ExistsAsync(string sessionId)
        {
            try
            {
                using var connection = new OracleConnection(_config.OracleConnectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT COUNT(1) 
                    FROM UserSessions 
                    WHERE SessionId = :sessionId AND ExpiresAt > SYSDATE";

                using var command = new OracleCommand(sql, connection);
                command.Parameters.Add(":sessionId", OracleDbType.NVarchar2).Value = sessionId;

                var result = await command.ExecuteScalarAsync();
                return Convert.ToInt32(result) > 0;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking existence of session {SessionId} in Oracle", sessionId);
                throw;
            }
        }

        public async Task CleanupExpiredAsync()
        {
            try
            {
                using var connection = new OracleConnection(_config.OracleConnectionString);
                await connection.OpenAsync();

                // Try to use stored procedure for optimized cleanup
                try
                {
                    using var command = new OracleCommand("CleanupExpiredSessions", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    await command.ExecuteNonQueryAsync();
                    
                    _logger.LogInformation("Oracle session cleanup completed using stored procedure");
                }
                catch (OracleException ex) when (ex.Number == 942) // Procedure doesn't exist
                {
                    _logger.LogWarning("Stored procedure not found, falling back to direct SQL cleanup");
                    
                    // Fallback to direct SQL
                    const string sql = "DELETE FROM UserSessions WHERE ExpiresAt <= SYSDATE";
                    using var command = new OracleCommand(sql, connection);
                    var rowsAffected = await command.ExecuteNonQueryAsync();
                    
                    _logger.LogInformation("Oracle session cleanup completed. Removed {RowsAffected} expired sessions", 
                        rowsAffected);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during Oracle session cleanup");
                throw;
            }
        }

        public async Task<SessionStatistics> GetSessionStatisticsAsync()
        {
            try
            {
                using var connection = new OracleConnection(_config.OracleConnectionString);
                await connection.OpenAsync();

                try
                {
                    // Try to use stored procedure
                    using var command = new OracleCommand("GetSessionStatistics", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    
                    var totalParam = new OracleParameter("p_total_sessions", OracleDbType.Int32, ParameterDirection.Output);
                    var activeParam = new OracleParameter("p_active_sessions", OracleDbType.Int32, ParameterDirection.Output);
                    var expiredParam = new OracleParameter("p_expired_sessions", OracleDbType.Int32, ParameterDirection.Output);
                    
                    command.Parameters.Add(totalParam);
                    command.Parameters.Add(activeParam);
                    command.Parameters.Add(expiredParam);
                    
                    await command.ExecuteNonQueryAsync();
                    
                    return new SessionStatistics
                    {
                        TotalSessions = Convert.ToInt32(totalParam.Value.ToString()),
                        ActiveSessions = Convert.ToInt32(activeParam.Value.ToString()),
                        ExpiredSessions = Convert.ToInt32(expiredParam.Value.ToString())
                    };
                }
                catch (OracleException ex) when (ex.Number == 942) // Procedure doesn't exist
                {
                    // Fallback to direct SQL queries
                    const string sql = @"
                        SELECT 
                            COUNT(*) as total_sessions,
                            SUM(CASE WHEN ExpiresAt > SYSDATE THEN 1 ELSE 0 END) as active_sessions,
                            SUM(CASE WHEN ExpiresAt <= SYSDATE THEN 1 ELSE 0 END) as expired_sessions
                        FROM UserSessions";
                    
                    using var command = new OracleCommand(sql, connection);
                    using var reader = await command.ExecuteReaderAsync();
                    
                    if (await reader.ReadAsync())
                    {
                        return new SessionStatistics
                        {
                            TotalSessions = reader.GetInt32("total_sessions"),
                            ActiveSessions = reader.GetInt32("active_sessions"),
                            ExpiredSessions = reader.GetInt32("expired_sessions")
                        };
                    }
                }
                
                return new SessionStatistics();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting session statistics from Oracle");
                throw;
            }
        }

        public async Task InitializeDatabaseAsync()
        {
            try
            {
                using var connection = new OracleConnection(_config.OracleConnectionString);
                await connection.OpenAsync();

                // Create table if it doesn't exist
                const string createTableSql = @"
                    BEGIN
                        EXECUTE IMMEDIATE '
                            CREATE TABLE UserSessions (
                                SessionId NVARCHAR2(128) PRIMARY KEY,
                                JsonPayload CLOB NOT NULL,
                                CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                ExpiresAt TIMESTAMP NOT NULL,
                                LastAccessedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                            )';
                    EXCEPTION
                        WHEN OTHERS THEN
                            IF SQLCODE != -955 THEN -- Table already exists
                                RAISE;
                            END IF;
                    END;";

                using var command = new OracleCommand(createTableSql, connection);
                await command.ExecuteNonQueryAsync();

                // Create indexes if they don't exist
                const string createIndexesSql = @"
                    BEGIN
                        EXECUTE IMMEDIATE 'CREATE INDEX idx_usersessions_expires_at ON UserSessions (ExpiresAt)';
                    EXCEPTION
                        WHEN OTHERS THEN
                            IF SQLCODE != -955 THEN -- Index already exists
                                RAISE;
                            END IF;
                    END;
                    
                    BEGIN
                        EXECUTE IMMEDIATE 'CREATE INDEX idx_usersessions_last_accessed ON UserSessions (LastAccessedAt)';
                    EXCEPTION
                        WHEN OTHERS THEN
                            IF SQLCODE != -955 THEN -- Index already exists
                                RAISE;
                            END IF;
                    END;";

                using var indexCommand = new OracleCommand(createIndexesSql, connection);
                await indexCommand.ExecuteNonQueryAsync();

                _logger.LogInformation("Oracle database schema initialized successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error initializing Oracle database schema");
                throw;
            }
        }
    }
}