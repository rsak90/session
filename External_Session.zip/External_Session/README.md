# Secure Session Management System

A comprehensive, secure session management solution for .NET applications that replaces InProc sessions with distributed, encrypted storage using Redis and Oracle Database.

## Features

- **Distributed Storage**: Primary Redis storage with Oracle Database fallback
- **Security**: AES-256-GCM encryption, secure cookies, session validation
- **Reliability**: Connection pooling, retry logic, automatic failover
- **Scalability**: Horizontal scaling support across multiple server instances
- **Backward Compatibility**: Legacy session adapter for gradual migration
- **Monitoring**: Session health monitoring, cleanup services, statistics

## Quick Start

### 1. Configuration

Add the following to your `appsettings.json`:

```json
{
  "SessionManagement": {
    "UseRedisStorage": true,
    "UseOracleStorage": true,
    "RedisConnectionString": "localhost:6379",
    "OracleConnectionString": "Data Source=localhost:1521/XE;User Id=session_user;Password=session_password;",
    "SessionTimeout": "00:30:00",
    "RequiredLogin": true,
    "MaxRetryAttempts": 3,
    "RetryDelay": "00:00:01"
  }
}
```

### 2. Service Registration

In your `Program.cs`:

```csharp
using SecureSessionManagement.Extensions;

var builder = WebApplication.CreateBuilder(args);

// Add secure session management
builder.Services.AddSecureSessionManagement(builder.Configuration);

var app = builder.Build();
```

### 3. Database Setup

Run the SQL scripts to create the required tables:

```sql
-- Execute Database/UserTableSchema.sql for Users table
-- Execute Database/OracleStoredProcedures.sql for optimization
```

### 4. View Integration

Include the session authentication in your layout:

```html
<!-- In your _Layout.cshtml -->
@Html.Partial("_SessionAuthLayout")
```

## Architecture

### Core Components

- **ISessionManager**: Main interface for session operations
- **ReliableSessionManager**: Implementation with dual-storage strategy
- **RedisSessionStore**: Primary storage using Redis
- **OracleSessionStore**: Fallback storage using Oracle Database
- **SessionCookieService**: Secure cookie management
- **UserAuthenticationFilter**: Authentication filter integration

### Data Flow

1. User authentication creates secure session
2. Session data stored in both Redis (primary) and Oracle (backup)
3. Client receives secure, HttpOnly cookies
4. JavaScript automatically checks session status
5. Expired sessions are cleaned up automatically

## Usage Examples

### Controller Usage

```csharp
[UserAuthentication]
public class HomeController : Controller
{
    private readonly ISessionManager _sessionManager;
    
    public async Task<IActionResult> Index()
    {
        var sessionId = HttpContext.Request.Cookies["SessionId"];
        var session = await _sessionManager.GetAsync(sessionId);
        
        if (session?.IsAuthorized == true)
        {
            // User is authenticated
            ViewBag.UserId = session.UserId;
        }
        
        return View();
    }
}
```

### JavaScript Integration

```javascript
// Check authentication status
SecureSessionAuth.checkAuthenticationStatus()
    .then(response => {
        if (response.loginRequired) {
            // Redirect to login
        } else {
            // User is authenticated
            console.log('User ID:', response.userId);
        }
    });

// Get session information
SecureSessionAuth.getSessionInfo()
    .then(info => {
        console.log('Session expires at:', info.expiresAt);
    });

// Logout
SecureSessionAuth.logout()
    .then(() => {
        window.location.href = '/Account/Login';
    });
```

### Legacy Migration

For gradual migration from existing ISession usage:

```csharp
public class LegacyController : Controller
{
    private readonly LegacySessionAdapter _legacyAdapter;
    
    public async Task<IActionResult> OldMethod()
    {
        // Old way: HttpContext.Session.GetString("UserId")
        // New way with adapter:
        var userId = await _legacyAdapter.GetStringAsync("UserId");
        
        return View();
    }
}
```

## Security Features

### Session Cookies
- HttpOnly: Prevents XSS attacks
- Secure: HTTPS only
- SameSite=Strict: CSRF protection
- Cryptographically secure session IDs

### Data Protection
- AES-256-GCM encryption for sensitive data
- HMAC validation for integrity
- Secure key management
- Session expiration enforcement

### Network Security
- TLS encryption for Redis connections
- Encrypted Oracle connections
- Connection pooling with security validation

## Monitoring and Maintenance

### Health Checks

```csharp
// Check system health
var configValidator = serviceProvider.GetService<ConfigurationValidationService>();
var result = configValidator.ValidateConfiguration();

if (!result.IsValid)
{
    // Handle configuration issues
}
```

### Session Statistics

```csharp
// Get session statistics
var oracleStore = serviceProvider.GetService<OracleSessionStore>();
var stats = await oracleStore.GetSessionStatisticsAsync();

Console.WriteLine($"Active sessions: {stats.ActiveSessions}");
Console.WriteLine($"Expired sessions: {stats.ExpiredSessions}");
```

### Migration Tools

Administrative endpoints for session migration:

- `GET /admin/SessionMigration/readiness` - Check migration readiness
- `POST /admin/SessionMigration/backup` - Create backup
- `POST /admin/SessionMigration/start` - Start migration
- `POST /admin/SessionMigration/validate/{sessionId}` - Validate session

## Configuration Options

### Session Management
- `UseRedisStorage`: Enable Redis storage (default: true)
- `UseOracleStorage`: Enable Oracle storage (default: true)
- `SessionTimeout`: Session expiration time (default: 30 minutes)
- `RequiredLogin`: Whether login is required (default: true)
- `MaxRetryAttempts`: Connection retry attempts (default: 3)

### User Integration
- `UserTableName`: Name of users table (default: "Users")
- `EnableUserCaching`: Cache user lookups (default: true)
- `UserCacheExpiration`: Cache expiration time (default: 15 minutes)
- `UpdateLastLoginDate`: Update login timestamps (default: true)

## Performance Considerations

### Redis Optimization
- Connection pooling reduces overhead
- TTL-based expiration for automatic cleanup
- Cluster support for high availability

### Oracle Optimization
- Stored procedures for batch operations
- Indexes on frequently queried columns
- Connection pooling and transaction management

### Memory Management
- External storage eliminates memory pressure
- Automatic cleanup prevents storage overflow
- Efficient serialization with JSON

## Troubleshooting

### Common Issues

1. **Redis Connection Failed**
   - Check connection string format
   - Verify Redis server is running
   - Check firewall settings

2. **Oracle Connection Issues**
   - Verify connection string parameters
   - Check database permissions
   - Ensure required tables exist

3. **Session Not Found**
   - Check cookie settings
   - Verify session hasn't expired
   - Check storage connectivity

### Logging

Enable detailed logging in `appsettings.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "SecureSessionManagement": "Debug"
    }
  }
}
```

## Contributing

1. Follow the existing code patterns
2. Add unit tests for new features
3. Update documentation
4. Ensure backward compatibility

## License

This project is licensed under the MIT License.