using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using StackExchange.Redis;
using SecureSessionManagement.Configuration;
using SecureSessionManagement.Services;
using SecureSessionManagement.Stores;
using SecureSessionManagement.Repositories;

namespace SecureSessionManagement.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddSecureSessionManagement(this IServiceCollection services, IConfiguration configuration)
        {
            // Configure session options
            services.Configure<SessionConfiguration>(configuration.GetSection("SessionManagement"));
            services.Configure<UserIntegrationConfiguration>(configuration.GetSection("UserIntegration"));
            
            // Register configuration validation
            services.AddSingleton<ConfigurationValidationService>();
            
            // Register Redis connection
            services.AddSingleton<RedisConnectionService>();
            services.AddSingleton<IConnectionMultiplexer>(provider =>
            {
                var redisService = provider.GetRequiredService<RedisConnectionService>();
                return redisService.GetConnection();
            });
            
            // Register core services
            services.AddScoped<ISessionManager, ReliableSessionManager>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<SessionCookieService>();
            services.AddScoped<SessionValidationService>();
            
            // Register repositories
            services.AddScoped<IUserRepository, UserRepository>();
            
            // Register session stores
            services.AddScoped<ISessionStore, RedisSessionStore>();
            services.AddScoped<ISessionStore, OracleSessionStore>();
            
            // Register background services
            services.AddHostedService<SessionCleanupService>();
            
            // Register migration and compatibility services (only if legacy compatibility is enabled)
            services.AddScoped<LegacySessionAdapter>();
            services.AddScoped<SessionMigrationService>();
            
            // Register HttpContextAccessor for legacy adapter
            services.AddHttpContextAccessor();
            
            return services;
        }
    }
}