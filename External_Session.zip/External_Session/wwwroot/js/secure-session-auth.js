/**
 * Secure Session Authentication JavaScript Library
 * Handles client-side authentication state management and automatic redirects
 */

(function(window, $) {
    'use strict';

    // Configuration
    const CONFIG = {
        endpoints: {
            isLoginRequired: '/Common/IsLoginRequired',
            sessionInfo: '/Common/SessionInfo',
            logout: '/Common/Logout'
        },
        loginPageUrl: '/Account/Login',
        sessionWarningThreshold: 5, // minutes before expiration to show warning
        checkInterval: 60000, // Check session every minute (60 seconds)
        retryAttempts: 3,
        retryDelay: 1000 // 1 second
    };

    // Session state
    let sessionState = {
        isAuthenticated: false,
        sessionId: null,
        userId: null,
        lastCheck: null,
        warningShown: false,
        checkTimer: null
    };

    /**
     * Main authentication check function
     * Called on page load and periodically
     */
    function checkAuthenticationStatus() {
        return makeAjaxCall(CONFIG.endpoints.isLoginRequired, 'GET')
            .then(function(response) {
                handleAuthenticationResponse(response);
                return response;
            })
            .catch(function(error) {
                console.error('Authentication check failed:', error);
                handleAuthenticationError(error);
                throw error;
            });
    }

    /**
     * Handle authentication response from server
     */
    function handleAuthenticationResponse(response) {
        sessionState.lastCheck = new Date();

        if (response.loginRequired === true) {
            handleLoginRequired(response);
        } else {
            handleValidSession(response);
        }
    }

    /**
     * Handle case where login is required
     */
    function handleLoginRequired(response) {
        console.log('Login required:', response.reason || 'Unknown reason');
        
        // Store current URL for post-login redirect
        storeReturnUrl();
        
        // Clear any existing session state
        clearSessionState();
        
        // Show user-friendly message based on error code
        showLoginRequiredMessage(response);
        
        // Redirect to login page
        redirectToLogin();
    }

    /**
     * Handle valid session response
     */
    function handleValidSession(response) {
        sessionState.isAuthenticated = true;
        sessionState.sessionId = response.sessionId;
        sessionState.userId = response.userId;
        sessionState.warningShown = false;

        // Check if session is near expiration
        if (response.nearExpiration && response.timeUntilExpiration) {
            handleNearExpiration(response.timeUntilExpiration);
        }

        // Trigger custom event for other scripts
        triggerEvent('sessionValidated', {
            sessionId: response.sessionId,
            userId: response.userId,
            timeUntilExpiration: response.timeUntilExpiration
        });
    }

    /**
     * Handle session near expiration
     */
    function handleNearExpiration(minutesUntilExpiration) {
        if (minutesUntilExpiration <= CONFIG.sessionWarningThreshold && !sessionState.warningShown) {
            showSessionWarning(minutesUntilExpiration);
            sessionState.warningShown = true;
        }
    }

    /**
     * Show session expiration warning
     */
    function showSessionWarning(minutesUntilExpiration) {
        const message = `Your session will expire in ${Math.ceil(minutesUntilExpiration)} minutes. ` +
                       'Please save your work and refresh the page to extend your session.';
        
        // Try to use a notification system if available
        if (typeof showNotification === 'function') {
            showNotification(message, 'warning');
        } else if (typeof toastr !== 'undefined') {
            toastr.warning(message, 'Session Warning');
        } else {
            // Fallback to alert
            alert(message);
        }

        // Trigger custom event
        triggerEvent('sessionWarning', { minutesUntilExpiration: minutesUntilExpiration });
    }

    /**
     * Show login required message
     */
    function showLoginRequiredMessage(response) {
        let message = 'Please log in to continue.';
        
        switch (response.errorCode) {
            case 'SESSION_EXPIRED':
                message = 'Your session has expired. Please log in again.';
                break;
            case 'SESSION_NOT_AUTHORIZED':
                message = 'Your session is not authorized. Please log in again.';
                break;
            case 'SESSION_TOO_OLD':
                message = 'Your session has exceeded the maximum lifetime. Please log in again.';
                break;
            case 'SYSTEM_ERROR':
                message = 'A system error occurred. Please try logging in again.';
                break;
        }

        // Show message if notification system is available
        if (typeof showNotification === 'function') {
            showNotification(message, 'info');
        } else if (typeof toastr !== 'undefined') {
            toastr.info(message, 'Authentication Required');
        }
    }

    /**
     * Store current URL for post-login redirect
     */
    function storeReturnUrl() {
        try {
            const returnUrl = window.location.href;
            sessionStorage.setItem('returnUrl', returnUrl);
            console.log('Return URL stored:', returnUrl);
        } catch (e) {
            console.warn('Could not store return URL:', e);
        }
    }

    /**
     * Clear session state
     */
    function clearSessionState() {
        sessionState.isAuthenticated = false;
        sessionState.sessionId = null;
        sessionState.userId = null;
        sessionState.warningShown = false;
    }

    /**
     * Redirect to login page
     */
    function redirectToLogin() {
        const returnUrl = encodeURIComponent(window.location.href);
        const loginUrl = `${CONFIG.loginPageUrl}?returnUrl=${returnUrl}`;
        
        console.log('Redirecting to login:', loginUrl);
        window.location.href = loginUrl;
    }

    /**
     * Handle authentication errors
     */
    function handleAuthenticationError(error) {
        console.error('Authentication error:', error);
        
        // On network errors, assume login is required for security
        if (error.status === 0 || error.status >= 500) {
            console.log('Network or server error, redirecting to login for security');
            storeReturnUrl();
            redirectToLogin();
        }
    }

    /**
     * Make AJAX call with retry logic
     */
    function makeAjaxCall(url, method, data, attempt) {
        attempt = attempt || 1;
        
        const ajaxOptions = {
            url: url,
            type: method || 'GET',
            dataType: 'json',
            timeout: 10000, // 10 second timeout
            cache: false
        };

        if (data) {
            ajaxOptions.data = data;
        }

        return $.ajax(ajaxOptions)
            .fail(function(xhr, textStatus, errorThrown) {
                if (attempt < CONFIG.retryAttempts && (textStatus === 'timeout' || xhr.status >= 500)) {
                    console.log(`Retry attempt ${attempt + 1} for ${url}`);
                    return new Promise(function(resolve) {
                        setTimeout(function() {
                            resolve(makeAjaxCall(url, method, data, attempt + 1));
                        }, CONFIG.retryDelay * attempt);
                    });
                }
                throw {
                    status: xhr.status,
                    statusText: xhr.statusText,
                    textStatus: textStatus,
                    errorThrown: errorThrown
                };
            });
    }

    /**
     * Get current session information
     */
    function getSessionInfo() {
        return makeAjaxCall(CONFIG.endpoints.sessionInfo, 'GET');
    }

    /**
     * Logout current user
     */
    function logout() {
        return makeAjaxCall(CONFIG.endpoints.logout, 'POST')
            .then(function(response) {
                clearSessionState();
                triggerEvent('userLoggedOut', response);
                return response;
            });
    }

    /**
     * Start periodic session checking
     */
    function startSessionMonitoring() {
        if (sessionState.checkTimer) {
            clearInterval(sessionState.checkTimer);
        }

        sessionState.checkTimer = setInterval(function() {
            checkAuthenticationStatus().catch(function(error) {
                console.error('Periodic session check failed:', error);
            });
        }, CONFIG.checkInterval);

        console.log('Session monitoring started');
    }

    /**
     * Stop periodic session checking
     */
    function stopSessionMonitoring() {
        if (sessionState.checkTimer) {
            clearInterval(sessionState.checkTimer);
            sessionState.checkTimer = null;
        }
        console.log('Session monitoring stopped');
    }

    /**
     * Trigger custom events
     */
    function triggerEvent(eventName, data) {
        try {
            const event = new CustomEvent(eventName, { detail: data });
            window.dispatchEvent(event);
        } catch (e) {
            console.warn('Could not trigger event:', eventName, e);
        }
    }

    /**
     * Initialize authentication system
     */
    function initialize() {
        console.log('Secure Session Authentication initialized');
        
        // Check authentication status immediately
        checkAuthenticationStatus()
            .then(function() {
                // Start monitoring if session is valid
                if (sessionState.isAuthenticated) {
                    startSessionMonitoring();
                }
            })
            .catch(function(error) {
                console.error('Initial authentication check failed:', error);
            });

        // Handle page visibility changes
        if (typeof document.addEventListener === 'function') {
            document.addEventListener('visibilitychange', function() {
                if (!document.hidden && sessionState.isAuthenticated) {
                    // Check session when page becomes visible
                    checkAuthenticationStatus();
                }
            });
        }

        // Handle beforeunload to clean up
        window.addEventListener('beforeunload', function() {
            stopSessionMonitoring();
        });
    }

    // Public API
    window.SecureSessionAuth = {
        checkAuthenticationStatus: checkAuthenticationStatus,
        getSessionInfo: getSessionInfo,
        logout: logout,
        startMonitoring: startSessionMonitoring,
        stopMonitoring: stopSessionMonitoring,
        getSessionState: function() { return Object.assign({}, sessionState); },
        configure: function(options) {
            Object.assign(CONFIG, options);
        }
    };

    // Legacy compatibility - expose IsLoginRequired function
    window.IsLoginRequired = checkAuthenticationStatus;

    // Auto-initialize when DOM is ready
    $(document).ready(function() {
        initialize();
    });

})(window, jQuery);