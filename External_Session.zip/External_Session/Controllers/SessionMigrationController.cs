using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SecureSessionManagement.Services;

namespace SecureSessionManagement.Controllers
{
    /// <summary>
    /// Administrative controller for session migration operations
    /// Should be secured and only accessible to administrators
    /// </summary>
    [ApiController]
    [Route("admin/[controller]")]
    [Authorize(Roles = "Administrator")] // Adjust authorization as needed
    public class SessionMigrationController : ControllerBase
    {
        private readonly SessionMigrationService _migrationService;
        private readonly ILogger<SessionMigrationController> _logger;

        public SessionMigrationController(
            SessionMigrationService migrationService,
            ILogger<SessionMigrationController> logger)
        {
            _migrationService = migrationService;
            _logger = logger;
        }

        /// <summary>
        /// Checks if the system is ready for migration
        /// </summary>
        [HttpGet("readiness")]
        public async Task<IActionResult> CheckReadiness()
        {
            try
            {
                var readiness = await _migrationService.CheckMigrationReadinessAsync();
                return Ok(readiness);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking migration readiness");
                return StatusCode(500, new { error = "Error checking migration readiness" });
            }
        }

        /// <summary>
        /// Gets the current migration progress
        /// </summary>
        [HttpGet("progress")]
        public async Task<IActionResult> GetProgress()
        {
            try
            {
                var progress = await _migrationService.GetMigrationProgressAsync();
                return Ok(progress);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting migration progress");
                return StatusCode(500, new { error = "Error getting migration progress" });
            }
        }

        /// <summary>
        /// Creates a backup of existing session data
        /// </summary>
        [HttpPost("backup")]
        public async Task<IActionResult> CreateBackup([FromBody] BackupRequest request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.BackupPath))
                {
                    return BadRequest(new { error = "Backup path is required" });
                }

                var success = await _migrationService.CreateBackupAsync(request.BackupPath);
                
                if (success)
                {
                    return Ok(new { message = "Backup created successfully", path = request.BackupPath });
                }
                else
                {
                    return StatusCode(500, new { error = "Failed to create backup" });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating backup");
                return StatusCode(500, new { error = "Error creating backup" });
            }
        }

        /// <summary>
        /// Starts the migration process
        /// </summary>
        [HttpPost("start")]
        public async Task<IActionResult> StartMigration()
        {
            try
            {
                _logger.LogInformation("Migration started by user: {User}", User.Identity?.Name);
                
                var result = await _migrationService.MigrateAllSessionsAsync();
                
                if (result.IsSuccess)
                {
                    return Ok(new
                    {
                        message = "Migration completed successfully",
                        totalSessions = result.TotalSessions,
                        successful = result.SuccessfulMigrations,
                        failed = result.FailedMigrations,
                        duration = result.Duration.TotalMinutes
                    });
                }
                else
                {
                    return StatusCode(500, new
                    {
                        error = "Migration failed",
                        message = result.ErrorMessage,
                        totalSessions = result.TotalSessions,
                        successful = result.SuccessfulMigrations,
                        failed = result.FailedMigrations
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during migration");
                return StatusCode(500, new { error = "Error during migration" });
            }
        }

        /// <summary>
        /// Validates a migrated session
        /// </summary>
        [HttpPost("validate/{sessionId}")]
        public async Task<IActionResult> ValidateSession(string sessionId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(sessionId))
                {
                    return BadRequest(new { error = "Session ID is required" });
                }

                var validation = await _migrationService.ValidateMigrationAsync(sessionId);
                return Ok(validation);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating session {SessionId}", sessionId);
                return StatusCode(500, new { error = "Error validating session" });
            }
        }

        /// <summary>
        /// Rolls back a migrated session
        /// </summary>
        [HttpPost("rollback/{sessionId}")]
        public async Task<IActionResult> RollbackSession(string sessionId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(sessionId))
                {
                    return BadRequest(new { error = "Session ID is required" });
                }

                _logger.LogWarning("Session rollback initiated by user: {User} for session: {SessionId}", 
                    User.Identity?.Name, sessionId);

                var success = await _migrationService.RollbackSessionAsync(sessionId);
                
                if (success)
                {
                    return Ok(new { message = "Session rolled back successfully" });
                }
                else
                {
                    return StatusCode(500, new { error = "Failed to rollback session" });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error rolling back session {SessionId}", sessionId);
                return StatusCode(500, new { error = "Error rolling back session" });
            }
        }

        /// <summary>
        /// Restores session data from backup
        /// </summary>
        [HttpPost("restore")]
        public async Task<IActionResult> RestoreFromBackup([FromBody] RestoreRequest request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.BackupPath))
                {
                    return BadRequest(new { error = "Backup path is required" });
                }

                _logger.LogWarning("Session restore initiated by user: {User} from backup: {BackupPath}", 
                    User.Identity?.Name, request.BackupPath);

                var success = await _migrationService.RestoreFromBackupAsync(request.BackupPath);
                
                if (success)
                {
                    return Ok(new { message = "Data restored successfully from backup" });
                }
                else
                {
                    return StatusCode(500, new { error = "Failed to restore from backup" });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error restoring from backup");
                return StatusCode(500, new { error = "Error restoring from backup" });
            }
        }
    }

    public class BackupRequest
    {
        public string BackupPath { get; set; } = string.Empty;
    }

    public class RestoreRequest
    {
        public string BackupPath { get; set; } = string.Empty;
    }
}