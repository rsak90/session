using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SecureSessionManagement.Configuration;
using SecureSessionManagement.Services;

namespace SecureSessionManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CommonController : ControllerBase
    {
        private readonly ISessionManager _sessionManager;
        private readonly SessionCookieService _cookieService;
        private readonly SessionValidationService _validationService;
        private readonly SessionConfiguration _config;
        private readonly ILogger<CommonController> _logger;

        public CommonController(
            ISessionManager sessionManager,
            SessionCookieService cookieService,
            SessionValidationService validationService,
            IOptions<SessionConfiguration> config,
            ILogger<CommonController> logger)
        {
            _sessionManager = sessionManager;
            _cookieService = cookieService;
            _validationService = validationService;
            _config = config.Value;
            _logger = logger;
        }

        /// <summary>
        /// Checks if login is required for the current user session
        /// </summary>
        /// <returns>JSON result indicating whether login is required</returns>
        [HttpGet("IsLoginRequired")]
        public async Task<JsonResult> IsLoginRequired()
        {
            try
            {
                // Get session ID from secure cookie
                var sessionId = _cookieService.GetSessionId(HttpContext);
                
                if (string.IsNullOrEmpty(sessionId))
                {
                    _logger.LogDebug("No session ID found, login required");
                    return Json(new { 
                        loginRequired = true, 
                        reason = "No session",
                        errorCode = "NO_SESSION"
                    });
                }

                // Validate and refresh session
                var validationResult = await _validationService.ValidateAndRefreshSessionAsync(_sessionManager, sessionId);
                
                if (!validationResult.IsValid)
                {
                    _logger.LogDebug("Session validation failed for ID: {SessionId}, reason: {Reason}", 
                        sessionId, validationResult.ErrorMessage);
                    
                    // Clean up invalid session cookie
                    _cookieService.RemoveSessionCookies(HttpContext);
                    
                    return Json(new { 
                        loginRequired = true, 
                        reason = validationResult.ErrorMessage,
                        errorCode = validationResult.ErrorCode,
                        expiredAt = validationResult.ExpiredAt
                    });
                }

                var session = validationResult.Session!;

                // Check for bypass conditions
                bool bypassLogin = _validationService.ShouldBypassLogin(session);
                
                // Determine if login is required
                bool loginRequired = _config.RequiredLogin && !bypassLogin;

                if (!loginRequired && validationResult.WasRefreshed)
                {
                    // Refresh session cookie since session was updated
                    _cookieService.RefreshSessionCookie(HttpContext, sessionId);
                }

                var response = new
                {
                    loginRequired = loginRequired,
                    sessionId = sessionId,
                    userId = session.UserId,
                    lastAccessed = session.LastAccessedAt,
                    nearExpiration = validationResult.NearExpiration,
                    timeUntilExpiration = validationResult.TimeUntilExpiration?.TotalMinutes
                };

                _logger.LogDebug("Login required check for session {SessionId}: {LoginRequired}", 
                    sessionId, loginRequired);

                return Json(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking login requirement");
                
                // On error, assume login is required for security
                return Json(new { 
                    loginRequired = true, 
                    reason = "System error",
                    errorCode = "SYSTEM_ERROR"
                });
            }
        }

        /// <summary>
        /// Gets current session information
        /// </summary>
        /// <returns>JSON result with session details</returns>
        [HttpGet("SessionInfo")]
        public async Task<JsonResult> GetSessionInfo()
        {
            try
            {
                var sessionId = _cookieService.GetSessionId(HttpContext);
                
                if (string.IsNullOrEmpty(sessionId))
                {
                    return Json(new { hasSession = false });
                }

                var session = await _sessionManager.GetAsync(sessionId);
                
                if (session == null)
                {
                    _cookieService.RemoveSessionCookies(HttpContext);
                    return Json(new { hasSession = false });
                }

                return Json(new
                {
                    hasSession = true,
                    sessionId = sessionId,
                    userId = session.UserId,
                    roleId = session.RoleId,
                    isAuthorized = session.IsAuthorized,
                    isDashboardVisited = session.IsDashboardVisited,
                    createdAt = session.CreatedAt,
                    lastAccessedAt = session.LastAccessedAt,
                    expiresAt = session.LastAccessedAt.Add(session.ExpirationTimeout)
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting session info");
                return Json(new { hasSession = false, error = "System error" });
            }
        }

        /// <summary>
        /// Logs out the current user by removing their session
        /// </summary>
        /// <returns>JSON result indicating logout success</returns>
        [HttpPost("Logout")]
        public async Task<JsonResult> Logout()
        {
            try
            {
                var sessionId = _cookieService.GetSessionId(HttpContext);
                
                if (!string.IsNullOrEmpty(sessionId))
                {
                    await _sessionManager.RemoveAsync(sessionId);
                    _logger.LogInformation("User session removed: {SessionId}", sessionId);
                }

                _cookieService.RemoveSessionCookies(HttpContext);
                
                return Json(new { success = true, message = "Logged out successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during logout");
                
                // Still remove cookies even if session removal failed
                _cookieService.RemoveSessionCookies(HttpContext);
                
                return Json(new { success = true, message = "Logged out (with errors)" });
            }
        }

        /// <summary>
        /// Updates dashboard visited flag for current session
        /// </summary>
        /// <returns>JSON result indicating update success</returns>
        [HttpPost("MarkDashboardVisited")]
        public async Task<JsonResult> MarkDashboardVisited()
        {
            try
            {
                var sessionId = _cookieService.GetSessionId(HttpContext);
                
                if (string.IsNullOrEmpty(sessionId))
                {
                    return Json(new { success = false, message = "No active session" });
                }

                var session = await _sessionManager.GetAsync(sessionId);
                
                if (session == null)
                {
                    return Json(new { success = false, message = "Session not found" });
                }

                session.IsDashboardVisited = true;
                session.LastAccessedAt = DateTime.UtcNow;
                
                await _sessionManager.SetAsync(sessionId, session);
                
                return Json(new { success = true, message = "Dashboard visit recorded" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error marking dashboard as visited");
                return Json(new { success = false, message = "System error" });
            }
        }

        private bool CheckBypassConditions(string externalConfig)
        {
            // Implement your bypass logic based on external configuration
            // This is a placeholder implementation
            
            if (string.IsNullOrEmpty(externalConfig))
            {
                return false;
            }

            try
            {
                // Example: Parse JSON config and check for bypass flags
                // var config = JsonSerializer.Deserialize<Dictionary<string, object>>(externalConfig);
                // return config.ContainsKey("bypassLogin") && (bool)config["bypassLogin"];
                
                // For now, return false (no bypass)
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error parsing external config for bypass conditions");
                return false;
            }
        }
    }
}