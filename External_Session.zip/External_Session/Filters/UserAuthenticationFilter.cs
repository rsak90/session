using System;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SecureSessionManagement.Configuration;
using SecureSessionManagement.Models;
using SecureSessionManagement.Services;

namespace SecureSessionManagement.Filters
{
    public class UserAuthenticationFilter : IAsyncAuthorizationFilter
    {
        private readonly ISessionManager _sessionManager;
        private readonly IUserService _userService;
        private readonly SessionCookieService _cookieService;
        private readonly SessionConfiguration _config;
        private readonly ILogger<UserAuthenticationFilter> _logger;

        public UserAuthenticationFilter(
            ISessionManager sessionManager,
            IUserService userService,
            SessionCookieService cookieService,
            IOptions<SessionConfiguration> config,
            ILogger<UserAuthenticationFilter> logger)
        {
            _sessionManager = sessionManager;
            _userService = userService;
            _cookieService = cookieService;
            _config = config.Value;
            _logger = logger;
        }

        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            try
            {
                // Skip authentication for certain actions/controllers if needed
                if (ShouldSkipAuthentication(context))
                {
                    return;
                }

                var httpContext = context.HttpContext;
                var user = await GetCurrentUserAsync(httpContext.User);

                if (user != null)
                {
                    // Create or update user session
                    var sessionId = GetOrCreateSessionId(httpContext);
                    var userSession = await CreateUserSessionAsync(user);
                    
                    await _sessionManager.SetAsync(sessionId, userSession);
                    SetSessionCookie(httpContext, sessionId);
                    
                    // Update last login date
                    await UpdateLastLoginAsync(user.UserId);
                    
                    _logger.LogDebug("User session created/updated for user: {UserId}", user.UserId);
                }
                else
                {
                    // No valid user found, check if we should redirect to login
                    if (RequiresAuthentication(context))
                    {
                        await HandleUnauthenticatedRequestAsync(context);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in UserAuthenticationFilter");
                
                // On error, redirect to login for security
                if (RequiresAuthentication(context))
                {
                    await HandleUnauthenticatedRequestAsync(context);
                }
            }
        }

        private async Task<User?> GetCurrentUserAsync(ClaimsPrincipal principal)
        {
            if (principal?.Identity == null || !principal.Identity.IsAuthenticated)
            {
                return null;
            }

            return await _userService.GetCurrentUserAsync(principal);
        }

        private async Task<UserSession> CreateUserSessionAsync(User user)
        {
            return new UserSession
            {
                UserId = user.UserId,
                RoleId = user.RoleId,
                IsAuthorized = true,
                IsDashboardVisited = false,
                ExternalConfig = user.ExternalConfig,
                CreatedAt = DateTime.UtcNow,
                LastAccessedAt = DateTime.UtcNow,
                ExpirationTimeout = _config.SessionTimeout
            };
        }

        private string GetOrCreateSessionId(HttpContext httpContext)
        {
            // Try to get existing session ID from secure cookie
            var sessionId = _cookieService.GetSessionId(httpContext);
            
            if (string.IsNullOrEmpty(sessionId))
            {
                // Generate new secure session ID
                sessionId = SessionCookieService.GenerateSecureSessionId();
                _logger.LogDebug("Generated new session ID: {SessionId}", sessionId);
            }
            
            return sessionId;
        }

        private void SetSessionCookie(HttpContext httpContext, string sessionId)
        {
            _cookieService.SetSessionCookie(httpContext, sessionId);
        }

        private async Task UpdateLastLoginAsync(string userId)
        {
            try
            {
                // This would typically call a repository method to update last login
                // For now, we'll log it
                _logger.LogDebug("Should update last login for user: {UserId}", userId);
                
                // If you have a user repository with UpdateLastLoginAsync method:
                // await _userRepository.UpdateLastLoginAsync(userId);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to update last login for user: {UserId}", userId);
                // Don't fail the authentication process for this
            }
        }

        private bool ShouldSkipAuthentication(AuthorizationFilterContext context)
        {
            // Skip for certain controllers or actions
            var controllerName = context.RouteData.Values["controller"]?.ToString();
            var actionName = context.RouteData.Values["action"]?.ToString();

            // Skip for login/logout actions
            if (string.Equals(controllerName, "Account", StringComparison.OrdinalIgnoreCase))
            {
                if (string.Equals(actionName, "Login", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(actionName, "Logout", StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            // Skip for API health checks
            if (string.Equals(controllerName, "Health", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            return false;
        }

        private bool RequiresAuthentication(AuthorizationFilterContext context)
        {
            // Check if the action/controller allows anonymous access
            var allowAnonymous = context.ActionDescriptor.EndpointMetadata
                .Any(m => m.GetType().Name == "AllowAnonymousAttribute");

            return !allowAnonymous;
        }

        private async Task HandleUnauthenticatedRequestAsync(AuthorizationFilterContext context)
        {
            var httpContext = context.HttpContext;
            
            // For AJAX requests, return JSON response
            if (IsAjaxRequest(httpContext.Request))
            {
                context.Result = new JsonResult(new { loginRequired = true })
                {
                    StatusCode = 401
                };
                return;
            }

            // For regular requests, redirect to login page
            var returnUrl = httpContext.Request.Path + httpContext.Request.QueryString;
            var loginUrl = $"{_config.LoginPageUrl}?returnUrl={Uri.EscapeDataString(returnUrl)}";
            
            context.Result = new RedirectResult(loginUrl);
        }

        private bool IsAjaxRequest(HttpRequest request)
        {
            return request.Headers.ContainsKey("X-Requested-With") &&
                   request.Headers["X-Requested-With"] == "XMLHttpRequest";
        }
    }
}