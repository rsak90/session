-- Users table schema for secure session management
-- This table should integrate with your existing user management system

-- Create Users table if it doesn't exist
CREATE TABLE Users (
    UserId NVARCHAR2(50) PRIMARY KEY,
    AccountName NVARCHAR2(100) NOT NULL UNIQUE,
    RoleId NVARCHAR2(50),
    IsActive NUMBER(1) DEFAULT 1 CHECK (IsActive IN (0,1)),
    ExternalConfig CLOB,
    CreatedDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    LastLoginDate TIMESTAMP,
    ModifiedDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Indexes for performance
    CONSTRAINT idx_users_account_name UNIQUE (AccountName)
);

-- Create indexes
CREATE INDEX idx_users_active ON Users (IsActive);
CREATE INDEX idx_users_role ON Users (RoleId);
CREATE INDEX idx_users_last_login ON Users (LastLoginDate);

-- Create trigger to update ModifiedDate
CREATE OR REPLACE TRIGGER trg_users_modified_date
    BEFORE UPDATE ON Users
    FOR EACH ROW
BEGIN
    :NEW.ModifiedDate := CURRENT_TIMESTAMP;
END;
/

-- Sample data (adjust according to your existing user system)
-- INSERT INTO Users (UserId, AccountName, RoleId, IsActive, ExternalConfig) 
-- VALUES ('USER001', 'john.doe', 'ADMIN', 1, '{"theme":"dark","language":"en"}');

-- If you have an existing Users table, you may need to add these columns:
-- ALTER TABLE Users ADD (
--     ExternalConfig CLOB,
--     LastLoginDate TIMESTAMP
-- );

-- Grant necessary permissions (adjust schema names as needed)
-- GRANT SELECT, INSERT, UPDATE ON Users TO your_application_user;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON UserSessions TO your_application_user;