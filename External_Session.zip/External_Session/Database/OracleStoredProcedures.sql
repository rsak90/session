-- Stored procedure for efficient session cleanup
CREATE OR REPLACE PROCEDURE CleanupExpiredSessions
AS
    v_deleted_count NUMBER;
BEGIN
    -- Delete expired sessions in batches to avoid long locks
    LOOP
        DELETE FROM UserSessions 
        WHERE ExpiresAt <= SYSDATE 
        AND ROWNUM <= 1000; -- Process in batches of 1000
        
        v_deleted_count := SQL%ROWCOUNT;
        
        -- Log progress for large cleanups
        IF v_deleted_count > 0 THEN
            DBMS_OUTPUT.PUT_LINE('Deleted ' || v_deleted_count || ' expired sessions');
        END IF;
        
        -- Commit each batch
        COMMIT;
        
        -- Exit when no more rows to delete
        EXIT WHEN v_deleted_count = 0;
        
        -- Small delay to prevent overwhelming the database
        DBMS_LOCK.SLEEP(0.1);
    END LOOP;
    
    -- Update table statistics for better query performance
    DBMS_STATS.GATHER_TABLE_STATS(
        ownname => USER,
        tabname => 'USERSESSIONS',
        estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE
    );
    
    DBMS_OUTPUT.PUT_LINE('Session cleanup completed successfully');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error during session cleanup: ' || SQLERRM);
        RAISE;
END CleanupExpiredSessions;
/

-- Stored procedure for session statistics
CREATE OR REPLACE PROCEDURE GetSessionStatistics(
    p_total_sessions OUT NUMBER,
    p_active_sessions OUT NUMBER,
    p_expired_sessions OUT NUMBER
)
AS
BEGIN
    -- Get total session count
    SELECT COUNT(*) INTO p_total_sessions FROM UserSessions;
    
    -- Get active session count
    SELECT COUNT(*) INTO p_active_sessions 
    FROM UserSessions 
    WHERE ExpiresAt > SYSDATE;
    
    -- Get expired session count
    SELECT COUNT(*) INTO p_expired_sessions 
    FROM UserSessions 
    WHERE ExpiresAt <= SYSDATE;
    
EXCEPTION
    WHEN OTHERS THEN
        p_total_sessions := -1;
        p_active_sessions := -1;
        p_expired_sessions := -1;
        RAISE;
END GetSessionStatistics;
/

-- Function to get session age distribution
CREATE OR REPLACE FUNCTION GetSessionAgeDistribution
RETURN SYS_REFCURSOR
AS
    v_cursor SYS_REFCURSOR;
BEGIN
    OPEN v_cursor FOR
        SELECT 
            CASE 
                WHEN age_hours < 1 THEN 'Less than 1 hour'
                WHEN age_hours < 24 THEN '1-24 hours'
                WHEN age_hours < 168 THEN '1-7 days'
                ELSE 'More than 7 days'
            END AS age_group,
            COUNT(*) as session_count
        FROM (
            SELECT 
                ROUND((SYSDATE - CreatedAt) * 24, 2) as age_hours
            FROM UserSessions
        )
        GROUP BY 
            CASE 
                WHEN age_hours < 1 THEN 'Less than 1 hour'
                WHEN age_hours < 24 THEN '1-24 hours'
                WHEN age_hours < 168 THEN '1-7 days'
                ELSE 'More than 7 days'
            END
        ORDER BY 
            CASE 
                WHEN age_group = 'Less than 1 hour' THEN 1
                WHEN age_group = '1-24 hours' THEN 2
                WHEN age_group = '1-7 days' THEN 3
                ELSE 4
            END;
    
    RETURN v_cursor;
END GetSessionAgeDistribution;
/

-- Create job for automatic cleanup (runs every hour)
BEGIN
    DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'SESSION_CLEANUP_JOB',
        job_type        => 'PLSQL_BLOCK',
        job_action      => 'BEGIN CleanupExpiredSessions; END;',
        start_date      => SYSTIMESTAMP,
        repeat_interval => 'FREQ=HOURLY;INTERVAL=1',
        enabled         => TRUE,
        comments        => 'Automatic cleanup of expired user sessions'
    );
END;
/