using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SecureSessionManagement.Configuration;
using SecureSessionManagement.Models;
using SecureSessionManagement.Services;

namespace SecureSessionManagement.Adapters
{
    /// <summary>
    /// Provides backward compatibility with existing ISession usage patterns
    /// Allows gradual migration from HttpContext.Session to secure session management
    /// </summary>
    public class LegacySessionAdapter
    {
        private readonly ISessionManager _secureSessionManager;
        private readonly SessionCookieService _cookieService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly SessionConfiguration _config;
        private readonly ILogger<LegacySessionAdapter> _logger;

        public LegacySessionAdapter(
            ISessionManager secureSessionManager,
            SessionCookieService cookieService,
            IHttpContextAccessor httpContextAccessor,
            IOptions<SessionConfiguration> config,
            ILogger<LegacySessionAdapter> logger)
        {
            _secureSessionManager = secureSessionManager;
            _cookieService = cookieService;
            _httpContextAccessor = httpContextAccessor;
            _config = config.Value;
            _logger = logger;
        }

        /// <summary>
        /// Gets a string value from the session, compatible with ISession.GetString()
        /// </summary>
        public async Task<string?> GetStringAsync(string key)
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext == null)
                {
                    _logger.LogWarning("HttpContext is null when getting session string for key: {Key}", key);
                    return null;
                }

                var sessionId = _cookieService.GetSessionId(httpContext);
                if (string.IsNullOrEmpty(sessionId))
                {
                    return null;
                }

                var session = await _secureSessionManager.GetAsync(sessionId);
                if (session == null)
                {
                    return null;
                }

                return GetValueFromSession(session, key);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting session string for key: {Key}", key);
                return null;
            }
        }

        /// <summary>
        /// Sets a string value in the session, compatible with ISession.SetString()
        /// </summary>
        public async Task SetStringAsync(string key, string value)
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext == null)
                {
                    _logger.LogWarning("HttpContext is null when setting session string for key: {Key}", key);
                    return;
                }

                var sessionId = _cookieService.GetSessionId(httpContext);
                UserSession session;

                if (string.IsNullOrEmpty(sessionId))
                {
                    // Create new session
                    sessionId = SessionCookieService.GenerateSecureSessionId();
                    session = CreateNewSession();
                    _cookieService.SetSessionCookie(httpContext, sessionId);
                }
                else
                {
                    // Get existing session or create new one
                    session = await _secureSessionManager.GetAsync(sessionId) ?? CreateNewSession();
                }

                SetValueInSession(session, key, value);
                session.LastAccessedAt = DateTime.UtcNow;

                await _secureSessionManager.SetAsync(sessionId, session);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error setting session string for key: {Key}", key);
                throw;
            }
        }

        /// <summary>
        /// Gets an integer value from the session, compatible with ISession.GetInt32()
        /// </summary>
        public async Task<int?> GetInt32Async(string key)
        {
            var stringValue = await GetStringAsync(key);
            if (string.IsNullOrEmpty(stringValue))
            {
                return null;
            }

            if (int.TryParse(stringValue, out int result))
            {
                return result;
            }

            return null;
        }

        /// <summary>
        /// Sets an integer value in the session, compatible with ISession.SetInt32()
        /// </summary>
        public async Task SetInt32Async(string key, int value)
        {
            await SetStringAsync(key, value.ToString());
        }

        /// <summary>
        /// Removes a key from the session, compatible with ISession.Remove()
        /// </summary>
        public async Task RemoveAsync(string key)
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext == null)
                {
                    return;
                }

                var sessionId = _cookieService.GetSessionId(httpContext);
                if (string.IsNullOrEmpty(sessionId))
                {
                    return;
                }

                var session = await _secureSessionManager.GetAsync(sessionId);
                if (session == null)
                {
                    return;
                }

                RemoveValueFromSession(session, key);
                session.LastAccessedAt = DateTime.UtcNow;

                await _secureSessionManager.SetAsync(sessionId, session);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing session key: {Key}", key);
                throw;
            }
        }

        /// <summary>
        /// Clears all session data, compatible with ISession.Clear()
        /// </summary>
        public async Task ClearAsync()
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext == null)
                {
                    return;
                }

                var sessionId = _cookieService.GetSessionId(httpContext);
                if (!string.IsNullOrEmpty(sessionId))
                {
                    await _secureSessionManager.RemoveAsync(sessionId);
                }

                _cookieService.RemoveSessionCookies(httpContext);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error clearing session");
                throw;
            }
        }

        /// <summary>
        /// Checks if a key exists in the session
        /// </summary>
        public async Task<bool> ContainsKeyAsync(string key)
        {
            var value = await GetStringAsync(key);
            return !string.IsNullOrEmpty(value);
        }

        /// <summary>
        /// Gets all session keys (for migration purposes)
        /// </summary>
        public async Task<IEnumerable<string>> GetKeysAsync()
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext == null)
                {
                    return new List<string>();
                }

                var sessionId = _cookieService.GetSessionId(httpContext);
                if (string.IsNullOrEmpty(sessionId))
                {
                    return new List<string>();
                }

                var session = await _secureSessionManager.GetAsync(sessionId);
                if (session == null)
                {
                    return new List<string>();
                }

                return GetKeysFromSession(session);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting session keys");
                return new List<string>();
            }
        }

        /// <summary>
        /// Migrates data from HttpContext.Session to secure session management
        /// </summary>
        public async Task MigrateFromHttpSessionAsync(ISession httpSession)
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext == null)
                {
                    _logger.LogWarning("HttpContext is null during session migration");
                    return;
                }

                var sessionId = SessionCookieService.GenerateSecureSessionId();
                var session = CreateNewSession();

                // Migrate common session keys
                var commonKeys = new[] { "UserId", "UserName", "RoleId", "IsAuthorized", "ExternalConfig" };
                
                foreach (var key in commonKeys)
                {
                    var value = httpSession.GetString(key);
                    if (!string.IsNullOrEmpty(value))
                    {
                        SetValueInSession(session, key, value);
                    }
                }

                // Set session properties from migrated data
                var userId = httpSession.GetString("UserId");
                var roleId = httpSession.GetString("RoleId");
                var isAuthorizedStr = httpSession.GetString("IsAuthorized");
                var externalConfig = httpSession.GetString("ExternalConfig");

                if (!string.IsNullOrEmpty(userId))
                {
                    session.UserId = userId;
                }

                if (!string.IsNullOrEmpty(roleId))
                {
                    session.RoleId = roleId;
                }

                if (bool.TryParse(isAuthorizedStr, out bool isAuthorized))
                {
                    session.IsAuthorized = isAuthorized;
                }

                if (!string.IsNullOrEmpty(externalConfig))
                {
                    session.ExternalConfig = externalConfig;
                }

                await _secureSessionManager.SetAsync(sessionId, session);
                _cookieService.SetSessionCookie(httpContext, sessionId);

                _logger.LogInformation("Successfully migrated session data for user: {UserId}", userId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error migrating from HTTP session");
                throw;
            }
        }

        private UserSession CreateNewSession()
        {
            return new UserSession
            {
                UserId = string.Empty,
                RoleId = string.Empty,
                IsAuthorized = false,
                IsDashboardVisited = false,
                ExternalConfig = "{}",
                CreatedAt = DateTime.UtcNow,
                LastAccessedAt = DateTime.UtcNow,
                ExpirationTimeout = _config.SessionTimeout
            };
        }

        private string? GetValueFromSession(UserSession session, string key)
        {
            // Handle built-in properties
            switch (key.ToLowerInvariant())
            {
                case "userid":
                    return session.UserId;
                case "roleid":
                    return session.RoleId;
                case "isauthorized":
                    return session.IsAuthorized.ToString();
                case "isdashboardvisited":
                    return session.IsDashboardVisited.ToString();
                case "externalconfig":
                    return session.ExternalConfig;
                default:
                    // Handle custom properties stored in ExternalConfig
                    return GetCustomProperty(session.ExternalConfig, key);
            }
        }

        private void SetValueInSession(UserSession session, string key, string value)
        {
            // Handle built-in properties
            switch (key.ToLowerInvariant())
            {
                case "userid":
                    session.UserId = value;
                    break;
                case "roleid":
                    session.RoleId = value;
                    break;
                case "isauthorized":
                    session.IsAuthorized = bool.TryParse(value, out bool authorized) && authorized;
                    break;
                case "isdashboardvisited":
                    session.IsDashboardVisited = bool.TryParse(value, out bool visited) && visited;
                    break;
                case "externalconfig":
                    session.ExternalConfig = value;
                    break;
                default:
                    // Handle custom properties in ExternalConfig
                    session.ExternalConfig = SetCustomProperty(session.ExternalConfig, key, value);
                    break;
            }
        }

        private void RemoveValueFromSession(UserSession session, string key)
        {
            switch (key.ToLowerInvariant())
            {
                case "userid":
                    session.UserId = string.Empty;
                    break;
                case "roleid":
                    session.RoleId = string.Empty;
                    break;
                case "isauthorized":
                    session.IsAuthorized = false;
                    break;
                case "isdashboardvisited":
                    session.IsDashboardVisited = false;
                    break;
                case "externalconfig":
                    session.ExternalConfig = "{}";
                    break;
                default:
                    session.ExternalConfig = RemoveCustomProperty(session.ExternalConfig, key);
                    break;
            }
        }

        private IEnumerable<string> GetKeysFromSession(UserSession session)
        {
            var keys = new List<string> { "UserId", "RoleId", "IsAuthorized", "IsDashboardVisited", "ExternalConfig" };
            
            // Add custom property keys from ExternalConfig
            try
            {
                if (!string.IsNullOrEmpty(session.ExternalConfig) && session.ExternalConfig != "{}")
                {
                    var customProps = JsonSerializer.Deserialize<Dictionary<string, object>>(session.ExternalConfig);
                    if (customProps != null)
                    {
                        keys.AddRange(customProps.Keys);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error parsing ExternalConfig for keys");
            }

            return keys;
        }

        private string? GetCustomProperty(string externalConfig, string key)
        {
            try
            {
                if (string.IsNullOrEmpty(externalConfig) || externalConfig == "{}")
                {
                    return null;
                }

                var props = JsonSerializer.Deserialize<Dictionary<string, object>>(externalConfig);
                if (props != null && props.TryGetValue(key, out var value))
                {
                    return value?.ToString();
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error getting custom property {Key} from ExternalConfig", key);
            }

            return null;
        }

        private string SetCustomProperty(string externalConfig, string key, string value)
        {
            try
            {
                Dictionary<string, object> props;
                
                if (string.IsNullOrEmpty(externalConfig) || externalConfig == "{}")
                {
                    props = new Dictionary<string, object>();
                }
                else
                {
                    props = JsonSerializer.Deserialize<Dictionary<string, object>>(externalConfig) ?? new Dictionary<string, object>();
                }

                props[key] = value;
                return JsonSerializer.Serialize(props);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error setting custom property {Key} in ExternalConfig", key);
                return externalConfig;
            }
        }

        private string RemoveCustomProperty(string externalConfig, string key)
        {
            try
            {
                if (string.IsNullOrEmpty(externalConfig) || externalConfig == "{}")
                {
                    return "{}";
                }

                var props = JsonSerializer.Deserialize<Dictionary<string, object>>(externalConfig);
                if (props != null)
                {
                    props.Remove(key);
                    return JsonSerializer.Serialize(props);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing custom property {Key} from ExternalConfig", key);
            }

            return externalConfig;
        }
    }
}