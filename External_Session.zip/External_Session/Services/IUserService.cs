using System.Security.Claims;
using System.Threading.Tasks;
using SecureSessionManagement.Models;

namespace SecureSessionManagement.Services
{
    public interface IUserService
    {
        Task<User?> GetUserByAccountNameAsync(string accountName);
        Task<User?> GetCurrentUserAsync(ClaimsPrincipal principal);
    }
}