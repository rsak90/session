using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using StackExchange.Redis;
using SecureSessionManagement.Configuration;

namespace SecureSessionManagement.Services
{
    public class RedisConnectionService : IDisposable
    {
        private readonly SessionConfiguration _config;
        private readonly ILogger<RedisConnectionService> _logger;
        private IConnectionMultiplexer? _connection;
        private readonly object _lock = new object();
        private bool _disposed = false;

        public RedisConnectionService(
            IOptions<SessionConfiguration> config,
            ILogger<RedisConnectionService> logger)
        {
            _config = config.Value;
            _logger = logger;
        }

        public IConnectionMultiplexer GetConnection()
        {
            if (_connection != null && _connection.IsConnected)
                return _connection;

            lock (_lock)
            {
                if (_connection != null && _connection.IsConnected)
                    return _connection;

                _connection?.Dispose();
                _connection = CreateConnection();
                return _connection;
            }
        }

        private IConnectionMultiplexer CreateConnection()
        {
            try
            {
                var options = ConfigurationOptions.Parse(_config.RedisConnectionString);
                
                // Configure connection options for reliability
                options.ConnectRetry = _config.MaxRetryAttempts;
                options.ConnectTimeout = 5000; // 5 seconds
                options.SyncTimeout = 5000; // 5 seconds
                options.AsyncTimeout = 5000; // 5 seconds
                options.AbortOnConnectFail = false;
                options.ReconnectRetryPolicy = new ExponentialRetry(1000); // Start with 1 second delay
                
                // Enable connection multiplexing
                options.ChannelPrefix = "session";
                
                // Configure for cluster support if needed
                if (_config.RedisConnectionString.Contains(","))
                {
                    _logger.LogInformation("Configuring Redis for cluster mode");
                }

                var connection = ConnectionMultiplexer.Connect(options);
                
                // Set up event handlers for connection monitoring
                connection.ConnectionFailed += OnConnectionFailed;
                connection.ConnectionRestored += OnConnectionRestored;
                connection.ErrorMessage += OnErrorMessage;
                connection.InternalError += OnInternalError;

                _logger.LogInformation("Redis connection established successfully");
                return connection;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create Redis connection");
                throw;
            }
        }

        private void OnConnectionFailed(object? sender, ConnectionFailedEventArgs e)
        {
            _logger.LogError("Redis connection failed: {EndPoint} - {FailureType} - {Exception}", 
                e.EndPoint, e.FailureType, e.Exception?.Message);
        }

        private void OnConnectionRestored(object? sender, ConnectionFailedEventArgs e)
        {
            _logger.LogInformation("Redis connection restored: {EndPoint}", e.EndPoint);
        }

        private void OnErrorMessage(object? sender, RedisErrorEventArgs e)
        {
            _logger.LogError("Redis error: {EndPoint} - {Message}", e.EndPoint, e.Message);
        }

        private void OnInternalError(object? sender, InternalErrorEventArgs e)
        {
            _logger.LogError(e.Exception, "Redis internal error: {EndPoint} - {Origin}", 
                e.EndPoint, e.Origin);
        }

        public async Task<bool> TestConnectionAsync()
        {
            try
            {
                var connection = GetConnection();
                var database = connection.GetDatabase();
                
                // Test with a simple ping
                var latency = await database.PingAsync();
                _logger.LogInformation("Redis connection test successful. Latency: {Latency}ms", latency.TotalMilliseconds);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Redis connection test failed");
                return false;
            }
        }

        public ConnectionInfo GetConnectionInfo()
        {
            var connection = GetConnection();
            return new ConnectionInfo
            {
                IsConnected = connection.IsConnected,
                ClientName = connection.ClientName,
                Configuration = connection.Configuration,
                TimeoutMilliseconds = connection.TimeoutMilliseconds
            };
        }

        public void Dispose()
        {
            if (!_disposed)
            {
                lock (_lock)
                {
                    if (!_disposed)
                    {
                        _connection?.Dispose();
                        _connection = null;
                        _disposed = true;
                    }
                }
            }
        }
    }

    public class ConnectionInfo
    {
        public bool IsConnected { get; set; }
        public string? ClientName { get; set; }
        public string? Configuration { get; set; }
        public int TimeoutMilliseconds { get; set; }
    }
}