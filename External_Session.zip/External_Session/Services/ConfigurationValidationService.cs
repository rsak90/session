using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SecureSessionManagement.Configuration;

namespace SecureSessionManagement.Services
{
    public class ConfigurationValidationService
    {
        private readonly SessionConfiguration _sessionConfig;
        private readonly UserIntegrationConfiguration _userConfig;
        private readonly ILogger<ConfigurationValidationService> _logger;

        public ConfigurationValidationService(
            IOptions<SessionConfiguration> sessionConfig,
            IOptions<UserIntegrationConfiguration> userConfig,
            ILogger<ConfigurationValidationService> logger)
        {
            _sessionConfig = sessionConfig.Value;
            _userConfig = userConfig.Value;
            _logger = logger;
        }

        public ConfigurationValidationResult ValidateConfiguration()
        {
            var result = new ConfigurationValidationResult();
            var errors = new List<string>();
            var warnings = new List<string>();

            // Validate session configuration
            ValidateSessionConfiguration(errors, warnings);
            
            // Validate user integration configuration
            ValidateUserIntegrationConfiguration(errors, warnings);
            
            // Validate connection strings
            ValidateConnectionStrings(errors, warnings);

            result.IsValid = !errors.Any();
            result.Errors = errors;
            result.Warnings = warnings;

            if (result.IsValid)
            {
                _logger.LogInformation("Configuration validation passed with {WarningCount} warnings", warnings.Count);
            }
            else
            {
                _logger.LogError("Configuration validation failed with {ErrorCount} errors and {WarningCount} warnings", 
                    errors.Count, warnings.Count);
            }

            return result;
        }

        private void ValidateSessionConfiguration(List<string> errors, List<string> warnings)
        {
            // Validate session timeout
            if (_sessionConfig.SessionTimeout <= TimeSpan.Zero)
            {
                errors.Add("SessionTimeout must be greater than zero");
            }
            else if (_sessionConfig.SessionTimeout > TimeSpan.FromHours(24))
            {
                warnings.Add("SessionTimeout is longer than 24 hours, which may pose security risks");
            }
            else if (_sessionConfig.SessionTimeout < TimeSpan.FromMinutes(5))
            {
                warnings.Add("SessionTimeout is less than 5 minutes, which may cause frequent re-authentication");
            }

            // Validate retry configuration
            if (_sessionConfig.MaxRetryAttempts < 1)
            {
                errors.Add("MaxRetryAttempts must be at least 1");
            }
            else if (_sessionConfig.MaxRetryAttempts > 10)
            {
                warnings.Add("MaxRetryAttempts is very high, which may cause long delays on failures");
            }

            if (_sessionConfig.RetryDelay < TimeSpan.Zero)
            {
                errors.Add("RetryDelay cannot be negative");
            }

            // Validate storage configuration
            if (!_sessionConfig.UseRedisStorage && !_sessionConfig.UseOracleStorage)
            {
                errors.Add("At least one storage option (Redis or Oracle) must be enabled");
            }

            // Validate login page URL
            if (string.IsNullOrWhiteSpace(_sessionConfig.LoginPageUrl))
            {
                errors.Add("LoginPageUrl cannot be empty");
            }
            else if (!_sessionConfig.LoginPageUrl.StartsWith("/"))
            {
                warnings.Add("LoginPageUrl should start with '/' for relative URLs");
            }
        }

        private void ValidateUserIntegrationConfiguration(List<string> errors, List<string> warnings)
        {
            // Validate table and column names
            if (string.IsNullOrWhiteSpace(_userConfig.UserTableName))
            {
                errors.Add("UserTableName cannot be empty");
            }

            var requiredColumns = new[]
            {
                (_userConfig.UserIdColumn, "UserIdColumn"),
                (_userConfig.AccountNameColumn, "AccountNameColumn"),
                (_userConfig.IsActiveColumn, "IsActiveColumn")
            };

            foreach (var (columnName, configName) in requiredColumns)
            {
                if (string.IsNullOrWhiteSpace(columnName))
                {
                    errors.Add($"{configName} cannot be empty");
                }
            }

            // Validate cache configuration
            if (_userConfig.EnableUserCaching)
            {
                if (_userConfig.UserCacheExpiration <= TimeSpan.Zero)
                {
                    errors.Add("UserCacheExpiration must be greater than zero when caching is enabled");
                }
                else if (_userConfig.UserCacheExpiration > TimeSpan.FromHours(4))
                {
                    warnings.Add("UserCacheExpiration is longer than 4 hours, which may cause stale user data");
                }
            }

            // Validate default role
            if (string.IsNullOrWhiteSpace(_userConfig.DefaultRoleId))
            {
                warnings.Add("DefaultRoleId is empty, users without roles may have limited access");
            }
        }

        private void ValidateConnectionStrings(List<string> errors, List<string> warnings)
        {
            // Validate Redis connection string
            if (_sessionConfig.UseRedisStorage)
            {
                if (string.IsNullOrWhiteSpace(_sessionConfig.RedisConnectionString))
                {
                    errors.Add("RedisConnectionString is required when UseRedisStorage is true");
                }
                else
                {
                    ValidateRedisConnectionString(_sessionConfig.RedisConnectionString, errors, warnings);
                }
            }

            // Validate Oracle connection string
            if (_sessionConfig.UseOracleStorage)
            {
                if (string.IsNullOrWhiteSpace(_sessionConfig.OracleConnectionString))
                {
                    errors.Add("OracleConnectionString is required when UseOracleStorage is true");
                }
                else
                {
                    ValidateOracleConnectionString(_sessionConfig.OracleConnectionString, errors, warnings);
                }
            }
        }

        private void ValidateRedisConnectionString(string connectionString, List<string> errors, List<string> warnings)
        {
            try
            {
                // Basic validation - check for common Redis connection string patterns
                if (!connectionString.Contains(":"))
                {
                    warnings.Add("Redis connection string may be missing port number");
                }

                if (connectionString.ToLower().Contains("password=") && 
                    connectionString.ToLower().Contains("password=your-redis-password"))
                {
                    warnings.Add("Redis connection string appears to contain placeholder password");
                }

                if (!connectionString.ToLower().Contains("ssl=true") && 
                    connectionString.Contains("amazonaws.com"))
                {
                    warnings.Add("AWS Redis connection should use SSL");
                }
            }
            catch (Exception ex)
            {
                warnings.Add($"Could not validate Redis connection string format: {ex.Message}");
            }
        }

        private void ValidateOracleConnectionString(string connectionString, List<string> errors, List<string> warnings)
        {
            try
            {
                var requiredParts = new[] { "Data Source", "User Id" };
                
                foreach (var part in requiredParts)
                {
                    if (!connectionString.Contains(part, StringComparison.OrdinalIgnoreCase))
                    {
                        errors.Add($"Oracle connection string is missing required part: {part}");
                    }
                }

                if (connectionString.ToLower().Contains("password=your-secure-password") ||
                    connectionString.ToLower().Contains("password=session_password"))
                {
                    warnings.Add("Oracle connection string appears to contain placeholder password");
                }

                if (!connectionString.ToLower().Contains("connection timeout"))
                {
                    warnings.Add("Oracle connection string should include Connection Timeout for better reliability");
                }
            }
            catch (Exception ex)
            {
                warnings.Add($"Could not validate Oracle connection string format: {ex.Message}");
            }
        }

        public void LogConfigurationSummary()
        {
            _logger.LogInformation("Session Management Configuration Summary:");
            _logger.LogInformation("- Redis Storage: {UseRedis}", _sessionConfig.UseRedisStorage);
            _logger.LogInformation("- Oracle Storage: {UseOracle}", _sessionConfig.UseOracleStorage);
            _logger.LogInformation("- Session Timeout: {Timeout}", _sessionConfig.SessionTimeout);
            _logger.LogInformation("- Login Required: {Required}", _sessionConfig.RequiredLogin);
            _logger.LogInformation("- Max Retry Attempts: {MaxRetries}", _sessionConfig.MaxRetryAttempts);
            _logger.LogInformation("- User Caching: {UserCaching}", _userConfig.EnableUserCaching);
            _logger.LogInformation("- Legacy Compatibility: {Legacy}", _sessionConfig.EnableLegacyCompatibility);
        }
    }

    public class ConfigurationValidationResult
    {
        public bool IsValid { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
        public List<string> Warnings { get; set; } = new List<string>();
    }
}