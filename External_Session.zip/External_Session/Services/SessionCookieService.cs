using System;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SecureSessionManagement.Configuration;

namespace SecureSessionManagement.Services
{
    public class SessionCookieService
    {
        private readonly SessionConfiguration _config;
        private readonly ILogger<SessionCookieService> _logger;
        private const string SessionCookieName = "SessionId";
        private const string SessionValidationCookieName = "SessionValidation";

        public SessionCookieService(
            IOptions<SessionConfiguration> config,
            ILogger<SessionCookieService> logger)
        {
            _config = config.Value;
            _logger = logger;
        }

        public string? GetSessionId(HttpContext httpContext)
        {
            var sessionId = httpContext.Request.Cookies[SessionCookieName];
            
            if (string.IsNullOrEmpty(sessionId))
            {
                return null;
            }

            // Validate session ID format
            if (!IsValidSessionIdFormat(sessionId))
            {
                _logger.LogWarning("Invalid session ID format detected: {SessionId}", sessionId);
                RemoveSessionCookies(httpContext);
                return null;
            }

            // Validate session integrity if validation cookie exists
            var validationCookie = httpContext.Request.Cookies[SessionValidationCookieName];
            if (!string.IsNullOrEmpty(validationCookie))
            {
                if (!ValidateSessionIntegrity(sessionId, validationCookie))
                {
                    _logger.LogWarning("Session integrity validation failed for session: {SessionId}", sessionId);
                    RemoveSessionCookies(httpContext);
                    return null;
                }
            }

            return sessionId;
        }

        public void SetSessionCookie(HttpContext httpContext, string sessionId, DateTime? expiresAt = null)
        {
            if (string.IsNullOrEmpty(sessionId))
            {
                throw new ArgumentException("Session ID cannot be null or empty", nameof(sessionId));
            }

            var expiration = expiresAt ?? DateTime.UtcNow.Add(_config.SessionTimeout);
            
            var cookieOptions = CreateSecureCookieOptions(expiration);

            // Set main session cookie
            httpContext.Response.Cookies.Append(SessionCookieName, sessionId, cookieOptions);

            // Set validation cookie for integrity checking
            var validationValue = GenerateValidationValue(sessionId);
            httpContext.Response.Cookies.Append(SessionValidationCookieName, validationValue, cookieOptions);

            _logger.LogDebug("Session cookies set for session: {SessionId}, expires: {Expiration}", 
                sessionId, expiration);
        }

        public void RemoveSessionCookies(HttpContext httpContext)
        {
            var expiredCookieOptions = CreateSecureCookieOptions(DateTime.UtcNow.AddDays(-1));

            httpContext.Response.Cookies.Append(SessionCookieName, string.Empty, expiredCookieOptions);
            httpContext.Response.Cookies.Append(SessionValidationCookieName, string.Empty, expiredCookieOptions);

            _logger.LogDebug("Session cookies removed");
        }

        public void RefreshSessionCookie(HttpContext httpContext, string sessionId)
        {
            var newExpiration = DateTime.UtcNow.Add(_config.SessionTimeout);
            SetSessionCookie(httpContext, sessionId, newExpiration);
        }

        public static string GenerateSecureSessionId()
        {
            using var rng = RandomNumberGenerator.Create();
            var bytes = new byte[32]; // 256 bits
            rng.GetBytes(bytes);
            
            // Convert to URL-safe base64
            return Convert.ToBase64String(bytes)
                .Replace("+", "-")
                .Replace("/", "_")
                .Replace("=", "");
        }

        private CookieOptions CreateSecureCookieOptions(DateTime expiration)
        {
            return new CookieOptions
            {
                HttpOnly = true,
                Secure = true, // Always require HTTPS for session cookies
                SameSite = SameSiteMode.Strict,
                Expires = expiration,
                Path = "/",
                IsEssential = true,
                Domain = GetCookieDomain()
            };
        }

        private string? GetCookieDomain()
        {
            // Configure domain for cookie sharing across subdomains if needed
            // Return null for default behavior (current domain only)
            return null;
        }

        private bool IsValidSessionIdFormat(string sessionId)
        {
            // Session ID should be base64url encoded, 43 characters long (32 bytes -> 43 chars without padding)
            if (string.IsNullOrEmpty(sessionId) || sessionId.Length != 43)
            {
                return false;
            }

            // Check for valid base64url characters
            foreach (char c in sessionId)
            {
                if (!IsBase64UrlChar(c))
                {
                    return false;
                }
            }

            return true;
        }

        private bool IsBase64UrlChar(char c)
        {
            return (c >= 'A' && c <= 'Z') ||
                   (c >= 'a' && c <= 'z') ||
                   (c >= '0' && c <= '9') ||
                   c == '-' || c == '_';
        }

        private string GenerateValidationValue(string sessionId)
        {
            // Create HMAC-SHA256 hash of session ID for integrity validation
            // In production, use a secret key from configuration
            var key = System.Text.Encoding.UTF8.GetBytes("SecureSessionValidationKey2024"); // TODO: Move to config
            
            using var hmac = new HMACSHA256(key);
            var hash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(sessionId));
            
            return Convert.ToBase64String(hash)
                .Replace("+", "-")
                .Replace("/", "_")
                .Replace("=", "");
        }

        private bool ValidateSessionIntegrity(string sessionId, string validationValue)
        {
            try
            {
                var expectedValidation = GenerateValidationValue(sessionId);
                return string.Equals(expectedValidation, validationValue, StringComparison.Ordinal);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating session integrity");
                return false;
            }
        }

        public SessionCookieInfo GetSessionCookieInfo(HttpContext httpContext)
        {
            var sessionId = GetSessionId(httpContext);
            var hasCookie = !string.IsNullOrEmpty(sessionId);
            
            return new SessionCookieInfo
            {
                HasSessionCookie = hasCookie,
                SessionId = sessionId,
                IsSecure = httpContext.Request.IsHttps,
                UserAgent = httpContext.Request.Headers["User-Agent"].ToString(),
                IpAddress = httpContext.Connection.RemoteIpAddress?.ToString()
            };
        }
    }

    public class SessionCookieInfo
    {
        public bool HasSessionCookie { get; set; }
        public string? SessionId { get; set; }
        public bool IsSecure { get; set; }
        public string? UserAgent { get; set; }
        public string? IpAddress { get; set; }
    }
}