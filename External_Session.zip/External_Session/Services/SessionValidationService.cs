using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SecureSessionManagement.Configuration;
using SecureSessionManagement.Models;

namespace SecureSessionManagement.Services
{
    public class SessionValidationService
    {
        private readonly SessionConfiguration _config;
        private readonly ILogger<SessionValidationService> _logger;

        public SessionValidationService(
            IOptions<SessionConfiguration> config,
            ILogger<SessionValidationService> logger)
        {
            _config = config.Value;
            _logger = logger;
        }

        public SessionValidationResult ValidateSession(UserSession? session, string? sessionId = null)
        {
            if (session == null)
            {
                return new SessionValidationResult
                {
                    IsValid = false,
                    ErrorCode = "SESSION_NOT_FOUND",
                    ErrorMessage = "Session not found",
                    RequiresReauthentication = true
                };
            }

            // Check if session is expired
            if (session.IsExpired)
            {
                _logger.LogDebug("Session expired for user {UserId}. Last accessed: {LastAccessed}, Timeout: {Timeout}",
                    session.UserId, session.LastAccessedAt, session.ExpirationTimeout);

                return new SessionValidationResult
                {
                    IsValid = false,
                    ErrorCode = "SESSION_EXPIRED",
                    ErrorMessage = "Session has expired",
                    RequiresReauthentication = true,
                    ExpiredAt = session.LastAccessedAt.Add(session.ExpirationTimeout)
                };
            }

            // Check if session is authorized
            if (!session.IsAuthorized)
            {
                _logger.LogDebug("Session not authorized for user {UserId}", session.UserId);

                return new SessionValidationResult
                {
                    IsValid = false,
                    ErrorCode = "SESSION_NOT_AUTHORIZED",
                    ErrorMessage = "Session is not authorized",
                    RequiresReauthentication = true
                };
            }

            // Check session age (additional security check)
            var sessionAge = DateTime.UtcNow - session.CreatedAt;
            var maxSessionAge = TimeSpan.FromHours(24); // Maximum session lifetime

            if (sessionAge > maxSessionAge)
            {
                _logger.LogDebug("Session too old for user {UserId}. Created: {Created}, Age: {Age}",
                    session.UserId, session.CreatedAt, sessionAge);

                return new SessionValidationResult
                {
                    IsValid = false,
                    ErrorCode = "SESSION_TOO_OLD",
                    ErrorMessage = "Session has exceeded maximum lifetime",
                    RequiresReauthentication = true,
                    ExpiredAt = session.CreatedAt.Add(maxSessionAge)
                };
            }

            // Check for session inactivity warning
            var inactivityWarningThreshold = session.ExpirationTimeout.Subtract(TimeSpan.FromMinutes(5));
            var timeSinceLastAccess = DateTime.UtcNow - session.LastAccessedAt;
            bool nearExpiration = timeSinceLastAccess > inactivityWarningThreshold;

            return new SessionValidationResult
            {
                IsValid = true,
                Session = session,
                NearExpiration = nearExpiration,
                TimeUntilExpiration = session.ExpirationTimeout.Subtract(timeSinceLastAccess),
                LastAccessedAt = session.LastAccessedAt
            };
        }

        public async Task<SessionValidationResult> ValidateAndRefreshSessionAsync(
            ISessionManager sessionManager, 
            string sessionId)
        {
            try
            {
                var session = await sessionManager.GetAsync(sessionId);
                var validationResult = ValidateSession(session, sessionId);

                if (validationResult.IsValid && session != null)
                {
                    // Update last accessed time
                    session.LastAccessedAt = DateTime.UtcNow;
                    await sessionManager.SetAsync(sessionId, session);
                    
                    validationResult.Session = session;
                    validationResult.WasRefreshed = true;
                }

                return validationResult;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating and refreshing session {SessionId}", sessionId);
                
                return new SessionValidationResult
                {
                    IsValid = false,
                    ErrorCode = "VALIDATION_ERROR",
                    ErrorMessage = "Error occurred during session validation",
                    RequiresReauthentication = true
                };
            }
        }

        public bool ShouldBypassLogin(UserSession session)
        {
            if (session == null || string.IsNullOrEmpty(session.ExternalConfig))
            {
                return false;
            }

            try
            {
                // Parse external config for bypass conditions
                // This is a placeholder - implement according to your business logic
                
                // Example bypass conditions:
                // - Development environment
                // - Service accounts
                // - Specific user roles
                // - Time-based exceptions
                
                return false; // Default: no bypass
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error checking bypass conditions for user {UserId}", session.UserId);
                return false;
            }
        }

        public SessionHealthInfo GetSessionHealth(UserSession session)
        {
            if (session == null)
            {
                return new SessionHealthInfo
                {
                    Status = SessionHealthStatus.Invalid,
                    Message = "Session not found"
                };
            }

            if (session.IsExpired)
            {
                return new SessionHealthInfo
                {
                    Status = SessionHealthStatus.Expired,
                    Message = "Session has expired",
                    ExpirationTime = session.LastAccessedAt.Add(session.ExpirationTimeout)
                };
            }

            var timeSinceLastAccess = DateTime.UtcNow - session.LastAccessedAt;
            var timeUntilExpiration = session.ExpirationTimeout - timeSinceLastAccess;

            if (timeUntilExpiration <= TimeSpan.FromMinutes(5))
            {
                return new SessionHealthInfo
                {
                    Status = SessionHealthStatus.NearExpiration,
                    Message = "Session will expire soon",
                    TimeUntilExpiration = timeUntilExpiration,
                    ExpirationTime = session.LastAccessedAt.Add(session.ExpirationTimeout)
                };
            }

            return new SessionHealthInfo
            {
                Status = SessionHealthStatus.Healthy,
                Message = "Session is active",
                TimeUntilExpiration = timeUntilExpiration,
                LastAccessedAt = session.LastAccessedAt
            };
        }
    }

    public class SessionValidationResult
    {
        public bool IsValid { get; set; }
        public string? ErrorCode { get; set; }
        public string? ErrorMessage { get; set; }
        public bool RequiresReauthentication { get; set; }
        public UserSession? Session { get; set; }
        public bool NearExpiration { get; set; }
        public TimeSpan? TimeUntilExpiration { get; set; }
        public DateTime? ExpiredAt { get; set; }
        public DateTime? LastAccessedAt { get; set; }
        public bool WasRefreshed { get; set; }
    }

    public class SessionHealthInfo
    {
        public SessionHealthStatus Status { get; set; }
        public string Message { get; set; } = string.Empty;
        public TimeSpan? TimeUntilExpiration { get; set; }
        public DateTime? ExpirationTime { get; set; }
        public DateTime? LastAccessedAt { get; set; }
    }

    public enum SessionHealthStatus
    {
        Invalid,
        Expired,
        NearExpiration,
        Healthy
    }
}