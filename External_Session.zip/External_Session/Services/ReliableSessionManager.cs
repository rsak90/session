using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SecureSessionManagement.Configuration;
using SecureSessionManagement.Models;
using SecureSessionManagement.Stores;

namespace SecureSessionManagement.Services
{
    public class ReliableSessionManager : ISessionManager
    {
        private readonly ISessionStore _primaryStore;
        private readonly ISessionStore _fallbackStore;
        private readonly SessionConfiguration _config;
        private readonly ILogger<ReliableSessionManager> _logger;

        public ReliableSessionManager(
            IEnumerable<ISessionStore> stores,
            IOptions<SessionConfiguration> config,
            ILogger<ReliableSessionManager> logger)
        {
            var storeList = stores.ToList();
            _primaryStore = storeList.FirstOrDefault(s => s.GetType().Name == "RedisSessionStore") 
                           ?? throw new InvalidOperationException("Redis store not found");
            _fallbackStore = storeList.FirstOrDefault(s => s.GetType().Name == "OracleSessionStore")
                            ?? throw new InvalidOperationException("Oracle store not found");
            _config = config.Value;
            _logger = logger;
        }

        public async Task<UserSession?> GetAsync(string sessionId)
        {
            if (string.IsNullOrEmpty(sessionId))
                return null;

            // Try primary store with retry logic
            var session = await TryGetFromStoreWithRetry(_primaryStore, sessionId, "Redis");
            if (session != null)
            {
                // Update last accessed time and sync to both stores
                session.LastAccessedAt = DateTime.UtcNow;
                await SetAsync(sessionId, session);
                return session;
            }

            // Try fallback store with retry logic
            session = await TryGetFromStoreWithRetry(_fallbackStore, sessionId, "Oracle");
            if (session != null)
            {
                // Update last accessed time and sync to both stores
                session.LastAccessedAt = DateTime.UtcNow;
                await SetAsync(sessionId, session);
                return session;
            }

            return null;
        }

        private async Task<UserSession?> TryGetFromStoreWithRetry(ISessionStore store, string sessionId, string storeName)
        {
            for (int attempt = 1; attempt <= _config.MaxRetryAttempts; attempt++)
            {
                try
                {
                    var record = await store.GetAsync(sessionId);
                    if (record != null)
                    {
                        var session = DeserializeSession(record.JsonPayload);
                        if (session != null && !session.IsExpired)
                        {
                            return session;
                        }
                        
                        // Session expired, remove it
                        if (session?.IsExpired == true)
                        {
                            await RemoveAsync(sessionId);
                            return null;
                        }
                    }
                    return null;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Attempt {Attempt}/{MaxAttempts} failed for {StoreName} store when getting session {SessionId}", 
                        attempt, _config.MaxRetryAttempts, storeName, sessionId);
                    
                    if (attempt == _config.MaxRetryAttempts)
                    {
                        _logger.LogError(ex, "All retry attempts failed for {StoreName} store when getting session {SessionId}", 
                            storeName, sessionId);
                        return null;
                    }
                    
                    // Exponential backoff
                    var delay = TimeSpan.FromMilliseconds(_config.RetryDelay.TotalMilliseconds * Math.Pow(2, attempt - 1));
                    await Task.Delay(delay);
                }
            }
            return null;
        }

        public async Task SetAsync(string sessionId, UserSession session)
        {
            if (string.IsNullOrEmpty(sessionId) || session == null)
                return;

            var record = new SessionRecord
            {
                SessionId = sessionId,
                JsonPayload = SerializeSession(session),
                CreatedAt = session.CreatedAt,
                ExpiresAt = session.LastAccessedAt.Add(session.ExpirationTimeout),
                LastAccessedAt = session.LastAccessedAt
            };

            // Try to store in primary store
            var primarySuccess = await TrySetInStoreWithRetry(_primaryStore, sessionId, record, "Redis");
            
            // Try to store in fallback store
            var fallbackSuccess = await TrySetInStoreWithRetry(_fallbackStore, sessionId, record, "Oracle");

            // If both fail, throw exception
            if (!primarySuccess && !fallbackSuccess)
            {
                throw new InvalidOperationException($"Failed to store session {sessionId} in both primary and fallback stores");
            }

            // Log if only one store succeeded
            if (!primarySuccess)
            {
                _logger.LogWarning("Session {SessionId} stored only in fallback store (Oracle)", sessionId);
            }
            else if (!fallbackSuccess)
            {
                _logger.LogWarning("Session {SessionId} stored only in primary store (Redis)", sessionId);
            }
        }

        private async Task<bool> TrySetInStoreWithRetry(ISessionStore store, string sessionId, SessionRecord record, string storeName)
        {
            for (int attempt = 1; attempt <= _config.MaxRetryAttempts; attempt++)
            {
                try
                {
                    await store.SetAsync(sessionId, record);
                    return true;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Attempt {Attempt}/{MaxAttempts} failed for {StoreName} store when setting session {SessionId}", 
                        attempt, _config.MaxRetryAttempts, storeName, sessionId);
                    
                    if (attempt == _config.MaxRetryAttempts)
                    {
                        _logger.LogError(ex, "All retry attempts failed for {StoreName} store when setting session {SessionId}", 
                            storeName, sessionId);
                        return false;
                    }
                    
                    // Exponential backoff
                    var delay = TimeSpan.FromMilliseconds(_config.RetryDelay.TotalMilliseconds * Math.Pow(2, attempt - 1));
                    await Task.Delay(delay);
                }
            }
            return false;
        }

        public async Task RemoveAsync(string sessionId)
        {
            if (string.IsNullOrEmpty(sessionId))
                return;

            try
            {
                await _primaryStore.RemoveAsync(sessionId);
                await _fallbackStore.RemoveAsync(sessionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing session {SessionId}", sessionId);
            }
        }

        public async Task<bool> ExistsAsync(string sessionId)
        {
            if (string.IsNullOrEmpty(sessionId))
                return false;

            try
            {
                return await _primaryStore.ExistsAsync(sessionId) || 
                       await _fallbackStore.ExistsAsync(sessionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking session existence {SessionId}", sessionId);
                return false;
            }
        }

        public async Task CleanupExpiredSessionsAsync()
        {
            // Cleanup primary store
            await TryCleanupStoreWithRetry(_primaryStore, "Redis");
            
            // Cleanup fallback store
            await TryCleanupStoreWithRetry(_fallbackStore, "Oracle");
        }

        private async Task TryCleanupStoreWithRetry(ISessionStore store, string storeName)
        {
            for (int attempt = 1; attempt <= _config.MaxRetryAttempts; attempt++)
            {
                try
                {
                    await store.CleanupExpiredAsync();
                    _logger.LogInformation("Successfully cleaned up expired sessions in {StoreName} store", storeName);
                    return;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Attempt {Attempt}/{MaxAttempts} failed for {StoreName} store cleanup", 
                        attempt, _config.MaxRetryAttempts, storeName);
                    
                    if (attempt == _config.MaxRetryAttempts)
                    {
                        _logger.LogError(ex, "All retry attempts failed for {StoreName} store cleanup", storeName);
                        return;
                    }
                    
                    // Exponential backoff
                    var delay = TimeSpan.FromMilliseconds(_config.RetryDelay.TotalMilliseconds * Math.Pow(2, attempt - 1));
                    await Task.Delay(delay);
                }
            }
        }

        public static string GenerateSessionId()
        {
            using var rng = RandomNumberGenerator.Create();
            var bytes = new byte[32];
            rng.GetBytes(bytes);
            return Convert.ToBase64String(bytes).Replace("+", "-").Replace("/", "_").Replace("=", "");
        }

        private string SerializeSession(UserSession session)
        {
            return JsonSerializer.Serialize(session, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
        }

        private UserSession? DeserializeSession(string json)
        {
            try
            {
                return JsonSerializer.Deserialize<UserSession>(json, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deserializing session data");
                return null;
            }
        }
    }
}