using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SecureSessionManagement.Configuration;

namespace SecureSessionManagement.Services
{
    public class SessionCleanupService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly SessionConfiguration _config;
        private readonly ILogger<SessionCleanupService> _logger;
        private readonly TimeSpan _cleanupInterval = TimeSpan.FromHours(1); // Run cleanup every hour

        public SessionCleanupService(
            IServiceProvider serviceProvider,
            IOptions<SessionConfiguration> config,
            ILogger<SessionCleanupService> logger)
        {
            _serviceProvider = serviceProvider;
            _config = config.Value;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Session cleanup service started");

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await PerformCleanupAsync();
                    await Task.Delay(_cleanupInterval, stoppingToken);
                }
                catch (OperationCanceledException)
                {
                    // Expected when cancellation is requested
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error during scheduled session cleanup");
                    // Continue running even if cleanup fails
                    await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken); // Wait 5 minutes before retry
                }
            }

            _logger.LogInformation("Session cleanup service stopped");
        }

        private async Task PerformCleanupAsync()
        {
            using var scope = _serviceProvider.CreateScope();
            var sessionManager = scope.ServiceProvider.GetRequiredService<ISessionManager>();

            _logger.LogInformation("Starting scheduled session cleanup");
            var startTime = DateTime.UtcNow;

            await sessionManager.CleanupExpiredSessionsAsync();

            var duration = DateTime.UtcNow - startTime;
            _logger.LogInformation("Session cleanup completed in {Duration}ms", duration.TotalMilliseconds);
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Session cleanup service is stopping");
            await base.StopAsync(cancellationToken);
        }
    }
}