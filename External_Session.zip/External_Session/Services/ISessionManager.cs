using System.Threading.Tasks;
using SecureSessionManagement.Models;

namespace SecureSessionManagement.Services
{
    public interface ISessionManager
    {
        Task<UserSession?> GetAsync(string sessionId);
        Task SetAsync(string sessionId, UserSession session);
        Task RemoveAsync(string sessionId);
        Task<bool> ExistsAsync(string sessionId);
        Task CleanupExpiredSessionsAsync();
    }
}