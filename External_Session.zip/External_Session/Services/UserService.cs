using System;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SecureSessionManagement.Models;
using SecureSessionManagement.Repositories;

namespace SecureSessionManagement.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly ILogger<UserService> _logger;

        public UserService(
            IUserRepository userRepository,
            ILogger<UserService> logger)
        {
            _userRepository = userRepository;
            _logger = logger;
        }

        public async Task<User?> GetUserByAccountNameAsync(string accountName)
        {
            if (string.IsNullOrWhiteSpace(accountName))
            {
                _logger.LogWarning("GetUserByAccountNameAsync called with null or empty account name");
                return null;
            }

            try
            {
                // Clean up the account name (remove domain prefix if present)
                var cleanAccountName = ExtractAccountName(accountName);
                
                _logger.LogDebug("Looking up user by account name: {AccountName}", cleanAccountName);
                
                var user = await _userRepository.GetByAccountNameAsync(cleanAccountName);
                
                if (user == null)
                {
                    _logger.LogWarning("User not found for account name: {AccountName}", cleanAccountName);
                    return null;
                }

                if (!user.IsActive)
                {
                    _logger.LogWarning("User account is inactive: {AccountName}", cleanAccountName);
                    return null;
                }

                _logger.LogDebug("User found: {UserId} for account name: {AccountName}", user.UserId, cleanAccountName);
                return user;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving user by account name: {AccountName}", accountName);
                return null;
            }
        }

        public async Task<User?> GetCurrentUserAsync(ClaimsPrincipal principal)
        {
            if (principal?.Identity == null || !principal.Identity.IsAuthenticated)
            {
                _logger.LogDebug("No authenticated user found in ClaimsPrincipal");
                return null;
            }

            try
            {
                // Try to get account name from different claim types
                var accountName = GetAccountNameFromClaims(principal);
                
                if (string.IsNullOrEmpty(accountName))
                {
                    _logger.LogWarning("No account name found in user claims");
                    return null;
                }

                return await GetUserByAccountNameAsync(accountName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving current user from ClaimsPrincipal");
                return null;
            }
        }

        private string ExtractAccountName(string accountName)
        {
            // Handle domain\username format (common in Windows authentication)
            if (accountName.Contains('\\'))
            {
                var parts = accountName.Split('\\');
                return parts.Length > 1 ? parts[1] : parts[0];
            }

            // Handle username@domain format
            if (accountName.Contains('@'))
            {
                var parts = accountName.Split('@');
                return parts[0];
            }

            return accountName;
        }

        private string? GetAccountNameFromClaims(ClaimsPrincipal principal)
        {
            // Try different claim types in order of preference
            var claimTypes = new[]
            {
                ClaimTypes.WindowsAccountName,
                ClaimTypes.Name,
                ClaimTypes.NameIdentifier,
                "preferred_username",
                "upn",
                "unique_name"
            };

            foreach (var claimType in claimTypes)
            {
                var claim = principal.FindFirst(claimType);
                if (claim != null && !string.IsNullOrWhiteSpace(claim.Value))
                {
                    _logger.LogDebug("Found account name in claim type {ClaimType}: {AccountName}", 
                        claimType, claim.Value);
                    return claim.Value;
                }
            }

            // Fallback to Identity.Name
            if (!string.IsNullOrWhiteSpace(principal.Identity.Name))
            {
                _logger.LogDebug("Using Identity.Name as account name: {AccountName}", principal.Identity.Name);
                return principal.Identity.Name;
            }

            return null;
        }

        public async Task<bool> ValidateUserAsync(string accountName)
        {
            var user = await GetUserByAccountNameAsync(accountName);
            return user != null && user.IsActive;
        }

        public async Task<string?> GetUserRoleAsync(string accountName)
        {
            var user = await GetUserByAccountNameAsync(accountName);
            return user?.RoleId;
        }

        public async Task<string?> GetUserExternalConfigAsync(string accountName)
        {
            var user = await GetUserByAccountNameAsync(accountName);
            return user?.ExternalConfig;
        }
    }
}