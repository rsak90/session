using System;

namespace SecureSessionManagement.Models
{
    public class UserSession
    {
        public string UserId { get; set; } = string.Empty;
        public string RoleId { get; set; } = string.Empty;
        public bool IsAuthorized { get; set; }
        public bool IsDashboardVisited { get; set; }
        public string ExternalConfig { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public DateTime LastAccessedAt { get; set; }
        public TimeSpan ExpirationTimeout { get; set; } = TimeSpan.FromMinutes(30);
        
        public bool IsExpired => DateTime.UtcNow > LastAccessedAt.Add(ExpirationTimeout);
    }
}