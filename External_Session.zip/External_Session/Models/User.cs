namespace SecureSessionManagement.Models
{
    public class User
    {
        public string UserId { get; set; } = string.Empty;
        public string AccountName { get; set; } = string.Empty;
        public string RoleId { get; set; } = string.Empty;
        public bool IsActive { get; set; }
        public string ExternalConfig { get; set; } = string.Empty;
    }
}