namespace SecureSessionManagement.Models
{
    public class SessionStatistics
    {
        public int TotalSessions { get; set; }
        public int ActiveSessions { get; set; }
        public int ExpiredSessions { get; set; }
        public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;
    }
}