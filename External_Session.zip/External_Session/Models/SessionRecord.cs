using System;

namespace SecureSessionManagement.Models
{
    public class SessionRecord
    {
        public string SessionId { get; set; } = string.Empty;
        public string JsonPayload { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public DateTime ExpiresAt { get; set; }
        public DateTime LastAccessedAt { get; set; }
    }
}