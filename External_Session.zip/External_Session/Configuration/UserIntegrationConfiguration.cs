using System;

namespace SecureSessionManagement.Configuration
{
    public class UserIntegrationConfiguration
    {
        /// <summary>
        /// The name of the existing Users table in your database
        /// </summary>
        public string UserTableName { get; set; } = "Users";
        
        /// <summary>
        /// Column name for the user ID field
        /// </summary>
        public string UserIdColumn { get; set; } = "UserId";
        
        /// <summary>
        /// Column name for the account name field
        /// </summary>
        public string AccountNameColumn { get; set; } = "AccountName";
        
        /// <summary>
        /// Column name for the role ID field
        /// </summary>
        public string RoleIdColumn { get; set; } = "RoleId";
        
        /// <summary>
        /// Column name for the active status field
        /// </summary>
        public string IsActiveColumn { get; set; } = "IsActive";
        
        /// <summary>
        /// Column name for external configuration field
        /// </summary>
        public string ExternalConfigColumn { get; set; } = "ExternalConfig";
        
        /// <summary>
        /// Column name for last login date field
        /// </summary>
        public string LastLoginDateColumn { get; set; } = "LastLoginDate";
        
        /// <summary>
        /// Whether to automatically create missing columns
        /// </summary>
        public bool AutoCreateMissingColumns { get; set; } = false;
        
        /// <summary>
        /// Custom SQL query for user lookup (if standard table structure doesn't apply)
        /// Use parameters: @accountName
        /// </summary>
        public string? CustomUserLookupQuery { get; set; }
        
        /// <summary>
        /// Whether to use case-sensitive account name matching
        /// </summary>
        public bool CaseSensitiveAccountNames { get; set; } = false;
        
        /// <summary>
        /// Domain to strip from Windows authentication (e.g., "DOMAIN\\username" -> "username")
        /// </summary>
        public string? DomainToStrip { get; set; }
        
        /// <summary>
        /// Whether to update last login date when user is authenticated
        /// </summary>
        public bool UpdateLastLoginDate { get; set; } = true;
        
        /// <summary>
        /// Default role ID for users without a role assigned
        /// </summary>
        public string DefaultRoleId { get; set; } = "USER";
        
        /// <summary>
        /// Whether to cache user lookups in memory
        /// </summary>
        public bool EnableUserCaching { get; set; } = true;
        
        /// <summary>
        /// Cache expiration time for user data
        /// </summary>
        public TimeSpan UserCacheExpiration { get; set; } = TimeSpan.FromMinutes(15);
    }
}