using System;

namespace SecureSessionManagement.Configuration
{
    public class SessionConfiguration
    {
        public bool UseRedisStorage { get; set; } = true;
        public bool UseOracleStorage { get; set; } = true;
        public string RedisConnectionString { get; set; } = string.Empty;
        public string OracleConnectionString { get; set; } = string.Empty;
        public TimeSpan SessionTimeout { get; set; } = TimeSpan.FromMinutes(30);
        public bool EnableLegacyCompatibility { get; set; } = false;
        public string LoginPageUrl { get; set; } = "/Account/Login";
        public int MaxRetryAttempts { get; set; } = 3;
        public TimeSpan RetryDelay { get; set; } = TimeSpan.FromSeconds(1);
        public bool RequiredLogin { get; set; } = true;
    }
}