using System.Threading.Tasks;
using SecureSessionManagement.Models;

namespace SecureSessionManagement.Repositories
{
    public interface IUserRepository
    {
        Task<User?> GetByAccountNameAsync(string accountName);
        Task<User?> GetByUserIdAsync(string userId);
        Task<bool> IsActiveAsync(string accountName);
        Task UpdateLastLoginAsync(string userId);
    }
}