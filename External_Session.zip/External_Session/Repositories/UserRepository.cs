using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using SecureSessionManagement.Configuration;
using SecureSessionManagement.Models;

namespace SecureSessionManagement.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly SessionConfiguration _config;
        private readonly ILogger<UserRepository> _logger;

        public UserRepository(
            IOptions<SessionConfiguration> config,
            ILogger<UserRepository> logger)
        {
            _config = config.Value;
            _logger = logger;
        }

        public async Task<User?> GetByAccountNameAsync(string accountName)
        {
            try
            {
                using var connection = new OracleConnection(_config.OracleConnectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT UserId, AccountName, RoleId, IsActive, ExternalConfig
                    FROM Users 
                    WHERE UPPER(AccountName) = UPPER(:accountName) AND IsActive = 1";

                using var command = new OracleCommand(sql, connection);
                command.Parameters.Add(":accountName", OracleDbType.NVarchar2).Value = accountName;

                using var reader = await command.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    return new User
                    {
                        UserId = reader.GetString("UserId"),
                        AccountName = reader.GetString("AccountName"),
                        RoleId = reader.IsDBNull("RoleId") ? string.Empty : reader.GetString("RoleId"),
                        IsActive = reader.GetInt32("IsActive") == 1,
                        ExternalConfig = reader.IsDBNull("ExternalConfig") ? string.Empty : reader.GetString("ExternalConfig")
                    };
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving user by account name: {AccountName}", accountName);
                throw;
            }
        }

        public async Task<User?> GetByUserIdAsync(string userId)
        {
            try
            {
                using var connection = new OracleConnection(_config.OracleConnectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT UserId, AccountName, RoleId, IsActive, ExternalConfig
                    FROM Users 
                    WHERE UserId = :userId";

                using var command = new OracleCommand(sql, connection);
                command.Parameters.Add(":userId", OracleDbType.NVarchar2).Value = userId;

                using var reader = await command.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    return new User
                    {
                        UserId = reader.GetString("UserId"),
                        AccountName = reader.GetString("AccountName"),
                        RoleId = reader.IsDBNull("RoleId") ? string.Empty : reader.GetString("RoleId"),
                        IsActive = reader.GetInt32("IsActive") == 1,
                        ExternalConfig = reader.IsDBNull("ExternalConfig") ? string.Empty : reader.GetString("ExternalConfig")
                    };
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving user by user ID: {UserId}", userId);
                throw;
            }
        }

        public async Task<bool> IsActiveAsync(string accountName)
        {
            try
            {
                using var connection = new OracleConnection(_config.OracleConnectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT COUNT(1) 
                    FROM Users 
                    WHERE UPPER(AccountName) = UPPER(:accountName) AND IsActive = 1";

                using var command = new OracleCommand(sql, connection);
                command.Parameters.Add(":accountName", OracleDbType.NVarchar2).Value = accountName;

                var result = await command.ExecuteScalarAsync();
                return Convert.ToInt32(result) > 0;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking if user is active: {AccountName}", accountName);
                throw;
            }
        }

        public async Task UpdateLastLoginAsync(string userId)
        {
            try
            {
                using var connection = new OracleConnection(_config.OracleConnectionString);
                await connection.OpenAsync();

                const string sql = @"
                    UPDATE Users 
                    SET LastLoginDate = SYSDATE 
                    WHERE UserId = :userId";

                using var command = new OracleCommand(sql, connection);
                command.Parameters.Add(":userId", OracleDbType.NVarchar2).Value = userId;

                var rowsAffected = await command.ExecuteNonQueryAsync();
                
                if (rowsAffected > 0)
                {
                    _logger.LogDebug("Updated last login date for user: {UserId}", userId);
                }
                else
                {
                    _logger.LogWarning("No rows updated when setting last login date for user: {UserId}", userId);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating last login date for user: {UserId}", userId);
                throw;
            }
        }
    }
}