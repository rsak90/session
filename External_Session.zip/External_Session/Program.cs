using SecureSessionManagement.Extensions;
using SecureSessionManagement.Filters;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllersWithViews(options =>
{
    // Add the authentication filter globally (optional)
    // options.Filters.Add<UserAuthenticationFilter>();
});

// Add secure session management services
builder.Services.AddSecureSessionManagement(builder.Configuration);

// Add other services as needed
builder.Services.AddLogging(logging =>
{
    logging.AddConsole();
    logging.AddDebug();
});

var app = builder.Build();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Authentication and authorization middleware
app.UseAuthentication();
app.UseAuthorization();

// Map controller routes
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Initialize database schema if needed
await InitializeDatabaseAsync(app);

app.Run();

async Task InitializeDatabaseAsync(WebApplication app)
{
    using var scope = app.Services.CreateScope();
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
    
    try
    {
        // Validate configuration
        var configValidator = scope.ServiceProvider.GetRequiredService<SecureSessionManagement.Services.ConfigurationValidationService>();
        var validationResult = configValidator.ValidateConfiguration();
        
        if (!validationResult.IsValid)
        {
            logger.LogError("Configuration validation failed:");
            foreach (var error in validationResult.Errors)
            {
                logger.LogError("- {Error}", error);
            }
            throw new InvalidOperationException("Invalid configuration detected. Please check your appsettings.json file.");
        }
        
        if (validationResult.Warnings.Any())
        {
            logger.LogWarning("Configuration warnings:");
            foreach (var warning in validationResult.Warnings)
            {
                logger.LogWarning("- {Warning}", warning);
            }
        }
        
        configValidator.LogConfigurationSummary();
        
        // Initialize Oracle database schema
        var oracleStore = scope.ServiceProvider.GetServices<SecureSessionManagement.Stores.ISessionStore>()
            .FirstOrDefault(s => s.GetType().Name == "OracleSessionStore") as SecureSessionManagement.Stores.OracleSessionStore;
        
        if (oracleStore != null)
        {
            await oracleStore.InitializeDatabaseAsync();
            logger.LogInformation("Database schema initialized successfully");
        }
        
        // Test Redis connection
        var redisService = scope.ServiceProvider.GetRequiredService<SecureSessionManagement.Services.RedisConnectionService>();
        var isRedisHealthy = await redisService.TestConnectionAsync();
        
        if (isRedisHealthy)
        {
            logger.LogInformation("Redis connection test successful");
        }
        else
        {
            logger.LogWarning("Redis connection test failed - session management will use Oracle fallback");
        }
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Error during application initialization");
        // Don't fail startup for database issues, but do fail for configuration issues
        if (ex is InvalidOperationException)
        {
            throw;
        }
    }
}