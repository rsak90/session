# Design Document

## Overview

The secure session management system replaces the current InProc session storage with a distributed, encrypted solution. The architecture centers around the `ISessionManager` abstraction that provides secure session operations through AES-256-GCM encryption, external storage (Redis primary, Oracle fallback), and Azure Key Vault integration for key management.

## Architecture

### High-Level Architecture

```mermaid
graph TB
    A[MVC Controllers] --> B[ISessionManager]
    C[Web API Controllers] --> B
    D[Custom Authorize Attribute] --> B
    
    B --> E[ReliableSessionManager]
    E --> F[ISessionStore]
    
    F --> G[RedisSessionStore]
    F --> H[OracleSessionStore]
    
    G --> I[Redis Cache]
    H --> J[Oracle Database]
    
    K[HttpContext] --> L[Session Cookies]
    L --> M[SessionId]
    M --> B
```

### Component Interaction Flow

```mermaid
sequenceDiagram
    participant V as MVC View
    participant JS as JavaScript
    participant CC as CommonController
    participant UAF as UserAuthenticationFilter
    participant SM as SessionManager
    participant US as UserService
    participant RS as RedisStore
    participant OS as OracleStore
    
    V->>JS: document.ready()
    JS->>JS: IsLoginRequired()
    JS->>CC: GET /Common/IsLoginRequired
    CC->>SM: GetAsync(sessionId)
    SM->>RS: GetSession(sessionId)
    alt Redis Available
        RS-->>SM: UserSession
    else Redis Unavailable
        SM->>OS: GetSession(sessionId)
        OS-->>SM: UserSession
    end
    SM-->>CC: UserSession
    CC-->>JS: JsonResult(loginRequired)
    
    Note over UAF: Authentication Filter Flow
    UAF->>US: GetUserByAccountName(username)
    US-->>UAF: User
    UAF->>SM: SetAsync(sessionId, userSession)
    SM->>RS: Store session (primary)
    SM->>OS: Store session (backup)
```

## Components and Interfaces

### Core Interfaces

#### ISessionManager
```csharp
public interface ISessionManager
{
    Task<UserSession?> GetAsync(string sessionId);
    Task SetAsync(string sessionId, UserSession session);
    Task RemoveAsync(string sessionId);
    Task<bool> ExistsAsync(string sessionId);
    Task CleanupExpiredSessionsAsync();
}
```

#### IUserService
```csharp
public interface IUserService
{
    Task<User?> GetUserByAccountNameAsync(string accountName);
    Task<User?> GetCurrentUserAsync(ClaimsPrincipal principal);
}
```

#### ISessionStore
```csharp
public interface ISessionStore
{
    Task<SessionRecord?> GetAsync(string sessionId);
    Task SetAsync(string sessionId, SessionRecord record);
    Task RemoveAsync(string sessionId);
    Task<bool> ExistsAsync(string sessionId);
    Task CleanupExpiredAsync();
}
```



### Data Models

#### UserSession
```csharp
public class UserSession
{
    public string UserId { get; set; } = string.Empty;
    public string RoleId { get; set; } = string.Empty;
    public bool IsAuthorized { get; set; }
    public bool IsDashboardVisited { get; set; }
    public string ExternalConfig { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime LastAccessedAt { get; set; }
    public TimeSpan ExpirationTimeout { get; set; } = TimeSpan.FromMinutes(30);
    
    public bool IsExpired => DateTime.UtcNow > LastAccessedAt.Add(ExpirationTimeout);
}
```

#### SessionRecord
```csharp
public class SessionRecord
{
    public string SessionId { get; set; } = string.Empty;
    public string JsonPayload { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime ExpiresAt { get; set; }
    public DateTime LastAccessedAt { get; set; }
}
```



#### User
```csharp
public class User
{
    public string UserId { get; set; } = string.Empty;
    public string AccountName { get; set; } = string.Empty;
    public string RoleId { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public string ExternalConfig { get; set; } = string.Empty;
}
```

#### UserAuthenticationAttribute
```csharp
public class UserAuthenticationAttribute : Attribute, IAuthorizationFilter
{
    public void OnAuthorization(AuthorizationFilterContext context);
}
```

### Implementation Components

#### ReliableSessionManager
- Implements `ISessionManager`
- Manages JSON serialization/deserialization of session data
- Implements dual-storage strategy (Redis primary, Oracle backup)
- Handles session expiration and automatic cleanup
- Provides connection pooling and retry logic for reliability

#### UserAuthenticationFilter
- Custom authorization filter replacing direct ISession usage
- Integrates with `ISessionManager` for secure session operations
- Calls `GetCurrentUser` and `UserService.GetUserByAccountName` for user lookup
- Sets session values through `SetSession` method using secure session management
- Validates user authentication state on each request

#### CommonController
- Refactored `IsLoginRequired` method using `ISessionManager`
- Provides JSON endpoints for client-side authentication checks
- Handles session validation and bypass logic
- Returns structured responses for JavaScript consumption

#### JavaScript Integration
- External JS file with `IsLoginRequired` method
- Called on `document.ready` for all MVC views
- Makes AJAX calls to `CommonController.IsLoginRequired`
- Handles authentication state changes on client-side



#### RedisSessionStore
- Primary storage implementation using Redis
- Implements connection pooling and retry logic
- Supports TLS encryption for data in transit
- Provides distributed caching capabilities
- Handles Redis-specific serialization

#### OracleSessionStore
- Fallback storage implementation using Oracle Database
- Implements connection management and transactions
- Supports encrypted connections
- Provides ACID compliance for session data
- Handles database-specific optimizations

## Data Models

### Session Storage Schema

#### Redis Storage
- Key: `session:{sessionId}`
- Value: JSON serialized `SessionRecord`
- TTL: Based on session expiration timeout
- Clustering: Supports Redis Cluster for high availability

#### Oracle Storage
```sql
CREATE TABLE UserSessions (
    SessionId NVARCHAR2(128) PRIMARY KEY,
    JsonPayload CLOB NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ExpiresAt TIMESTAMP NOT NULL,
    LastAccessedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_expires_at (ExpiresAt),
    INDEX idx_last_accessed (LastAccessedAt)
);
```



## Error Handling

### Exception Hierarchy
```csharp
public class SessionException : Exception
{
    public SessionException(string message) : base(message) { }
    public SessionException(string message, Exception innerException) : base(message, innerException) { }
}

public class SessionStorageException : SessionException
{
    public string StorageType { get; }
    public SessionStorageException(string message, string storageType) : base(message)
    {
        StorageType = storageType;
    }
}

public class SessionSerializationException : SessionException
{
    public SessionSerializationException(string message) : base(message) { }
    public SessionSerializationException(string message, Exception innerException) : base(message, innerException) { }
}
```

### Error Handling Strategy

#### Storage Failures
- Redis primary failure → Automatic fallback to Oracle
- Oracle fallback failure → Return null session (force re-authentication)
- Connection timeout → Exponential backoff retry (max 3 attempts)
- Serialization errors → Log and return null session

#### Data Integrity Failures
- JSON deserialization failure → Log and remove corrupted session
- Invalid session format → Return null session and cleanup storage
- Storage inconsistency → Prefer Redis data, sync to Oracle

#### Session Validation Failures
- Expired session → Remove from storage and return null
- Invalid session format → Log and remove corrupted session
- Missing session → Return null (normal case for new users)
- Concurrent modification → Use optimistic locking where supported

## Testing Strategy

### Unit Testing
- **CryptoHelper Tests**: Encryption/decryption roundtrip, key versioning, HMAC validation
- **SessionManager Tests**: Session CRUD operations, expiration handling, fallback logic
- **Storage Tests**: Redis and Oracle operations, connection handling, serialization
- **Model Tests**: UserSession validation, SessionRecord integrity, data binding
- **UserAuthenticationFilter Tests**: Filter execution, session setting, user lookup integration
- **CommonController Tests**: IsLoginRequired method, JSON response format, session validation
- **JavaScript Tests**: AJAX calls, authentication state handling, DOM manipulation

### Integration Testing
- **End-to-End Session Flow**: Complete session lifecycle from creation to expiration
- **Storage Failover**: Redis failure scenarios with Oracle fallback
- **Key Rotation**: Key version changes during active sessions
- **Concurrent Access**: Multiple instances accessing same session data

### Security Testing
- **Encryption Validation**: Verify AES-256-GCM implementation correctness
- **Key Management**: Test key rotation, version handling, and secure storage
- **Session Hijacking**: Validate cookie security attributes and session validation
- **Data Integrity**: HMAC signature verification and tamper detection

### Performance Testing
- **Session Operations**: Benchmark Get/Set operations under load
- **Storage Performance**: Redis vs Oracle performance characteristics
- **Encryption Overhead**: Measure encryption/decryption performance impact
- **Memory Usage**: Session data memory footprint and garbage collection

### Configuration Testing
- **Connection Strings**: Validate Redis and Oracle connection configurations
- **Key Vault Setup**: Test Azure Key Vault integration and permissions
- **Cookie Configuration**: Verify security attributes and domain settings
- **Timeout Settings**: Test various session timeout configurations

## Reliability Considerations

### Data Persistence
- Dual storage strategy prevents data loss
- Automatic failover between Redis and Oracle
- Session data survives application restarts
- Connection pooling prevents resource exhaustion

### Performance Optimization
- Redis provides fast in-memory access
- Oracle ensures long-term persistence
- JSON serialization for efficient storage
- Connection reuse reduces overhead

### System Resilience
- Graceful degradation when storage is unavailable
- Automatic retry logic with exponential backoff
- Session cleanup prevents storage overflow
- Health monitoring for proactive maintenance

### Memory Management
- External storage eliminates InProc memory issues
- Automatic session expiration prevents memory leaks
- Connection pooling manages resource usage
- Garbage collection friendly object lifecycle
## MVC 
Integration Components

### View Integration
- All MVC views include reference to external JavaScript file
- JavaScript file contains `IsLoginRequired` method called on `document.ready`
- Views handle authentication state changes based on server responses
- Consistent authentication checking across all application pages

### JavaScript Architecture
```javascript
// External JS file structure
function IsLoginRequired() {
    $.ajax({
        url: '/Common/IsLoginRequired',
        type: 'GET',
        dataType: 'json',
        success: function(loginRequired) {
            if (loginRequired === true) {
                // Store current URL for post-login redirect
                sessionStorage.setItem('returnUrl', window.location.href);
                // Redirect to login page
                window.location.href = '/Account/Login';
            }
        },
        error: function() {
            // On error, assume login is required for security
            sessionStorage.setItem('returnUrl', window.location.href);
            window.location.href = '/Account/Login';
        }
    });
}

$(document).ready(function() {
    IsLoginRequired();
});
```

### Controller Refactoring
```csharp
[HttpGet]
public async Task<JsonResult> IsLoginRequired()
{
    var sessionId = HttpContext.Session.GetString("sid");
    if (string.IsNullOrEmpty(sessionId))
        return Json(true);

    var session = await _sessionManager.GetAsync(sessionId);
    if (session == null || !session.IsAuthorized)
        return Json(true);

    bool bypass = _service.ByPassRunArgs(session.ExternalConfig);
    bool result = _settings.RequiredLogin && !bypass;
    return Json(result);
}
```

### Authentication Filter Integration
```csharp
public class UserAuthenticationFilter : IAuthorizationFilter
{
    private readonly ISessionManager _sessionManager;
    private readonly IUserService _userService;

    public async void OnAuthorization(AuthorizationFilterContext context)
    {
        var user = await GetCurrentUser(context.HttpContext.User);
        if (user != null)
        {
            var userSession = new UserSession
            {
                UserId = user.UserId,
                RoleId = user.RoleId,
                IsAuthorized = true,
                ExternalConfig = user.ExternalConfig,
                CreatedAt = DateTime.UtcNow,
                LastAccessedAt = DateTime.UtcNow
            };

            var sessionId = GenerateSessionId();
            await _sessionManager.SetAsync(sessionId, userSession);
            SetSessionCookie(context.HttpContext, sessionId);
        }
    }

    private async Task<User?> GetCurrentUser(ClaimsPrincipal principal)
    {
        var accountName = principal.Identity?.Name?.Split('\\')[0];
        if (!string.IsNullOrEmpty(accountName))
        {
            return await _userService.GetUserByAccountNameAsync(accountName);
        }
        return null;
    }
}
```## Adaptabil
ity and Migration Strategy

### POC Considerations
This implementation serves as a proof-of-concept for integration into existing large-scale applications. Key adaptability features include:

### Backward Compatibility Layer
```csharp
public class LegacySessionAdapter : ISessionManager
{
    private readonly ISessionManager _secureSessionManager;
    private readonly ISession _legacySession;

    // Provides bridge between old ISession usage and new secure implementation
    public async Task<string?> GetLegacyString(string key)
    {
        var session = await GetAsync(GetSessionId());
        return session?.GetPropertyByKey(key);
    }

    public async Task SetLegacyString(string key, string value)
    {
        var sessionId = GetSessionId();
        var session = await GetAsync(sessionId) ?? new UserSession();
        session.SetPropertyByKey(key, value);
        await SetAsync(sessionId, session);
    }
}
```

### Gradual Migration Support
- **Phase 1**: Deploy secure session infrastructure alongside existing ISession
- **Phase 2**: Migrate critical authentication components to use ISessionManager
- **Phase 3**: Gradually replace ISession usage with secure session management
- **Phase 4**: Remove legacy session dependencies

### Configuration Flexibility
```csharp
public class SessionConfiguration
{
    public bool UseRedisStorage { get; set; } = true;
    public bool UseOracleStorage { get; set; } = true;
    public string RedisConnectionString { get; set; } = string.Empty;
    public string OracleConnectionString { get; set; } = string.Empty;
    public TimeSpan SessionTimeout { get; set; } = TimeSpan.FromMinutes(30);
    public bool EnableLegacyCompatibility { get; set; } = false;
    public string LoginPageUrl { get; set; } = "/Account/Login";
    public int MaxRetryAttempts { get; set; } = 3;
    public TimeSpan RetryDelay { get; set; } = TimeSpan.FromSeconds(1);
}
```

### Integration Points
- **Minimal Framework Dependencies**: Core interfaces use standard .NET types
- **Pluggable Storage**: ISessionStore allows different storage implementations
- **Simple Serialization**: JSON-based session data for easy debugging and maintenance
- **Flexible Authentication**: Works with existing ASP.NET Core authentication middleware

### Large-Scale Application Considerations
- **Performance**: Async operations throughout to prevent blocking
- **Scalability**: Distributed storage with connection pooling
- **Monitoring**: Built-in logging and metrics collection points
- **Security**: Defense-in-depth with multiple validation layers
- **Maintenance**: Clear separation of concerns for easier updates