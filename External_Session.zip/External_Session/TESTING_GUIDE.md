# Secure Session Management - Testing Guide

This guide provides comprehensive instructions for testing the Secure Session Management system across different environments and scenarios.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Environment Setup](#environment-setup)
3. [Unit Testing](#unit-testing)
4. [Integration Testing](#integration-testing)
5. [End-to-End Testing](#end-to-end-testing)
6. [Performance Testing](#performance-testing)
7. [Security Testing](#security-testing)
8. [Manual Testing Scenarios](#manual-testing-scenarios)
9. [Troubleshooting](#troubleshooting)

## Prerequisites

### Required Software
- Visual Studio 2022 (17.0 or later)
- .NET 8.0 SDK
- Docker Desktop (for containerized testing)
- Redis Server (local or containerized)
- Oracle Database (local or containerized)
- Postman or similar API testing tool

### Test Data Setup
```sql
-- Create test users in your database
INSERT INTO Users (UserId, AccountName, RoleId, IsActive, ExternalConfig) VALUES
('TEST001', 'testuser1', 'USER', 1, '{"theme":"light","language":"en"}'),
('TEST002', 'testuser2', 'ADMIN', 1, '{"theme":"dark","language":"en"}'),
('TEST003', 'testuser3', 'USER', 0, '{"theme":"light","language":"en"}'); -- Inactive user
```

## Environment Setup

### 1. Development Environment

#### Redis Setup (Docker)
```bash
docker run -d --name redis-test -p 6379:6379 redis:7-alpine
```

#### Oracle Setup (Docker)
```bash
docker run -d --name oracle-test -p 1521:1521 -e ORACLE_PASSWORD=testpassword container-registry.oracle.com/database/express:21.3.0-xe
```

#### Configuration
Update `appsettings.Development.json`:
```json
{
  "SessionManagement": {
    "RedisConnectionString": "localhost:6379",
    "OracleConnectionString": "Data Source=localhost:1521/XE;User Id=system;Password=testpassword;",
    "SessionTimeout": "00:05:00",
    "RequiredLogin": false
  }
}
```

### 2. Test Environment Configuration

Create `appsettings.Testing.json`:
```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Debug",
      "SecureSessionManagement": "Trace"
    }
  },
  "SessionManagement": {
    "UseRedisStorage": true,
    "UseOracleStorage": true,
    "RedisConnectionString": "localhost:6379",
    "OracleConnectionString": "Data Source=localhost:1521/XE;User Id=system;Password=testpassword;",
    "SessionTimeout": "00:02:00",
    "RequiredLogin": true,
    "MaxRetryAttempts": 2,
    "RetryDelay": "00:00:00.500"
  }
}
```

## Unit Testing

### Running Unit Tests

```bash
# Run all tests
dotnet test

# Run with coverage
dotnet test --collect:"XPlat Code Coverage"

# Run specific test category
dotnet test --filter Category=Unit

# Run tests with detailed output
dotnet test --logger "console;verbosity=detailed"
```

### Key Test Categories

#### 1. Session Manager Tests
```csharp
[Fact]
public async Task GetAsync_ValidSessionId_ReturnsSession()
{
    // Arrange
    var sessionId = "test-session-id";
    var expectedSession = new UserSession { UserId = "TEST001" };
    
    // Act
    var result = await _sessionManager.GetAsync(sessionId);
    
    // Assert
    result.Should().NotBeNull();
    result.UserId.Should().Be("TEST001");
}

[Fact]
public async Task GetAsync_ExpiredSession_ReturnsNull()
{
    // Test expired session handling
}

[Fact]
public async Task SetAsync_ValidSession_StoresInBothStores()
{
    // Test dual storage strategy
}
```

#### 2. Cookie Service Tests
```csharp
[Fact]
public void GenerateSecureSessionId_ReturnsValidFormat()
{
    // Test session ID generation
}

[Fact]
public void ValidateSessionIntegrity_ValidCookie_ReturnsTrue()
{
    // Test cookie integrity validation
}
```

#### 3. Validation Service Tests
```csharp
[Fact]
public void ValidateSession_ExpiredSession_ReturnsInvalid()
{
    // Test session expiration validation
}
```

### Sample Unit Test Implementation

Create `Tests/Services/ReliableSessionManagerTests.cs`:
```csharp
using Xunit;
using Moq;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SecureSessionManagement.Services;
using SecureSessionManagement.Configuration;
using SecureSessionManagement.Models;
using SecureSessionManagement.Stores;

namespace SecureSessionManagement.Tests.Services
{
    public class ReliableSessionManagerTests
    {
        private readonly Mock<ISessionStore> _mockRedisStore;
        private readonly Mock<ISessionStore> _mockOracleStore;
        private readonly Mock<ILogger<ReliableSessionManager>> _mockLogger;
        private readonly SessionConfiguration _config;
        private readonly ReliableSessionManager _sessionManager;

        public ReliableSessionManagerTests()
        {
            _mockRedisStore = new Mock<ISessionStore>();
            _mockOracleStore = new Mock<ISessionStore>();
            _mockLogger = new Mock<ILogger<ReliableSessionManager>>();
            
            _config = new SessionConfiguration
            {
                SessionTimeout = TimeSpan.FromMinutes(30),
                MaxRetryAttempts = 3,
                RetryDelay = TimeSpan.FromSeconds(1)
            };

            var stores = new List<ISessionStore> { _mockRedisStore.Object, _mockOracleStore.Object };
            _sessionManager = new ReliableSessionManager(
                stores, 
                Options.Create(_config), 
                _mockLogger.Object);
        }

        [Fact]
        public async Task GetAsync_ValidSession_ReturnsFromRedis()
        {
            // Arrange
            var sessionId = "test-session";
            var sessionRecord = new SessionRecord
            {
                SessionId = sessionId,
                JsonPayload = """{"userId":"TEST001","roleId":"USER","isAuthorized":true}""",
                CreatedAt = DateTime.UtcNow,
                ExpiresAt = DateTime.UtcNow.AddMinutes(30),
                LastAccessedAt = DateTime.UtcNow
            };

            _mockRedisStore.Setup(x => x.GetAsync(sessionId))
                          .ReturnsAsync(sessionRecord);

            // Act
            var result = await _sessionManager.GetAsync(sessionId);

            // Assert
            result.Should().NotBeNull();
            result!.UserId.Should().Be("TEST001");
            _mockRedisStore.Verify(x => x.GetAsync(sessionId), Times.Once);
        }

        [Fact]
        public async Task GetAsync_RedisFailsOracleSucceeds_ReturnsFromOracle()
        {
            // Arrange
            var sessionId = "test-session";
            var sessionRecord = new SessionRecord
            {
                SessionId = sessionId,
                JsonPayload = """{"userId":"TEST001","roleId":"USER","isAuthorized":true}""",
                CreatedAt = DateTime.UtcNow,
                ExpiresAt = DateTime.UtcNow.AddMinutes(30),
                LastAccessedAt = DateTime.UtcNow
            };

            _mockRedisStore.Setup(x => x.GetAsync(sessionId))
                          .ThrowsAsync(new Exception("Redis connection failed"));
            _mockOracleStore.Setup(x => x.GetAsync(sessionId))
                           .ReturnsAsync(sessionRecord);

            // Act
            var result = await _sessionManager.GetAsync(sessionId);

            // Assert
            result.Should().NotBeNull();
            result!.UserId.Should().Be("TEST001");
            _mockOracleStore.Verify(x => x.GetAsync(sessionId), Times.Once);
        }
    }
}
```

## Integration Testing

### Database Integration Tests

Create `Tests/Integration/DatabaseIntegrationTests.cs`:
```csharp
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Testcontainers.Redis;
using Testcontainers.Oracle;
using Xunit;

namespace SecureSessionManagement.Tests.Integration
{
    public class DatabaseIntegrationTests : IAsyncLifetime
    {
        private readonly RedisContainer _redisContainer;
        private readonly OracleContainer _oracleContainer;
        private IServiceProvider _serviceProvider;

        public DatabaseIntegrationTests()
        {
            _redisContainer = new RedisBuilder().Build();
            _oracleContainer = new OracleBuilder().Build();
        }

        public async Task InitializeAsync()
        {
            await _redisContainer.StartAsync();
            await _oracleContainer.StartAsync();

            // Setup service provider with test containers
            var services = new ServiceCollection();
            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string>
                {
                    ["SessionManagement:RedisConnectionString"] = _redisContainer.GetConnectionString(),
                    ["SessionManagement:OracleConnectionString"] = _oracleContainer.GetConnectionString()
                })
                .Build();

            services.AddSecureSessionManagement(configuration);
            _serviceProvider = services.BuildServiceProvider();
        }

        [Fact]
        public async Task SessionLifecycle_CreateUpdateDelete_WorksCorrectly()
        {
            // Arrange
            var sessionManager = _serviceProvider.GetRequiredService<ISessionManager>();
            var sessionId = "integration-test-session";
            var session = new UserSession
            {
                UserId = "TEST001",
                RoleId = "USER",
                IsAuthorized = true,
                CreatedAt = DateTime.UtcNow,
                LastAccessedAt = DateTime.UtcNow
            };

            // Act & Assert - Create
            await sessionManager.SetAsync(sessionId, session);
            var retrievedSession = await sessionManager.GetAsync(sessionId);
            retrievedSession.Should().NotBeNull();
            retrievedSession!.UserId.Should().Be("TEST001");

            // Act & Assert - Update
            session.RoleId = "ADMIN";
            await sessionManager.SetAsync(sessionId, session);
            var updatedSession = await sessionManager.GetAsync(sessionId);
            updatedSession!.RoleId.Should().Be("ADMIN");

            // Act & Assert - Delete
            await sessionManager.RemoveAsync(sessionId);
            var deletedSession = await sessionManager.GetAsync(sessionId);
            deletedSession.Should().BeNull();
        }

        public async Task DisposeAsync()
        {
            await _redisContainer.DisposeAsync();
            await _oracleContainer.DisposeAsync();
        }
    }
}
```

### Web API Integration Tests

Create `Tests/Integration/WebApiIntegrationTests.cs`:
```csharp
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using System.Net.Http.Json;
using Xunit;

namespace SecureSessionManagement.Tests.Integration
{
    public class WebApiIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly WebApplicationFactory<Program> _factory;
        private readonly HttpClient _client;

        public WebApiIntegrationTests(WebApplicationFactory<Program> factory)
        {
            _factory = factory;
            _client = _factory.CreateClient();
        }

        [Fact]
        public async Task IsLoginRequired_NoSession_ReturnsLoginRequired()
        {
            // Act
            var response = await _client.GetAsync("/Common/IsLoginRequired");
            var content = await response.Content.ReadFromJsonAsync<dynamic>();

            // Assert
            response.IsSuccessStatusCode.Should().BeTrue();
            ((bool)content.loginRequired).Should().BeTrue();
        }

        [Fact]
        public async Task SessionInfo_NoSession_ReturnsNoSession()
        {
            // Act
            var response = await _client.GetAsync("/Common/SessionInfo");
            var content = await response.Content.ReadFromJsonAsync<dynamic>();

            // Assert
            response.IsSuccessStatusCode.Should().BeTrue();
            ((bool)content.hasSession).Should().BeFalse();
        }
    }
}
```

## End-to-End Testing

### Browser Automation Tests

Create `Tests/E2E/SessionManagementE2ETests.cs`:
```csharp
using Microsoft.Playwright;
using Xunit;

namespace SecureSessionManagement.Tests.E2E
{
    public class SessionManagementE2ETests : IAsyncLifetime
    {
        private IPlaywright _playwright;
        private IBrowser _browser;
        private IPage _page;

        public async Task InitializeAsync()
        {
            _playwright = await Playwright.CreateAsync();
            _browser = await _playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions
            {
                Headless = false // Set to true for CI/CD
            });
            _page = await _browser.NewPageAsync();
        }

        [Fact]
        public async Task SessionExpiration_ShowsWarningAndRedirects()
        {
            // Navigate to application
            await _page.GotoAsync("https://localhost:5001");

            // Wait for session warning (configure short timeout for testing)
            await _page.WaitForSelectorAsync("#session-warning", new PageWaitForSelectorOptions
            {
                Timeout = 10000
            });

            // Verify warning is displayed
            var warningVisible = await _page.IsVisibleAsync("#session-warning");
            warningVisible.Should().BeTrue();

            // Click extend session
            await _page.ClickAsync("#extend-session-btn");

            // Verify warning disappears
            await _page.WaitForSelectorAsync("#session-warning", new PageWaitForSelectorOptions
            {
                State = WaitForSelectorState.Hidden
            });
        }

        public async Task DisposeAsync()
        {
            await _page?.CloseAsync();
            await _browser?.CloseAsync();
            _playwright?.Dispose();
        }
    }
}
```

## Performance Testing

### Load Testing with NBomber

Create `Tests/Performance/SessionLoadTests.cs`:
```csharp
using NBomber.CSharp;
using NBomber.Http.CSharp;

namespace SecureSessionManagement.Tests.Performance
{
    public class SessionLoadTests
    {
        [Fact]
        public void SessionCreation_LoadTest()
        {
            var scenario = Scenario.Create("session_creation", async context =>
            {
                var httpClient = new HttpClient();
                var sessionId = Guid.NewGuid().ToString();
                
                // Create session
                var createResponse = await httpClient.PostAsJsonAsync(
                    "https://localhost:5001/api/sessions", 
                    new { sessionId, userId = $"user_{context.ScenarioInfo.ThreadId}" });

                return createResponse.IsSuccessStatusCode ? Response.Ok() : Response.Fail();
            })
            .WithLoadSimulations(
                Simulation.InjectPerSec(rate: 100, during: TimeSpan.FromMinutes(5))
            );

            NBomberRunner
                .RegisterScenarios(scenario)
                .Run();
        }

        [Fact]
        public void SessionRetrieval_LoadTest()
        {
            var scenario = Scenario.Create("session_retrieval", async context =>
            {
                var httpClient = new HttpClient();
                
                // Get session info
                var response = await httpClient.GetAsync("https://localhost:5001/Common/SessionInfo");
                
                return response.IsSuccessStatusCode ? Response.Ok() : Response.Fail();
            })
            .WithLoadSimulations(
                Simulation.KeepConstant(copies: 50, during: TimeSpan.FromMinutes(10))
            );

            NBomberRunner
                .RegisterScenarios(scenario)
                .Run();
        }
    }
}
```

## Security Testing

### Security Test Scenarios

Create `Tests/Security/SecurityTests.cs`:
```csharp
using Xunit;
using System.Security.Cryptography;

namespace SecureSessionManagement.Tests.Security
{
    public class SecurityTests
    {
        [Fact]
        public void SessionId_Generation_IsSecure()
        {
            // Generate multiple session IDs
            var sessionIds = new HashSet<string>();
            for (int i = 0; i < 10000; i++)
            {
                var sessionId = SessionCookieService.GenerateSecureSessionId();
                
                // Verify uniqueness
                sessionIds.Add(sessionId).Should().BeTrue($"Session ID {sessionId} was generated twice");
                
                // Verify format
                sessionId.Should().HaveLength(43); // Base64 without padding
                sessionId.Should().MatchRegex("^[A-Za-z0-9_-]+$");
            }
        }

        [Fact]
        public void Cookie_Security_Attributes_AreSet()
        {
            var httpContext = new DefaultHttpContext();
            var cookieService = new SessionCookieService(
                Options.Create(new SessionConfiguration()), 
                Mock.Of<ILogger<SessionCookieService>>());

            // Set cookie
            cookieService.SetSessionCookie(httpContext, "test-session-id");

            // Verify security attributes
            var setCookieHeader = httpContext.Response.Headers["Set-Cookie"].ToString();
            setCookieHeader.Should().Contain("HttpOnly");
            setCookieHeader.Should().Contain("Secure");
            setCookieHeader.Should().Contain("SameSite=Strict");
        }

        [Fact]
        public async Task Session_Encryption_WorksCorrectly()
        {
            // Test session data encryption/decryption
            var originalSession = new UserSession
            {
                UserId = "TEST001",
                RoleId = "ADMIN",
                IsAuthorized = true
            };

            // Serialize and encrypt
            var json = JsonSerializer.Serialize(originalSession);
            
            // Verify sensitive data is not in plain text when stored
            json.Should().NotContain("password");
            json.Should().NotContain("secret");
        }
    }
}
```

## Manual Testing Scenarios

### 1. Session Creation and Validation

**Test Steps:**
1. Open browser and navigate to application
2. Open Developer Tools → Network tab
3. Login with valid credentials
4. Verify session cookie is set with security attributes
5. Check that `IsLoginRequired` returns `false`
6. Verify session data in Redis/Oracle

**Expected Results:**
- Session cookie has HttpOnly, Secure, SameSite attributes
- Session data is stored in both Redis and Oracle
- User can access protected resources

### 2. Session Expiration

**Test Steps:**
1. Login and establish session
2. Wait for session timeout (or modify timeout for testing)
3. Try to access protected resource
4. Verify automatic redirect to login page

**Expected Results:**
- Session expires after configured timeout
- User is redirected to login page
- Expired session is cleaned up from storage

### 3. Failover Testing

**Test Steps:**
1. Establish active session
2. Stop Redis server
3. Continue using application
4. Verify session data is retrieved from Oracle
5. Restart Redis
6. Verify session sync

**Expected Results:**
- Application continues working when Redis is down
- Session data is available from Oracle fallback
- No data loss during failover

### 4. Cross-Browser Session Testing

**Test Steps:**
1. Login in Chrome
2. Copy session cookie
3. Open same application in Firefox
4. Manually set session cookie
5. Try to access application

**Expected Results:**
- Session should not work across browsers (security feature)
- Each browser should maintain separate sessions

### 5. Concurrent Session Testing

**Test Steps:**
1. Login from multiple tabs/windows
2. Perform actions in different tabs
3. Verify session consistency
4. Logout from one tab
5. Check other tabs

**Expected Results:**
- Session is shared across tabs in same browser
- Logout affects all tabs
- No session conflicts

## Troubleshooting

### Common Test Issues

#### 1. Redis Connection Failed
```bash
# Check Redis is running
docker ps | grep redis

# Check Redis logs
docker logs redis-test

# Test connection manually
redis-cli -h localhost -p 6379 ping
```

#### 2. Oracle Connection Issues
```bash
# Check Oracle container
docker ps | grep oracle

# Check Oracle logs
docker logs oracle-test

# Test connection
sqlplus system/testpassword@localhost:1521/XE
```

#### 3. Test Database Setup
```sql
-- Verify tables exist
SELECT table_name FROM user_tables WHERE table_name IN ('USERS', 'USERSESSIONS');

-- Check test data
SELECT * FROM Users WHERE UserId LIKE 'TEST%';

-- Verify session data
SELECT SessionId, CreatedAt, ExpiresAt FROM UserSessions;
```

#### 4. Configuration Issues
```bash
# Verify configuration loading
dotnet run --environment Testing

# Check configuration values
# Add logging in ConfigurationValidationService
```

### Test Data Cleanup

Create cleanup scripts for test data:

```sql
-- Cleanup test sessions
DELETE FROM UserSessions WHERE SessionId LIKE 'test-%';

-- Cleanup test users
DELETE FROM Users WHERE UserId LIKE 'TEST%';

-- Reset sequences if needed
-- ALTER SEQUENCE user_seq RESTART WITH 1000;
```

### Continuous Integration

Example GitHub Actions workflow:

```yaml
name: Test Suite

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      redis:
        image: redis:7-alpine
        ports:
          - 6379:6379
      oracle:
        image: container-registry.oracle.com/database/express:21.3.0-xe
        ports:
          - 1521:1521
        env:
          ORACLE_PASSWORD: testpassword

    steps:
    - uses: actions/checkout@v3
    
    - name: Setup .NET
      uses: actions/setup-dotnet@v3
      with:
        dotnet-version: 8.0.x
        
    - name: Restore dependencies
      run: dotnet restore
      
    - name: Build
      run: dotnet build --no-restore
      
    - name: Test
      run: dotnet test --no-build --verbosity normal --collect:"XPlat Code Coverage"
      
    - name: Upload coverage
      uses: codecov/codecov-action@v3
```

This comprehensive testing guide covers all aspects of testing the Secure Session Management system, from unit tests to end-to-end scenarios, ensuring robust validation of the implementation.