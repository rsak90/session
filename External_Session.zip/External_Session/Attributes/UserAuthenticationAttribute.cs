using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using SecureSessionManagement.Filters;

namespace SecureSessionManagement.Attributes
{
    /// <summary>
    /// Attribute to enable secure session-based authentication for controllers or actions
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
    public class UserAuthenticationAttribute : TypeFilterAttribute
    {
        public UserAuthenticationAttribute() : base(typeof(UserAuthenticationFilter))
        {
            // This attribute will automatically inject the UserAuthenticationFilter
            // with all its dependencies resolved from the DI container
        }

        /// <summary>
        /// Whether to bypass authentication for this action/controller
        /// </summary>
        public bool BypassAuthentication { get; set; } = false;

        /// <summary>
        /// Required role for accessing this action/controller
        /// </summary>
        public string? RequiredRole { get; set; }

        /// <summary>
        /// Whether to allow access for inactive users
        /// </summary>
        public bool AllowInactiveUsers { get; set; } = false;
    }
}